#include <afxwin.h>
#include <afxcmn.h>
#include "yeardialog.h"
#include "resource.h"

yeardialog::yeardialog ( int yr ) : CDialog ( IDD_DIALOG1 ) 
{
	m_year = yr ;
}

int yeardialog::OnInitDialog( )
{
	m_spin = ( CSpinButtonCtrl * ) GetDlgItem ( IDC_SPIN1 ) ;
	m_spin -> SetRange ( 1, 10000 ) ;

	return CDialog::OnInitDialog( ) ;
}

void yeardialog::DoDataExchange ( CDataExchange *pdx )
{
	CDialog::DoDataExchange ( pdx ) ;
		
	DDX_Text ( pdx, IDC_EDIT1, m_year ) ;
	DDV_MinMaxUInt ( pdx, m_year, 1, 10000 ) ;
}

int yeardialog::getyear( )
{
	return m_year ;
}
