class myview : public CScrollView
{
	DECLARE_DYNCREATE ( myview )

	private :

		info m_today ;
		static int m_days[12] ;
		static char *m_months[12] ;
		static char *m_daynames[7] ;
		CFont m_myfont ;
		int m_modeflag ;
		HCURSOR m_cur1, m_cur2 ;
		info m_firstdate, m_seconddate ;
		CPoint m_pos ;
		UINT f_totdays ;

	public :

		myview( ) ;
		void OnInitialUpdate( ) ;
		int OnEraseBkgnd ( CDC *pdc ) ;
		void OnDraw ( CDC *d ) ;
		void changemode( ) ;
		void OnLButtonDown ( UINT flags, CPoint pt ) ;
		void OnMouseMove ( UINT flags, CPoint pt ) ;

	DECLARE_MESSAGE_MAP( )
} ;
