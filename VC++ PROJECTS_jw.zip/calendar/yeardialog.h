class yeardialog : public CDialog 
{
	private :

		CSpinButtonCtrl *m_spin ;
		int m_year ;

	public :

		yeardialog ( int yr ) ;
		int OnInitDialog( ) ;
		void DoDataExchange ( CDataExchange *pdx ) ;
		int getyear( ) ;
} ;

