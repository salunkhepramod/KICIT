#include <afxwin.h>
#include "myapp.h"
#include "info.h"
#include "mydoc.h"
#include "myframe.h"
#include "myview.h"
#include "resource.h"

myapp a ;

BEGIN_MESSAGE_MAP ( myapp, CWinApp ) 

	ON_COMMAND ( ID_FILE_NEW, CWinApp::OnFileNew )
	ON_COMMAND ( ID_FILE_OPEN, CWinApp::OnFileOpen )

END_MESSAGE_MAP( )

int myapp::InitInstance( )
{
	SetRegistryKey ( "Calendar Program" ) ;
	LoadStdProfileSettings ( 6 ) ;

	CSingleDocTemplate *t ;
	CRuntimeClass *md, *mf, *mv ;
		
	md = RUNTIME_CLASS ( mydoc ) ;
	mf = RUNTIME_CLASS ( myframe ) ;
	mv = RUNTIME_CLASS ( myview ) ;

	t = new CSingleDocTemplate ( IDR_MAINFRAME, md, mf, mv ) ;
	AddDocTemplate ( t ) ;

	RegisterShellFileTypes ( TRUE ) ;

	CCommandLineInfo str ;
	ParseCommandLine ( str ) ;

	if ( !ProcessShellCommand ( str ) )
		return FALSE ;

	m_pMainWnd -> DragAcceptFiles( ) ;
	return 1 ;
} 
