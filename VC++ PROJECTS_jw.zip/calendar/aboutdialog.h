class aboutdialog : public CDialog 
{
	private :

		HICON m_ico1, m_ico2 ;
		int m_iconflag ;
		CStatic *m_st ;

	public :

		aboutdialog( ) ;
		int OnInitDialog( ) ;
		void OnTimer( ) ;
		void OnOK( ) ;

	DECLARE_MESSAGE_MAP( )
} ;
