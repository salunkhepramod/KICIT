struct info
{
	int dd, mm, yy ;

	int height, width, weight, italic, underline, strikeout ;
	CString facename ;

	COLORREF windowbk, mnt, wkday, dat, tddat, tddatbox ;
} ;
