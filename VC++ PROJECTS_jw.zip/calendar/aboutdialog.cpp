#include <afxwin.h>
#include "aboutdialog.h"
#include "resource.h"

BEGIN_MESSAGE_MAP ( aboutdialog, CDialog )
	ON_WM_TIMER( )
END_MESSAGE_MAP( )

aboutdialog::aboutdialog( ) : CDialog ( IDD_DIALOG2 ) 
{
}

int aboutdialog::OnInitDialog( )
{
	m_ico1 = AfxGetApp( ) -> LoadIcon ( IDI_ICON1 ) ;
	m_ico2 = AfxGetApp( ) -> LoadIcon ( IDI_ICON2 ) ;
	m_st = ( CStatic * ) GetDlgItem ( IDC_ICONVIEW ) ;

	m_iconflag = 1 ;
	SetIcon ( m_ico1, TRUE ) ;

	SetTimer ( 1, 200, NULL ) ;

	return CDialog::OnInitDialog( ) ;
}

void aboutdialog::OnTimer( )
{
	if ( m_iconflag == 1 )
	{
		m_st -> SetIcon ( m_ico1 ) ;
		SetIcon ( m_ico1, TRUE ) ;
		m_iconflag = 2 ;
	}
	else
	{
		m_st -> SetIcon ( m_ico2 ) ;
		SetIcon ( m_ico2, TRUE ) ;
		m_iconflag = 1 ;
	}
}

void aboutdialog::OnOK( )
{
	CDialog::OnOK( ) ;
	KillTimer ( 1 ) ;
}
