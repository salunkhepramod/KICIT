class myview : public CView
{	
	DECLARE_DYNCREATE ( myview ) 

	private :

		CPoint m_hstart, m_hend, m_vstart, m_vend ;
		int m_firsttime ;
		city *m_city ;
		CStatic m_static ;
		CRect m_rect ;

	public :

		myview( ) ;
		int OnCreate ( LPCREATESTRUCT l ) ;
		void OnDraw ( CDC *p ) ;
		void OnMouseMove ( UINT flags, CPoint pt ) ;

	DECLARE_MESSAGE_MAP( )
} ;
