class mydoc : public CDocument
{
	DECLARE_DYNCREATE ( mydoc )
	
	private :

		CObArray arr ;
		int m_count ;

	public :
		
		mydoc( ) ;
		BOOL OnNewDocument( ) ;
		void init_array( ) ;
		city* getcity ( int i ) ;
		int search ( CPoint p ) ;
		void DeleteContents( ) ;
} ;
