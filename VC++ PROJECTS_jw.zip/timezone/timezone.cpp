#include <afxwin.h>
#include <afxext.h>

#include "resource.h"

#define TRUE 1
#define FALSE 0
#define MAX 100

class city : public CObject
{
	private :

		int m_hour, m_minute ;
		CString m_name ;
	
	public :

		CPoint m_pt ;

		city( )
		{
		}

		city ( int hr, int min, CString n, CPoint p )
		{
			m_hour = hr ;
			m_minute = min ;
			m_name = n ;
			m_pt = p ; 
		}

		CString calculate( )
		{
			int hr, min, week_day ;

			CString day ;
													
			CTime t = CTime::GetCurrentTime () ;
	
			week_day = t.GetDayOfWeek( ) ;
			hr = t.GetHour( ) + m_hour ;
			min = t.GetMinute( ) + m_minute ;
								
			if ( min >= 60 )
			{
				hr++ ;
				min -= 60 ;
			}	
									
			if ( min < 0 )
			{
				hr-- ;
				min += 60 ;
			}
									
			if ( hr >= 24 )
			{
				hr -= 24 ;
				week_day++ ;
	
				if ( hr == 0 ) 
					hr = 24 ;
			}							
	   
			if(hr <= 0)
			{
				hr += 24 ;
				week_day-- ;
			}
									
			if ( week_day == 8 )
				week_day = 1 ;
							
			if ( week_day == 0 )
				week_day = 7 ;
								
			switch ( week_day )
			{
				case 1:
					 day = " Sun" ;
					break ;

				case 2:
					day = " Mon" ;
					break ;
		
				case 3:
					day = " Tue" ;
					break ;
	
				case 4:
					day = " Wed" ;
					break ;
	
				case 5:
					day = " Thu" ;
					break ;
	
				case 6:
					day = " Fri" ;
					break ;
	
				case 7:
					day = " Sat" ;
					break ;
			}

			CString str ;
			str.Format ( "%s %d:%d %s", day, hr, min, m_name ) ;

			return str ;
		}
} ;

class mydoc : public CDocument
{
	DECLARE_DYNCREATE ( mydoc )
	
	private :

		CObArray arr ;
		int m_count ;

	public :
		
		mydoc( )
		{
			m_count = 0 ;
			arr.SetSize ( 0, 20 ) ;
		}

		BOOL OnNewDocument( )
		{
			CDocument::OnNewDocument( ) ;
			init_array( ) ;
			return TRUE ;
		}

		void init_array( )
		{
			CStdioFile file ;
			file.Open ( "TIME.DAT", CFile::modeRead ) ;

			int hr, min, x, y ;
			char  place[20] ;
			CString str ;
			city *c ;
			while ( file.ReadString ( str ) != NULL )
			{
				sscanf ( str, "%d %d %s %d %d", &hr, &min, place, &x, &y ) ;
				
				c = new city ( hr, min, place, CPoint ( x, y ) ) ;
				arr.Add ( c ) ;
			}
			file.Close( ) ;

			m_count = arr.GetSize( ) ;
		}

		city* getcity ( int i )
		{
			return ( (city*) arr[i] ) ;
		}

		int search ( CPoint p )
		{
			CRect r ( p.x - 5, p.y - 5, p.x + 5, p.y + 5 ) ;

			CPoint pt ;
			for ( int i = 0 ; i < m_count ; i++ )
			{
				pt = getcity ( i ) -> m_pt ;
				if ( pt.x > r.left && pt.x < r.right && pt.y > r.top && pt.y < r.bottom ) 
				{
					return ( i ) ;
				}
			}

			return -1 ;
		}

		void DeleteContents( )
		{
			int count = arr.GetSize( ) ;

			for ( int i = 0 ; i< count ; i++ )
				delete arr[i] ;

			arr.RemoveAll( ) ;
		}
} ;

IMPLEMENT_DYNCREATE ( mydoc, CDocument ) 

class myview : public CView
{	
	DECLARE_DYNCREATE ( myview ) 

	private:

		CPoint m_hstart, m_hend, m_vstart, m_vend ;
		int firsttime ;
		city *m_city ;
		CStatic m_static ;
		CRect m_rect ;

	public:

		myview()
		{
			firsttime = 1 ;
		}

		int OnCreate ( LPCREATESTRUCT l )
		{
			CView::OnCreate ( l ) ;
			m_static.Create ( "", WS_CHILD, CRect ( 0, 0, 50, 20 ), this, 1 ) ;
			return 0 ;
		}


		void OnDraw ( CDC *p )
		{
			if ( firsttime == 1 )
			{
				CRect r ;
				GetClientRect ( &r ) ;
				m_rect = r ;

				m_hstart = CPoint ( r.left, r.bottom / 2 ) ;
		 		m_hend = CPoint ( r.right, r.bottom / 2 ) ;
				m_vstart = CPoint ( r.right / 2, r.top ) ;
		 		m_vend = CPoint ( r.right / 2, r.bottom ) ;

				firsttime = 0 ;
			}

			CBitmap mybitmap ;
		 	CDC mymemdc ;
			BITMAP b ;
        			
			mybitmap.LoadBitmap ( IDB_BITMAP1 ) ;
			mymemdc.CreateCompatibleDC ( p ) ;
			mymemdc.SelectObject ( &mybitmap ) ;

			mybitmap.GetBitmap( &b ) ;
			p -> BitBlt ( 0, 0, b.bmWidth, b.bmHeight, &mymemdc, 0, 0, SRCCOPY ) ;
			
			p -> SetROP2 ( R2_NOTXORPEN ) ;
	
			p -> MoveTo ( m_hstart ) ;
		 	p -> LineTo ( m_hend ) ;

			p -> MoveTo ( m_vstart ) ;
		 	p -> LineTo ( m_vend ) ;
		}

		void OnMouseMove ( UINT flags, CPoint pt )
		{
			CClientDC d ( this ) ;

			CPen mypen ;
			mypen.CreatePen ( PS_SOLID, 3, RGB ( 0, 0, 255 ) ) ;

			d.SetROP2 ( R2_NOTXORPEN ) ;
			d.MoveTo ( m_hstart ) ;
 			d.LineTo ( m_hend ) ;

			d.MoveTo ( m_vstart ) ;
 			d.LineTo ( m_vend ) ;

			// new line
			m_hstart.y = pt.y ;
			m_hend.y = pt.y ;
			
			m_vstart.x = pt.x ;
			m_vend.x = pt.x ;

			d.MoveTo ( m_hstart ) ;
			d.LineTo ( m_hend ) ;

			d.MoveTo ( m_vstart ) ;
			d.LineTo ( m_vend ) ;

			CString str ;
			str.Format ( "%d %d", pt.x, pt.y ) ;

			mydoc *pdoc = ( ( mydoc *) GetDocument( ) ) ;
			int index = pdoc  -> search ( pt ) ;

			if ( index != -1 )
			{
				m_city = pdoc -> getcity ( index ) ;

				SetCursor ( AfxGetApp( ) -> LoadCursor ( IDC_NULL ) ) ;
				
				CPoint dpt ;
				if ( pt.x + 150 + 4 < m_rect.right )
					dpt.x = pt.x + 4 ;
				else
					dpt.x = pt.x - 150 - 4 ;

				if ( pt.y + 15 + 4 < m_rect.bottom )
					dpt.y = pt.y + 4 ;
				else
					dpt.y = pt.y - 15 - 4 ;

				m_static.SetWindowPos ( &wndTop, dpt.x, dpt.y, 150, 15, SWP_SHOWWINDOW ) ;

				CString info ;
				info = m_city -> calculate( ) ;
				m_static.SetWindowText ( info ) ;
			}
			else
			{
				m_static.SetWindowPos ( &wndTop, pt.x, pt.y, 100, 50, SWP_HIDEWINDOW ) ;
			}
		}


	DECLARE_MESSAGE_MAP( )
} ;

BEGIN_MESSAGE_MAP ( myview, CView ) 
	ON_WM_CREATE( )
	ON_WM_MOUSEMOVE( )
END_MESSAGE_MAP( )

IMPLEMENT_DYNCREATE ( myview, CView ) 
		
class myframe : public CFrameWnd
{	
	DECLARE_DYNCREATE ( myframe ) 

	private:

		int m_count ;

	public:

		void OnSize ( UINT type, int cx, int cy )
		{
			CFrameWnd::OnSize ( type, cx, cy ) ;
			SetWindowPos ( &wndTop, 0, 0, 370, 228, SWP_SHOWWINDOW ) ;
		}

	DECLARE_MESSAGE_MAP()
};	
	
BEGIN_MESSAGE_MAP(myframe,CFrameWnd)
	ON_WM_SIZE ( )
END_MESSAGE_MAP ( )

IMPLEMENT_DYNCREATE ( myframe, CFrameWnd ) 

class myapp:public CWinApp
{
	public:

		int InitInstance( )
		{
			CRuntimeClass *md, *mf, *mv ;

			md = RUNTIME_CLASS ( mydoc ) ;
			mf = RUNTIME_CLASS ( myframe ) ;
			mv = RUNTIME_CLASS ( myview ) ;

			CSingleDocTemplate *p ;
			p = new CSingleDocTemplate ( IDR_MAINRES, md, mf, mv ) ;

			AddDocTemplate ( p ) ;

			CCommandLineInfo str ;
			ParseCommandLine ( str ) ;

			if ( !ProcessShellCommand ( str ) )
				return FALSE ;

			return 1 ;
		} 
} ;

myapp a ;
					
