#include <afxwin.h>
#include "city.h"
#include "mydoc.h"

IMPLEMENT_DYNCREATE ( mydoc, CDocument ) 

mydoc::mydoc( )
{
	m_count = 0 ;
	arr.SetSize ( 0, 20 ) ;
}

BOOL mydoc::OnNewDocument( )
{
	CDocument::OnNewDocument( ) ;
	init_array( ) ;
	SetTitle ( "World" ) ;

	return TRUE ;
}

void mydoc::init_array( )
{
	CStdioFile file ;
	file.Open ( "TIME.DAT", CFile::modeRead ) ;

	int hr, min, x, y ;
	char  place[20] ;
	CString str ;
	city *c ;
	while ( file.ReadString ( str ) != NULL )
	{
		sscanf ( str, "%d %d %s %d %d", &hr, &min, place, &x, &y ) ;
				
		c = new city ( hr, min, place, CPoint ( x, y ) ) ;
		arr.Add ( c ) ;
	}
	file.Close( ) ;

	m_count = arr.GetSize( ) ;
}

city* mydoc::getcity ( int i )
{
	return ( (city*) arr[i] ) ;
}

int mydoc::search ( CPoint p )
{
	CRect r ( p.x - 5, p.y - 5, p.x + 5, p.y + 5 ) ;

	CPoint pt ;
	for ( int i = 0 ; i < m_count ; i++ )
	{
		pt = getcity ( i ) -> m_pt ;
		if ( pt.x > r.left && pt.x < r.right && pt.y > r.top && pt.y < r.bottom ) 
		{
			return ( i ) ;
		}
	}

	return -1 ;
}

void mydoc::DeleteContents( )
{
	int count = arr.GetSize( ) ;

	for ( int i = 0 ; i < count ; i++ )
		delete arr[i] ;

	arr.RemoveAll( ) ;
}
