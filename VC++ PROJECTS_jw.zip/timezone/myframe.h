class myframe : public CFrameWnd
{	
	DECLARE_DYNCREATE ( myframe ) 

	private:

		int m_count ;

	public:

		BOOL PreCreateWindow ( CREATESTRUCT& cs ) ;
		void OnSize ( UINT type, int cx, int cy ) ;

	DECLARE_MESSAGE_MAP( )
};	
