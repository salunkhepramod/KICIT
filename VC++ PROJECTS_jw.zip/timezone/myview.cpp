#include <afxwin.h>
#include "city.h"
#include "mydoc.h"
#include "myview.h"
#include "resource.h"

BEGIN_MESSAGE_MAP ( myview, CView ) 
	ON_WM_CREATE( )
	ON_WM_MOUSEMOVE( )
END_MESSAGE_MAP( )

IMPLEMENT_DYNCREATE ( myview, CView ) 

myview::myview( )
{
	m_firsttime = 1 ;
}

int myview::OnCreate ( LPCREATESTRUCT l )
{
	CView::OnCreate ( l ) ;
	m_static.Create ( "", WS_CHILD, CRect ( 0, 0, 50, 20 ), this, 1 ) ;
	return 0 ;
}

void myview::OnDraw ( CDC *p )
{
	if ( m_firsttime == 1 )
	{
		CRect r ;
		GetClientRect ( &r ) ;
		m_rect = r ;

		m_hstart = CPoint ( r.left, r.bottom / 2 ) ;
 		m_hend = CPoint ( r.right, r.bottom / 2 ) ;
		m_vstart = CPoint ( r.right / 2, r.top ) ;
 		m_vend = CPoint ( r.right / 2, r.bottom ) ;

		m_firsttime = 0 ;
	}

	CBitmap mybitmap ;
 	CDC mymemdc ;
	BITMAP b ;
        			
	mybitmap.LoadBitmap ( IDB_BITMAP1 ) ;
	mymemdc.CreateCompatibleDC ( p ) ;
	mymemdc.SelectObject ( &mybitmap ) ;

	mybitmap.GetBitmap( &b ) ;
	p -> BitBlt ( 0, 0, b.bmWidth, b.bmHeight, &mymemdc, 0, 0, SRCCOPY ) ;
			
	p -> SetROP2 ( R2_NOTXORPEN ) ;
	
	p -> MoveTo ( m_hstart ) ;
 	p -> LineTo ( m_hend ) ;

	p -> MoveTo ( m_vstart ) ;
 	p -> LineTo ( m_vend ) ;
}

void myview::OnMouseMove ( UINT flags, CPoint pt )
{
	CClientDC d ( this ) ;

	CPen mypen ;
	mypen.CreatePen ( PS_SOLID, 3, RGB ( 0, 0, 255 ) ) ;

	// erase earlier lines
	d.SetROP2 ( R2_NOTXORPEN ) ;
	d.MoveTo ( m_hstart ) ;
	d.LineTo ( m_hend ) ;

	d.MoveTo ( m_vstart ) ;
	d.LineTo ( m_vend ) ;

	// draw new lines
	m_hstart.y = pt.y ;
	m_hend.y = pt.y ;
			
	m_vstart.x = pt.x ;
	m_vend.x = pt.x ;

	d.MoveTo ( m_hstart ) ;
	d.LineTo ( m_hend ) ;

	d.MoveTo ( m_vstart ) ;
	d.LineTo ( m_vend ) ;

	mydoc *pdoc = ( ( mydoc *) GetDocument( ) ) ;
	int index = pdoc  -> search ( pt ) ;

	if ( index != -1 )
	{
		m_city = pdoc -> getcity ( index ) ;

		SetCursor ( AfxGetApp( ) -> LoadCursor ( IDC_NULL ) ) ;
				
		CPoint dpt ;
		if ( pt.x + 150 + 4 < m_rect.right )
			dpt.x = pt.x + 4 ;
		else
			dpt.x = pt.x - 150 - 4 ;

		if ( pt.y + 15 + 4 < m_rect.bottom )
			dpt.y = pt.y + 4 ;
		else
			dpt.y = pt.y - 15 - 4 ;

		m_static.SetWindowPos ( &wndTop, dpt.x, dpt.y, 150, 15, SWP_SHOWWINDOW ) ;

		CString info ;
		info = m_city -> calculate( ) ;
		m_static.SetWindowText ( info ) ;
	}
	else
	{
		m_static.SetWindowPos ( &wndTop, pt.x, pt.y, 100, 50, SWP_HIDEWINDOW ) ;
	}
}
