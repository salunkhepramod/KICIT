#include <afxwin.h>
#include <afxext.h>

#include "resource.h"

#define TRUE 1
#define FALSE 0
#define MAX 100
