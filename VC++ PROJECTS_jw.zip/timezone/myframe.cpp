#include <afxwin.h>
#include "myframe.h"
#include "resource.h"

BEGIN_MESSAGE_MAP ( myframe, CFrameWnd )
	ON_WM_SIZE ( )
END_MESSAGE_MAP ( )

IMPLEMENT_DYNCREATE ( myframe, CFrameWnd ) 

BOOL myframe::PreCreateWindow ( CREATESTRUCT& cs )
{
	CFrameWnd::PreCreateWindow ( cs ) ;
	cs.style &= ~WS_MAXIMIZEBOX ;

	return TRUE ;
}

void myframe::OnSize ( UINT type, int cx, int cy )
{
	CFrameWnd::OnSize ( type, cx, cy ) ;
	SetWindowPos ( &wndTop, 0, 0, 370, 228, SWP_SHOWWINDOW ) ;
}
