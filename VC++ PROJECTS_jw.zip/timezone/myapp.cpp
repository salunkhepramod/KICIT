#include <afxwin.h>
#include "myapp.h"
#include "city.h"
#include "mydoc.h"
#include "myframe.h"
#include "myview.h"
#include "resource.h"

myapp a ;

int myapp::InitInstance( )
{
	CRuntimeClass *md, *mf, *mv ;

	md = RUNTIME_CLASS ( mydoc ) ;
	mf = RUNTIME_CLASS ( myframe ) ;
	mv = RUNTIME_CLASS ( myview ) ;

	CSingleDocTemplate *p ;
	p = new CSingleDocTemplate ( IDR_MAINRES, md, mf, mv ) ;

	AddDocTemplate ( p ) ;

	OnFileNew( ) ;

	return 1 ;
}

