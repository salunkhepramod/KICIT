#include <afxwin.h>
#include "city.h"

city::city( )
{
}

city::city ( int hr, int min, CString n, CPoint p )
{
	m_hour = hr ;
	m_minute = min ;
	m_name = n ;
	m_pt = p ; 
}

CString city::calculate( )
{
	int hr, min, week_day ;

	CString day ;
													
	CTime t = CTime::GetCurrentTime( ) ;
	
	week_day = t.GetDayOfWeek( ) ;
	hr = t.GetHour( ) + m_hour ;
	min = t.GetMinute( ) + m_minute ;
								
	if ( min >= 60 )
	{
		hr++ ;
		min -= 60 ;
	}	
									
	if ( min < 0 )
	{
		hr-- ;
		min += 60 ;
	}
									
	if ( hr >= 24 )
	{
		hr -= 24 ;
		week_day++ ;
	
		if ( hr == 0 ) 
			hr = 24 ;
	}							
	   
	if(hr <= 0)
	{
		hr += 24 ;
		week_day-- ;
	}
									
	if ( week_day == 8 )
		week_day = 1 ;
							
	if ( week_day == 0 )
		week_day = 7 ;
								
	switch ( week_day )
	{
		case 1 :
			day = " Sun" ;
			break ;

		case 2 :
			day = " Mon" ;
			break ;
		
		case 3 :
			day = " Tue" ;
			break ;
	
		case 4 :
			day = " Wed" ;
			break ;
	
		case 5 :
			day = " Thu" ;
			break ;
	
		case 6 :
			day = " Fri" ;
			break ;
	
		case 7 :
			day = " Sat" ;
			break ;
	}

	CString str ;
	str.Format ( "%s %d:%d %s", day, hr, min, m_name ) ;

	return str ;
}
