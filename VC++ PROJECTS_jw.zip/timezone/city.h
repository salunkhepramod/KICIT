class city : public CObject
{
	private :

		int m_hour, m_minute ;
		CString m_name ;
	
	public :

		CPoint m_pt ;

		city( ) ;
		city ( int hr, int min, CString n, CPoint p ) ;
		CString calculate( ) ;
} ;

