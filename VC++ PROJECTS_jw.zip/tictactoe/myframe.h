class myframe : public CFrameWnd
{
	private :

		int arr[9] ; 
		CRect square[9] ;

	public :

		myframe( ) ;
		int OnCreate ( LPCREATESTRUCT l ) ;
		void OnSysCommand ( UINT id, LPARAM l ) ;
		void OnPaint( ) ;
		void drawex ( int i ) ;
		void drawoh ( int i ) ;
		void OnLButtonDown ( UINT Flags, CPoint pt ) ;
		void compplay( ) ;
		int diduserwin( ) ;
		int isgamedrawn( ) ;
		void didcomputerwin( ) ;
		int findwinner( ) ;
		void OnLButtonDblClk ( UINT flags,CPoint p ) ;
		void resetgame( ) ;

	DECLARE_MESSAGE_MAP( )
} ;
