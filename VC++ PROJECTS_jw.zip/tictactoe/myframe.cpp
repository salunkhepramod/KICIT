#include <afxwin.h>
#include "myframe.h"
#include "resource.h"

#define EMPTY 		0
#define EX 			1 
#define OH 			2
#define DRAW 		3 
#define WON 		4
#define LOST 		5

BEGIN_MESSAGE_MAP ( myframe, CFrameWnd )

	ON_WM_PAINT( )
	ON_WM_CREATE( )
	ON_WM_LBUTTONDOWN( )
	ON_WM_LBUTTONDBLCLK( )
	ON_WM_SYSCOMMAND( )

END_MESSAGE_MAP( )

myframe::myframe( )
{
	CString mywindowclass ;
	CBrush mybrush ;
	mybrush.CreateStockObject ( LTGRAY_BRUSH ) ;

	mywindowclass = AfxRegisterWndClass ( CS_DBLCLKS,
						AfxGetApp( ) -> LoadStandardCursor ( IDC_ARROW ),
						mybrush,					
						AfxGetApp( ) -> LoadStandardIcon ( IDI_EXCLAMATION ) ) ;

	Create ( mywindowclass, "Tic Tac Toe", 
			WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU, 
			CRect ( 10, 10, 180, 200 ) ) ;
}

int myframe::OnCreate ( LPCREATESTRUCT l )
{		
	CFrameWnd::OnCreate ( l ) ;

	for ( int i = 0 ; i <= 8 ; i++ )
		arr[i] = EMPTY ;
					
	square[0] = CRect ( 10, 10, 49, 49 ) ;
	square[1] = CRect ( 60, 10, 99, 49 ) ;
	square[2] = CRect ( 110, 10, 149, 49 );
	square[3] = CRect ( 10, 60, 49, 99 ) ;
	square[4] = CRect ( 60, 60, 99, 99 ) ;
	square[5] = CRect ( 110, 60, 149, 99 ) ;
	square[6] = CRect ( 10, 110, 49, 149 ) ;
	square[7] = CRect ( 60, 110, 99, 149 ) ;
	square[8] = CRect ( 110, 110, 149, 149 ) ;

	CMenu *psystemmenu = GetSystemMenu ( FALSE ) ;

	psystemmenu -> AppendMenu ( MF_SEPARATOR ) ;
	psystemmenu -> AppendMenu ( MF_STRING, 112, "&About" ) ;

	psystemmenu -> AppendMenu ( MF_SEPARATOR ) ;
	psystemmenu -> AppendMenu ( MF_STRING, 128, "&Help" ) ;

	return 0;
}

void myframe::OnSysCommand ( UINT id, LPARAM l )
{
	if( ( id & 0xfff0 )  == 112 )
	{
		CDialog d ( IDD_DIALOG2 ) ;
		d.DoModal( ) ;
		return ;
	}

	if ( ( id & 0xfff0 ) == 128 )
	{
		CDialog d ( IDD_DIALOG1 ) ;
		d.DoModal( );
		return ;
	}

	CFrameWnd::OnSysCommand ( id, l ) ;
}

void myframe::OnPaint( )
{
	CPaintDC d ( this ) ;
			
	CPen mypen ( PS_SOLID, 10, RGB ( 0, 0, 0 ) ) ;

	d.SelectObject ( &mypen ) ;

	d.MoveTo ( 10, 54) ;
	d.LineTo ( 149, 54) ;

	d.MoveTo ( 10, 104 ) ;
	d.LineTo ( 149, 104 ) ;

	d.MoveTo ( 54,10 ) ;
	d.LineTo ( 54, 149 ) ;

	d.MoveTo ( 104, 10 ) ;
	d.LineTo ( 104, 149 ) ;

	for ( int i = 0 ; i <= 8; i++ )
	{
		if ( arr[i] == EX )
			drawex ( i ) ;
			
		if( arr[i] == OH ) 
			drawoh ( i ) ;
	}
}

void myframe::drawex ( int i )
{
	CClientDC d ( this ) ;
	CPen mypen ( PS_SOLID, 5, RGB ( 255, 0, 0 ) ) ;
			
	d.SelectObject ( &mypen ) ;

	d.MoveTo ( square[i].left + 10, square[i].top + 10 ) ;
	d.LineTo ( square[i].right - 10, square[i].bottom - 10 ) ;

	d.MoveTo ( square[i].left + 10, square[i].bottom - 10 ) ;
	d.LineTo ( square[i].right - 10, square[i].top + 10 ) ;
}

void myframe::drawoh ( int i )
{
	CClientDC d ( this ) ;
		
	CBrush mybrush ;
	mybrush.CreateStockObject ( NULL_BRUSH ) ;
			
	CPen mypen ( PS_SOLID, 5, RGB ( 0, 0, 255 ) ) ;
			
	d.SelectObject ( &mypen ) ;
			
	d.SelectObject ( &mybrush ) ;

	CRect r = square[ i ] ;
	d.Ellipse ( CRect (  r.left+5, r.top+5, r.right-5, r.bottom-5 ) ) ;
}	
			
void myframe::OnLButtonDown ( UINT Flags, CPoint pt )
{
	int i ;
			
	for ( i = 0 ; i <= 8; i++ )
	{
		if ( square[i].PtInRect ( pt ) && ( arr[i] == OH || arr[i] == EX ) )
		{
			MessageBox ( " Cheating! Press left button only at Empty boxes" ) ;
			return ;
		}
		else
		{
			if ( square[i].PtInRect ( pt ) && arr[i] == EMPTY )
			{
				drawoh ( i ) ;
				arr[i] = OH ;
						
				if ( diduserwin( ) )
					break ;
				else
				{
					if ( isgamedrawn( ) )
						break ;
					else
					{
						Sleep ( rand( ) % 1000 ) ;
						compplay( ) ;
						break ;
					}
				}
			}  
		}
	}
}

void myframe::compplay( )
{
	int p[3][3] = 
	{
		  0,1,2,
		  3,4,5,
		  6,7,8
	} ;

	int zero = p[0][0] ;
	int one = p[0][1] ;
	int two	= p[0][2] ;
	int three = p[1][0] ;
	int four = p[1][1] ;
	int five = p[1][2] ;
	int six = p[2][0] ;
	int seven = p[2][1] ;
	int eight = p[2][2] ;

	// attempt to win
	if ( ( arr[zero] == EMPTY && arr[one] == EX   && arr[two] == EX ) ||
	     ( arr[zero] == EMPTY && arr[three] == EX && arr[six] == EX ) ||
	     ( arr[zero] == EMPTY && arr[four] == EX   && arr[eight] == EX ) )
	{
		arr[zero] = EX ;
		drawex ( zero ) ;
		didcomputerwin( ) ;
		return ;
	}

	if ( ( arr[one] == EMPTY && arr[zero] == EX && arr[two] == EX ) ||
	     ( arr[one] == EMPTY && arr[four] == EX && arr[seven] == EX ) )
	{
		arr[one] = EX ;
		drawex ( one ) ;
		didcomputerwin( ) ;
		return ;
	}

	if ( ( arr[two] == EMPTY && arr[zero] == EX && arr[one] == EX ) ||
	     ( arr[two] == EMPTY && arr[five] == EX  && arr[eight] == EX ) ||
	     ( arr[two] == EMPTY && arr[four] == EX && arr[six] == EX ) )
	{
		arr[two] = EX ;
		drawex ( two ) ;
		didcomputerwin( ) ;
		return ;
	}

	if ( ( arr[three] == EMPTY && arr[four] == EX  && arr[five] == EX ) ||
	     ( arr[three] == EMPTY && arr[zero] == EX && arr[six] == EX ) )
	{
		arr[three] = EX ;
		drawex ( three ) ;
		didcomputerwin( ) ;
		return ;
	}

	if ( ( arr[four] == EMPTY && arr[three] == EX && arr[five] == EX ) ||
	     ( arr[four] == EMPTY && arr[one] == EX   && arr[seven] == EX ) ||
	     ( arr[four] == EMPTY && arr[zero] == EX  && arr[eight] == EX ) )
	{
		arr[four] = EX ;
		drawex ( four ) ;
		didcomputerwin( ) ;
		return ;
	}

	if ( ( arr[five] == EMPTY && arr[three] == EX && arr[four] == EX ) ||
	     ( arr[five] == EMPTY && arr[two] == EX   && arr[eight] == EX ) )
	{
		arr[five] = EX ;
		drawex ( five ) ;
		didcomputerwin( ) ;
		return ;
	}

	if ( ( arr[six] == EMPTY && arr[seven] == EX && arr[eight] == EX ) ||
	     ( arr[six] == EMPTY && arr[zero] == EX    && arr[three] == EX ) ||
	     ( arr[six] == EMPTY && arr[four] == EX     && arr[two] == EX ) )
	{
		arr[six] = EX ;
		drawex ( six ) ;
		didcomputerwin( ) ;
		return ;
	}

	if ( ( arr[seven] == EMPTY && arr[six] == EX   && arr[eight] == EX ) ||
	     ( arr[seven] == EMPTY && arr[one] == EX && arr[four] == EX ) )
	{
		arr[seven] = EX ;
		drawex ( seven ) ;
		didcomputerwin( ) ;
		return ;
	 }

	if ( ( arr[eight] == EMPTY && arr[six] == EX   && arr[seven] == EX ) ||
	     ( arr[eight] == EMPTY && arr[two] == EX  && arr[five] == EX ) ||
	     ( arr[eight] == EMPTY && arr[zero] == EX && arr[four] == EX ) )
	{
		arr[eight] = EX ;
		drawex ( eight ) ;
		didcomputerwin( ) ;
		return ;
	}

	// attempt not to lose
	if ( ( arr[zero] == EMPTY && arr[one] == OH   && arr[two] == OH ) ||
	     ( arr[zero] == EMPTY && arr[three] == OH && arr[six] == OH ) ||
	     ( arr[zero] == EMPTY && arr[four] == OH   && arr[eight] == OH ) )
	{
		arr[zero] = EX ;
		drawex ( zero ) ;
		didcomputerwin( ) ;
		return ;
	 }

	if ( ( arr[one] == EMPTY && arr[zero] == OH && arr[two] == OH ) ||
	     ( arr[one] == EMPTY && arr[four] == OH  && arr[seven] == OH ) )
	{
		arr[one] = EX ;
		drawex ( one ) ;
		didcomputerwin( ) ;
		return ;
	}

	if ( ( arr[two] == EMPTY && arr[zero] == OH && arr[one] == OH ) ||
	     ( arr[two] == EMPTY && arr[five] == OH   && arr[eight] == OH ) ||
	     ( arr[two] == EMPTY && arr[four] == OH  && arr[six] == OH ) )
	 {
		arr[two] = EX ;
		drawex ( two ) ;
		didcomputerwin( ) ;
		return ;
	 }

	if ( ( arr[three] == EMPTY && arr[four] == OH  && arr[five] == OH ) ||
	     ( arr[three] == EMPTY && arr[zero] == OH && arr[six] == OH ) )
	{
		arr[three] = EX ;
		drawex ( three ) ;
		didcomputerwin( ) ;
		return ;
	}

	if ( ( arr[four] == EMPTY && arr[three] == OH && arr[five] == OH ) ||
	     ( arr[four] == EMPTY && arr[one] == OH   && arr[seven] == OH ) ||
	     ( arr[four] == EMPTY && arr[zero] == OH  && arr[eight] == OH ) )
	{
		arr[four] = EX ;
		drawex ( four ) ;
		didcomputerwin( ) ;
		return ;
	}

	if ( ( arr[five] == EMPTY && arr[three] == OH && arr[four] == OH ) ||
	     ( arr[five] == EMPTY && arr[two] == OH    && arr[eight] == OH ) )
	{
		arr[five] = EX ;
		drawex ( five ) ;
		didcomputerwin( ) ;
		return ;
	}

	if ( ( arr[six] == EMPTY && arr[seven] == OH && arr[eight] == OH ) ||
	     ( arr[six] == EMPTY && arr[zero] == OH    && arr[three] == OH ) ||
	     ( arr[six] == EMPTY && arr[four] == OH     && arr[two] == OH ) )
	{
		arr[six] = EX ;
		drawex ( six ) ;
		didcomputerwin( ) ;
		return ;
	}

	if ( ( arr[seven] == EMPTY && arr[six] == OH   && arr[eight] == OH ) ||
	     ( arr[seven] == EMPTY && arr[one] == OH && arr[four] == OH ) )
	{
		arr[seven] = EX ;
		drawex ( seven ) ;
		didcomputerwin( ) ;
		return ;
	}

	if ( ( arr[eight] == EMPTY && arr[six] == OH   && arr[seven] == OH ) ||
	     ( arr[eight] == EMPTY && arr[two] == OH  && arr[five] == OH ) ||
	     ( arr[eight] == EMPTY && arr[zero] == OH && arr[four] == OH ) )
	{
		arr[eight] = EX ;
		drawex ( eight ) ;
		didcomputerwin( ) ;
		return ;
	}

	// occupy center
	if ( arr[four] == EMPTY )
	{
		arr[four] = EX ;
		drawex ( four ) ;
		didcomputerwin( ) ;
		return ;
	}

	// occupy first available corner
	if ( arr[zero] == EMPTY )
	{
		arr[zero] = EX ;
		drawex ( zero ) ;
		didcomputerwin( ) ;
		return ;
	}

	if ( arr[two] == EMPTY )
	{
		arr[two] = EX ;
		drawex ( two ) ;
		didcomputerwin( ) ;
		return ;
	}

	if ( arr[six] == EMPTY )
	{
		arr[six] = EX ;
		drawex ( six ) ;
		didcomputerwin( ) ;
		return ;
	}

	if ( arr[eight] == EMPTY )
	{
		arr[eight] = EX ;
		drawex ( eight ) ;
		didcomputerwin( ) ;
		return ;
	}

	// occupy empty slot
	for ( int i = 0 ; i <= 8 ; i++ )
	{
		if ( arr[i] == EMPTY )
		{
			arr[i] = EX ;
			drawex ( i ) ;
			didcomputerwin( ) ;
			break ;
		}
	}
}					

int myframe::diduserwin( )
{
	int winner ;
	winner = findwinner( ) ;

	if ( winner == OH )
	{
		MessageBox ( " O won the game !! ", "Result..." ) ;
		resetgame( ) ;
		return 1 ;
	}
	else
		return 0 ;
}
			
int myframe::isgamedrawn( )
{
	for ( int i = 0 ; i <= 8 ; i++ )
	{
		if ( arr[i] == EMPTY )
			return 0 ;
	} 
	
	MessageBox ( " Game is drawn !! ", "Result..." ) ;
	resetgame( ) ;
	return 1 ;
}
			
void myframe::didcomputerwin( )
{
	int winner ;
	winner = findwinner( ) ;
		
	if ( winner == EX )
	{
		MessageBox ( " computer won the game !! ", "Result..." ) ;
		resetgame( ) ;
	}
}

int myframe::findwinner( )
{
	int pattern[8][3] = {
							0,1,2,
							3,4,5,
							6,7,8,
							0,3,6,
							1,4,7,
							2,5,8,
							0,4,8,
							2,4,6,
						} ;
	int i ;
	
	for ( i = 0 ; i <= 7 ; i++ )
	{
		if ( arr [pattern [i][0]] == OH && arr [pattern[i][1]] == OH && arr[pattern[i][2]] == OH )
				return OH ;

		if( arr [pattern[i][0]] == EX && arr[pattern[i][1]] == EX && arr[pattern[i][2]] == EX )
				return EX ;
	}

	return 0 ;
}

void myframe::OnLButtonDblClk ( UINT flags,CPoint p )
{
	CClientDC d ( this ) ;
			
	if ( d.GetPixel ( p ) == RGB (0, 0, 0 ) )
		MessageBox ( " press ok to resart the game " ) ;

	resetgame( ) ;
	Invalidate( ) ;
}

void myframe::resetgame( )
{
	for ( int i = 0 ; i <= 8 ; i++ )
		arr[i] = EMPTY ;
					
	Invalidate( ) ;
	return ;
}
