#include "afxwin.h"
#include "myapp.h"
#include "drawwnd.h"

BEGIN_MESSAGE_MAP ( drawwnd, CWnd )

	ON_WM_TIMER( )
	ON_WM_CREATE( )

END_MESSAGE_MAP( )

drawwnd::drawwnd ( BOOL deleteflag )
{
	m_deleteflag = deleteflag ;

	m_shape = AfxGetApp( ) -> GetProfileInt ( "Config", "Shape", 0 ) ;
	m_fillstyle = AfxGetApp( ) -> GetProfileInt ( "Config", "FillStyle", 0 ) ;

	for ( int i = 0 ; i < 10 ; i++ )
		s[i].x = s[i].y = -1 ;

	setdrawingtool ( m_shape, m_fillstyle ) ;
	currentnum = 0 ;
}

BOOL drawwnd::Create ( DWORD exstyle, DWORD style, const RECT& r, 
						CWnd *p, UINT id, CCreateContext *pc ) 
{
	CBrush mybrush ( RGB ( 0, 0, 0 ) ) ;

	CString mywindowclass ;
	mywindowclass = AfxRegisterWndClass ( CS_HREDRAW | CS_VREDRAW, 
										AfxGetApp( ) -> LoadCursor ( IDC_NULLCURSOR ), 
										mybrush, 0 ) ;

	return CreateEx ( exstyle, mywindowclass, "", style, 
						r.left, r.top, r.right - r.left, r.bottom - r.top, 
						p -> GetSafeHwnd( ), NULL, NULL ) ;
}

int drawwnd::OnCreate ( LPCREATESTRUCT l ) 
{
	CWnd::OnCreate ( l ) ;
	SetTimer ( 1, 10, NULL ) ;
	return 0 ;
}

void drawwnd::setdrawingtool ( int sh, int fs )
{
	COLORREF color ;
	int i ;

	m_shape = sh ;
	m_fillstyle = fs ;

	for ( i = 0 ; i <= 9 ; i++ )
		s[i].mybrush.DeleteObject( ) ;

	switch ( m_fillstyle )
	{
		case 0 :

			for ( i = 0 ; i <= 9 ; i++ )
			{
				color = RGB ( rand( ) % 255, rand( ) % 255, rand( ) % 255 ) ;
				s[i].mybrush.CreateSolidBrush ( color ) ;
			}

			break ;

		case 1 :

			for ( i = 0 ; i <= 9 ; i++ )
			{
				color = RGB ( rand( ) % 255, rand( ) % 255, rand( ) % 255 ) ;
				s[i].mybrush.CreateHatchBrush ( HS_CROSS, color ) ;
			}
			
			break ;

		case 2 :

			for ( i = 0 ; i <= 9 ; i++ )
				s[i].mybrush.CreateSolidBrush ( RGB ( 0, 255, 0 ) ) ;
			
			break ;
	}
}

void drawwnd::OnTimer ( UINT id ) 
{
	CClientDC *dc ;
	dc = new CClientDC ( this ) ;

	CRect rect ;
	GetClientRect ( &rect ) ;

	draw ( dc, rect ) ;

	delete dc ;
}

void drawwnd::draw ( CDC* dc, CRect rr ) 
{
	CRect r ;
	int  SQUARESIZE ;
	CBrush brush ( RGB ( 0, 0, 0 ) ) ;

	SQUARESIZE = rr.right / 25 ;
	if ( s[currentnum].x != -1 )
	{
		r.left = s[currentnum].x ;
		r.top = s[currentnum].y ;
		r.right = s[currentnum].x + SQUARESIZE ;
		r.bottom = s[currentnum].y + SQUARESIZE ;

		dc -> FillRect ( &r, &brush ) ;
	}

	srand ( LOWORD ( GetCurrentTime( ) ) ) ;
	s[currentnum].x = rand( ) % rr.right ;
	s[currentnum].y = rand( ) % rr.bottom ;
			
	r.left = s[currentnum].x ;
	r.top = s[currentnum].y ;
	r.right = s[currentnum].x + SQUARESIZE ;
	r.bottom = s[currentnum].y + SQUARESIZE ;

	dc -> SelectObject ( &s[currentnum].mybrush ) ;

	switch ( m_shape )
	{
		case 0 :

			dc -> Ellipse ( r ) ;
			break ;

		case 1 :

			dc -> Rectangle ( r ) ;
			break ;
	}

	currentnum = ++currentnum % 10 ;
}

void drawwnd::PostNcDestroy( ) 
{
	if ( m_deleteflag )
		delete this ;
}
