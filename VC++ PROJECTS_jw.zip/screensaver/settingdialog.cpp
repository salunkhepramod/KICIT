#include "afxwin.h"
#include "myapp.h"
#include "drawwnd.h"
#include "settingdialog.h"

BEGIN_MESSAGE_MAP ( settingdialog, CDialog )

	ON_CBN_SELENDOK ( IDC_SHAPE, newshapestyle )
	ON_CBN_SELENDOK ( IDC_FILLSTYLE, newshapestyle )

END_MESSAGE_MAP( )

settingdialog::settingdialog( ) : CDialog ( IDD_SAVER_DIALOG ), m_preview ( FALSE )
{
}

BOOL settingdialog::OnInitDialog( )
{
	m_shape = AfxGetApp( ) -> GetProfileInt ( "Config", "Shape", 0 ) ;
	m_fillstyle = AfxGetApp( ) -> GetProfileInt ( "Config", "FillStyle", 0 ) ;

	CDialog::OnInitDialog( ) ;

	CRect r ;
	CStatic *s = ( CStatic * ) GetDlgItem ( IDC_PREVIEW ) ;
	s -> GetWindowRect ( &r ) ;
	ScreenToClient ( &r ) ;

	m_preview.Create ( NULL, WS_VISIBLE | WS_CHILD, r, this, NULL ) ;

	CenterWindow( ) ;

	return TRUE ;
}

void settingdialog::DoDataExchange ( CDataExchange* pdx )
{
	CDialog::DoDataExchange ( pdx ) ;
	
	DDX_Control ( pdx, IDC_SHAPE, m_shapecombo ) ;
	DDX_Control ( pdx, IDC_FILLSTYLE, m_fillstylecombo ) ;

	DDX_CBIndex ( pdx, IDC_SHAPE, m_shape ) ;
	DDX_CBIndex ( pdx, IDC_FILLSTYLE, m_fillstyle ) ;
}

void settingdialog::newshapestyle( ) 
{
	int cors ;
	cors = m_shapecombo.GetCurSel( ) ;

	int sorhorp ;
	sorhorp = m_fillstylecombo.GetCurSel( ) ;

	m_preview.setdrawingtool ( cors, sorhorp ) ;
}

void settingdialog::OnOK( )
{
	CDialog::OnOK( ) ;
	AfxGetApp( ) -> WriteProfileInt ( "Config", "Shape", m_shape ) ;
	AfxGetApp( ) -> WriteProfileInt ( "Config", "FillStyle", m_fillstyle ) ;
}