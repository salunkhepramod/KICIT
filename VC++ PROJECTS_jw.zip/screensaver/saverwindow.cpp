#include "afxwin.h"
#include "myapp.h"
#include "drawwnd.h"
#include "saverwindow.h"

BEGIN_MESSAGE_MAP ( saverwindow, drawwnd )

	ON_WM_SYSCOMMAND( )
	ON_WM_DESTROY( )
	ON_WM_SETCURSOR( )
	ON_WM_NCACTIVATE( )
	ON_WM_ACTIVATE( )
	ON_WM_ACTIVATEAPP( )
	ON_WM_MOUSEMOVE( )
	ON_WM_LBUTTONDOWN( )
	ON_WM_MBUTTONDOWN( )
	ON_WM_RBUTTONDOWN( )
	ON_WM_KEYDOWN( )
	ON_WM_SYSKEYDOWN( )

END_MESSAGE_MAP( )

saverwindow::saverwindow ( BOOL deleteflag ) : drawwnd ( deleteflag )
{
	lastpoint = CPoint ( -1, -1 ) ;
}

BOOL saverwindow::Create( ) 
{
	CRect r ;

	r.left = r.top = 0 ;
	r.right = ::GetSystemMetrics ( SM_CXSCREEN ) ;
	r.bottom = ::GetSystemMetrics ( SM_CYSCREEN ) ;

	return drawwnd::Create ( WS_EX_TOPMOST, WS_VISIBLE | WS_POPUP, r, NULL, 0, NULL ) ;
}

void saverwindow::OnSysCommand ( UINT id, LPARAM l ) 
{
	if ( ( id == SC_SCREENSAVE) || ( id == SC_CLOSE ) )
		return ;
	drawwnd::OnSysCommand ( id, l ) ;
}

void saverwindow::OnDestroy( ) 
{
	PostQuitMessage ( 0 ) ;
	drawwnd::OnDestroy( ) ;
}

BOOL saverwindow::OnSetCursor ( CWnd* w, UINT hittest, UINT message ) 
{
	SetCursor ( NULL ) ;
	return TRUE ;
}

BOOL saverwindow::OnNcActivate ( BOOL active ) 
{
	if ( !active )
		return FALSE ;

	return drawwnd::OnNcActivate ( active ) ;
}

void saverwindow::OnActivate ( UINT state, CWnd* w, BOOL flag ) 
{
	if ( state == WA_INACTIVE )
		PostMessage ( WM_CLOSE ) ;

	drawwnd::OnActivate ( state, w, flag ) ; 
}

void saverwindow::OnActivateApp ( BOOL active, HTASK t ) 
{
	if ( !active )
		PostMessage ( WM_CLOSE ) ;

	drawwnd::OnActivateApp ( active, t ) ;
}

void saverwindow::OnMouseMove ( UINT flags, CPoint pt ) 
{
	if ( lastpoint == CPoint ( -1, -1 ) )
		lastpoint = pt ;
	else if ( lastpoint != pt )
		PostMessage ( WM_CLOSE ) ;

	drawwnd::OnMouseMove ( flags, pt ) ;
}

void saverwindow::OnLButtonDown ( UINT flags, CPoint pt ) 
{
	PostMessage ( WM_CLOSE ) ;
	drawwnd::OnLButtonDown ( flags, pt ) ;
}

void saverwindow::OnMButtonDown ( UINT flags, CPoint pt ) 
{
	PostMessage ( WM_CLOSE ) ;
	drawwnd::OnMButtonDown ( flags, pt ) ;
}

void saverwindow::OnRButtonDown ( UINT flags, CPoint pt ) 
{
	PostMessage ( WM_CLOSE ) ;
	drawwnd::OnRButtonDown ( flags, pt ) ;
}

void saverwindow::OnKeyDown ( UINT ch, UINT count, UINT flags ) 
{
	PostMessage ( WM_CLOSE ) ;
	drawwnd::OnKeyDown ( ch, count, flags ) ;
}

void saverwindow::OnSysKeyDown ( UINT ch, UINT count, UINT flags ) 
{
	PostMessage ( WM_CLOSE ) ;
	drawwnd::OnSysKeyDown ( ch, count, flags ) ;
}
