class settingdialog : public CDialog
{
	private :

		drawwnd m_preview ;
		CComboBox m_shapecombo ;
		CComboBox m_fillstylecombo ;
		int	m_speed ;
		int	m_shape ;
		int	m_fillstyle ;

	public :

		settingdialog( ) ;
		virtual BOOL OnInitDialog( ) ;
		virtual void DoDataExchange ( CDataExchange* pdx ) ;
		void newshapestyle( ) ;
		void OnOK( ) ;

	DECLARE_MESSAGE_MAP( )
} ;
