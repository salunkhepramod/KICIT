class drawwnd : public CWnd
{
	private :
	
		struct square
		{
			int x, y, size ;
			CBrush mybrush ;
		} s[10] ;

		int m_shape ;
		int m_fillstyle ;
		
		int currentnum ;
	
		BOOL m_deleteflag ;

	public:
	
		drawwnd ( BOOL deleteflag ) ;

		BOOL Create ( DWORD exstyle, DWORD style, const RECT& r, 
						CWnd *p, UINT id, CCreateContext *pc=NULL ) ;
		int OnCreate ( LPCREATESTRUCT l ) ;
		void setdrawingtool ( int sh, int fs ) ;
		void OnTimer ( UINT id ) ;
		void draw ( CDC* dc, CRect rr ) ; 
		virtual void PostNcDestroy( ) ;

	DECLARE_MESSAGE_MAP( )
} ;

