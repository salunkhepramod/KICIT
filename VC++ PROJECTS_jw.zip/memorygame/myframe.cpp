#include "myframe.h"
#include "resource.h"

#define COMPUTER	1
#define USER		2
#define YES			3
#define NO			4

BEGIN_MESSAGE_MAP ( myframe, CFrameWnd )

	ON_WM_CREATE( )
	ON_COMMAND ( 101, newgame )
	ON_CONTROL_RANGE ( BN_CLICKED, 1, 25, usersmove )
	ON_COMMAND_RANGE ( 201, 202, sound )
	ON_UPDATE_COMMAND_UI_RANGE ( 201, 202, enable_disable )
	ON_COMMAND ( 301, about )

END_MESSAGE_MAP( )

myframe::myframe( )
{
	CString mywindowclass ;
	CBrush mybrush ;
	mybrush.CreateStockObject ( LTGRAY_BRUSH ) ;

	mywindowclass = AfxRegisterWndClass ( CS_HREDRAW | CS_VREDRAW, 0, mybrush, AfxGetApp( ) -> LoadIcon ( IDI_ICON1 ) ) ;
	Create ( mywindowclass, "Memory Game", WS_OVERLAPPED | WS_SYSMENU | WS_MINIMIZE, CRect ( 150, 130, 150 + 250 + 10, 130 + 250 + 38 + 10 ), 0, MAKEINTRESOURCE ( IDR_MENU1 ) ) ;
}

int myframe::OnCreate ( LPCREATESTRUCT l )
{
	CFrameWnd::OnCreate ( l ) ;

	int x1 = 0, y1 = 0, x2, y2 ;

	for ( int i = 0 ; i <= 24 ; i++ )
	{
		x2 = x1 + 50 ;
		y2 = y1 + 50 ;
		m_b[i].Create ( "", WS_CHILD | WS_VISIBLE | BS_OWNERDRAW, CRect ( x1, y1, x2, y2 ), this, i + 1 ) ;
		m_b[i].LoadBitmaps ( IDB_BITMAP1 + i, IDB_BITMAP26 + i, 0, 0 ) ;

		x1 += 50 ;
		if ( ( i + 1 ) % 5 == 0 )
		{
			x1 = 0 ;
			y1 += 50 ;
		}
	}

	m_turn = COMPUTER ;
	m_state = YES ;

	return 0 ;
}

void myframe::newgame( )
{
	m_turn = COMPUTER ;
	computersmove ( 1 ) ;
}

void myframe::computersmove ( int count )
{
	int r ;

	m_no_buttons_computer_played = 0 ;
	m_no_buttons_user_played = 0 ;

	for ( int i = 0 ; i <= 49 ; i++ )
	{
		m_computerplayed[i] = 0 ;
		m_userplayed[i] = 0 ;
	}

	srand ( ( unsigned ) time ( NULL ) ) ;

	for ( i = 0 ; i < count ; i++ )
	{
		r = rand( ) % 25 ;

		m_b[r].SetState ( 1 ) ;
		Sleep ( 500 ) ;
		m_b[r].SetState ( 0 ) ;

		if ( m_state == YES )
			::MessageBeep ( 1 ) ;

		m_computerplayed[i] = r ;
	}

	m_no_buttons_computer_played = count ;
	m_turn = USER ;
}

void myframe::usersmove ( int id ) 
{
	if ( m_turn != USER ) // m_turn == COMPUTER
	{
		MessageBox ( "Not Your Turn, Start New Game" ) ;
		return ;
	}

	if ( m_no_buttons_user_played != m_no_buttons_computer_played )
	{
		m_userplayed[m_no_buttons_user_played] = id - 1 ;

		if ( m_state == YES )
			::MessageBeep ( 1 ) ;

		if ( m_userplayed[m_no_buttons_user_played] != m_computerplayed[m_no_buttons_user_played] )
		{
			MessageBox ( "Game Over.\nSelect 'New' to start a new game." ) ;
			m_turn = COMPUTER ;
			return ;
		}
		else
			m_no_buttons_user_played++ ;
	}

	if ( m_no_buttons_user_played == m_no_buttons_computer_played )
	{
		m_turn = COMPUTER ;
		m_no_buttons_computer_played++ ;
		MessageBox ( "\tGrand!!!\nNow it is computer's turn." ) ;
		computersmove ( m_no_buttons_computer_played ) ;
	}
}

void myframe::sound ( int id )
{
	switch ( id )
	{
		case 201 :
			m_state = YES ;
			break ;
		
		case 202 :
			m_state = NO ;
			break ;
	}
}

void myframe::enable_disable ( CCmdUI *item )
{
	switch ( item -> m_nID )
	{
		case 201 :

			if ( m_state == YES )
				item -> Enable ( FALSE ) ;
			else
				item -> Enable ( TRUE ) ;

			break ;

		case 202 :

			if ( m_state == NO )
				item -> Enable ( FALSE ) ;
			else
				item -> Enable ( TRUE ) ;

			break ;
	}
}

void myframe::about( )
{
	CDialog d ( IDD_DIALOG1 ) ;
	d.DoModal( ) ;
}
