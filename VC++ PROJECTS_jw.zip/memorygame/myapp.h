#include <afxwin.h>

class myapp : public CWinApp
{
	public :
		
		int InitInstance( ) ;
} ;
