//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by memorygame.rc
//
#define IDR_MENU1                       101
#define IDB_BITMAP1                     108
#define IDB_BITMAP2                     109
#define IDB_BITMAP3                     110
#define IDB_BITMAP4                     111
#define IDB_BITMAP5                     112
#define IDB_BITMAP6                     113
#define IDB_BITMAP7                     114
#define IDB_BITMAP8                     115
#define IDB_BITMAP9                     116
#define IDB_BITMAP10                    117
#define IDB_BITMAP11                    118
#define IDB_BITMAP12                    119
#define IDB_BITMAP13                    120
#define IDB_BITMAP14                    121
#define IDB_BITMAP15                    122
#define IDB_BITMAP16                    123
#define IDB_BITMAP17                    124
#define IDB_BITMAP18                    125
#define IDB_BITMAP19                    126
#define IDB_BITMAP20                    127
#define IDB_BITMAP21                    128
#define IDB_BITMAP22                    129
#define IDB_BITMAP23                    130
#define IDB_BITMAP24                    131
#define IDB_BITMAP25                    132
#define IDB_BITMAP26                    136
#define IDB_BITMAP27                    137
#define IDB_BITMAP28                    138
#define IDB_BITMAP29                    139
#define IDB_BITMAP30                    140
#define IDB_BITMAP31                    141
#define IDB_BITMAP32                    142
#define IDB_BITMAP33                    143
#define IDB_BITMAP34                    144
#define IDB_BITMAP35                    145
#define IDB_BITMAP36                    146
#define IDB_BITMAP37                    147
#define IDB_BITMAP38                    148
#define IDB_BITMAP39                    149
#define IDB_BITMAP40                    150
#define IDB_BITMAP41                    151
#define IDB_BITMAP42                    152
#define IDB_BITMAP43                    153
#define IDB_BITMAP44                    154
#define IDB_BITMAP45                    155
#define IDB_BITMAP46                    156
#define IDB_BITMAP47                    157
#define IDB_BITMAP48                    158
#define IDB_BITMAP49                    159
#define IDB_BITMAP50                    160
#define IDD_DIALOG1                     168
#define IDI_ICON1                       169

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        171
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
