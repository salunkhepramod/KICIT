#include <afxwin.h>
#include <afxext.h>

class myframe : public CFrameWnd 
{
	private :

		CBitmapButton m_b[25] ;
		int m_turn ;
		int m_no_buttons_computer_played, m_no_buttons_user_played ;
		int m_computerplayed[50], m_userplayed[50] ;
		int m_state ;

	public :

		myframe( ) ;
		int OnCreate ( LPCREATESTRUCT l ) ;
		void newgame( ) ;
		void computersmove ( int count ) ;
		void usersmove ( int id ) ;
		void sound ( int id ) ;
		void enable_disable ( CCmdUI *item ) ;
		void about( ) ;

	DECLARE_MESSAGE_MAP( )
} ;
