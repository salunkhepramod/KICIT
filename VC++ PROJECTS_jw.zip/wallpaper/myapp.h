class myapp : public CWinApp
{
	public :
	
		int InitInstance( ) ;
		void setnextwallpaper( ) ;
		void setnextstartupsound( ) ;
} ;
