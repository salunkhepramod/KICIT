class mydialog : public CDialog
{
	private :

		CListBox *lb, *ls ;
		CButton *b ;
		mytooltipctrl tip ;
		CBitmapButton rbok, rbcl ;

	public :

		mydialog( ) ;
		int OnEraseBkgnd ( CDC *p ) ;
		int OnInitDialog( ) ;
		void getregbitmap( ) ;
		int getregstyle( ) ;
		void getregsound( ) ;
		void addbitmaps( ) ;
		void addsounds( ) ;
		void delbitmaps( ) ;
		void delsounds( ) ;
		void OnOK( ) ;

	DECLARE_MESSAGE_MAP( )
} ;
