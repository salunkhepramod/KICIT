#include <afxwin.h>
#include <afxext.h>
#include <afxcmn.h>
#include "globalfunc.h"
#include "mytooltipctrl.h"
#include "mydialog.h"

#include "resource.h"

BEGIN_MESSAGE_MAP ( mydialog, CDialog )

	ON_WM_ERASEBKGND( )
	ON_COMMAND ( IDC_ADDBITMAPS, addbitmaps ) 
	ON_COMMAND ( IDC_DELBITMAPS, delbitmaps ) 

	ON_COMMAND ( IDC_ADDSOUNDS, addsounds ) 
	ON_COMMAND ( IDC_DELSOUNDS, delsounds ) 

END_MESSAGE_MAP( )

mydialog::mydialog( ) : CDialog ( IDD_DIALOG1 )
{
}

int mydialog::OnEraseBkgnd ( CDC *p )
{
	CBitmap mybitmap ;
	mybitmap.LoadBitmap ( IDB_BITMAP1 ) ;
	CDC mymemdc ;
	mymemdc.CreateCompatibleDC ( p ) ;
	mymemdc.SelectObject ( &mybitmap ) ;

	CRect r ;
	GetClientRect ( &r ) ;

	for ( int x = 0 ; x <= r.right ; x += 20 )
		for ( int y = 0 ; y <= r.bottom ; y += 20 )
			p -> BitBlt ( x, y, 20, 20, &mymemdc, 0, 0, SRCCOPY ) ;

	return 1 ;
}

int mydialog::OnInitDialog( )
{
	lb = ( CListBox * ) GetDlgItem ( IDC_LIST1 ) ;
	ls = ( CListBox * ) GetDlgItem ( IDC_LIST2 ) ;

	tip.Create ( this ) ;
	tip.addtool ( lb, "List of bitmap files" ) ;
	tip.addtool ( ls, "List of sound files" ) ;

	b = ( CButton * ) GetDlgItem ( IDC_ADDBITMAPS ) ;
	tip.addtool ( b, "Add Bitmaps" ) ;

	b = ( CButton * ) GetDlgItem ( IDC_DELBITMAPS ) ;
	tip.addtool ( b, "Delete Bitmaps" ) ;
			
	b = ( CButton * ) GetDlgItem ( IDC_ADDSOUNDS ) ;
	tip.addtool ( b, "Add Sounds" ) ;
			
	b = ( CButton * ) GetDlgItem ( IDC_DELSOUNDS ) ;
	tip.addtool ( b, "Delete Sounds" ) ;

	getregbitmap( ) ;

	if ( getregstyle( ) == 1 )
		CheckRadioButton ( IDC_RADIO1, IDC_RADIO2, IDC_RADIO2 ) ;
	else
		CheckRadioButton ( IDC_RADIO1, IDC_RADIO2, IDC_RADIO1 ) ;

	getregsound( ) ;

	lb -> SetCurSel ( 0 ) ;
	ls -> SetCurSel ( 0 ) ;

	rbok.Create ( "", WS_CHILD | WS_VISIBLE | BS_OWNERDRAW, CRect ( 200, 300, 248, 348 ), this, IDOK ) ;
	rbok.LoadBitmaps ( IDB_BITMAP2, IDB_BITMAP3, NULL, NULL ) ;
	rbcl.Create ( "", WS_CHILD | WS_VISIBLE | BS_OWNERDRAW, CRect ( 300, 300, 348, 348 ), this, IDCANCEL ) ;
	rbcl.LoadBitmaps ( IDB_BITMAP4, IDB_BITMAP5, NULL, NULL ) ;

	tip.addtool ( &rbok, "Ok" ) ;
	tip.addtool ( &rbcl, "Cancel" ) ;

	return 1 ;
}

void mydialog::getregbitmap( )
{
	CString str_hkey = "Software\\Amazing\\wallpaper\\CurrentVersion\\bitmap" ;
	HKEY hkeyresult ;

	if ( RegOpenKey ( HKEY_CURRENT_USER, ( LPCTSTR ) str_hkey, &hkeyresult ) != ERROR_SUCCESS )
		return ;

	BYTE count ;
	DWORD size = sizeof ( DWORD ) ;

	if ( RegQueryValueEx ( hkeyresult, ( LPCTSTR ) "COUNT", 0, 0, &count, &size ) != ERROR_SUCCESS  ) 
	{
		RegCloseKey ( hkeyresult ) ;
		return ;
	}

	CString s ;
	BYTE pathname[255] ;

	for ( int i = 0 ; i < count ; i++ )
	{
		s.Format ( "BITMAP%d", i ) ;

		size = 255 ;
		RegQueryValueEx ( hkeyresult, ( LPCTSTR ) s, 0, 0, pathname, &size ) ;

		lb -> AddString ( ( LPCTSTR ) pathname ) ;
	}

	RegCloseKey ( hkeyresult ) ;
}

int mydialog::getregstyle( )
{
	HKEY hkeyresult ;
	CString str_hkey = "Control Panel\\desktop" ;

	if ( RegOpenKey ( HKEY_CURRENT_USER, ( LPCTSTR ) str_hkey, &hkeyresult ) != ERROR_SUCCESS )
		return 0 ;

	BYTE value[2] ;
	DWORD size = 2 ;
	RegQueryValueEx ( hkeyresult, "TileWallpaper", 0, 0, value, &size ) ;
	RegCloseKey ( hkeyresult ) ;

	int style = atoi ( ( const char * ) value ) ;
	return style ;
}

void mydialog::getregsound( )
{
	CString str_hkey = "Software\\Amazing\\wallpaper\\CurrentVersion\\sound" ;
	HKEY hkeyresult ;

	if ( RegOpenKey ( HKEY_CURRENT_USER, ( LPCTSTR ) str_hkey, &hkeyresult ) != ERROR_SUCCESS )
		return ;

	BYTE count ;
	DWORD size = sizeof ( DWORD ) ;

	if ( RegQueryValueEx ( hkeyresult, ( LPCTSTR ) "COUNT", 0, 0, &count, &size ) != ERROR_SUCCESS  ) 
	{
		RegCloseKey ( hkeyresult ) ;
		return ;
	}

	CString s ;
	BYTE pathname[255] ;

	for ( int i = 0 ; i < count ; i++ )
	{
		s.Format ( "SOUND%d", i ) ;

		size = 255 ;
		RegQueryValueEx ( hkeyresult, ( LPCTSTR ) s, 0, 0, pathname, &size ) ;

		ls -> AddString ( ( LPCTSTR ) pathname ) ;
	}

	RegCloseKey ( hkeyresult ) ;
}

void mydialog::addbitmaps( )
{
	CFileDialog f ( TRUE, 0, 0, OFN_HIDEREADONLY | OFN_FILEMUSTEXIST | OFN_ALLOWMULTISELECT, "Bitmaps(*.bmp)|*.bmp||" ) ;
	f.m_ofn.lpstrTitle = "Wallpaper" ;

	if ( f.DoModal( ) == IDCANCEL ) 
		return ;
			
	POSITION pos ;
	pos = f.GetStartPosition( ) ;

	CString s ;
	while ( pos )
	{
		s = f.GetNextPathName ( pos ) ;
		if ( lb -> FindString ( -1, ( LPCTSTR ) s ) == LB_ERR )
			lb -> AddString ( ( LPCTSTR ) s ) ;
	}
}

void mydialog::addsounds( )
{
	CFileDialog f ( TRUE, 0, 0, OFN_HIDEREADONLY | OFN_FILEMUSTEXIST | OFN_ALLOWMULTISELECT, "Sounds(*.wav)|*.wav||" ) ;
	f.m_ofn.lpstrTitle = "Wallpaper" ;

	if ( f.DoModal( ) == IDCANCEL ) 
		return ;
			
	POSITION pos ;
	pos = f.GetStartPosition( ) ;

	CString s ;
	while ( pos )
	{
		s = f.GetNextPathName ( pos ) ;
		if ( ls -> FindString ( -1, ( LPCTSTR ) s ) == LB_ERR )
			ls -> AddString ( ( LPCTSTR ) s ) ;
	}
}

void mydialog::delbitmaps( )
{
	int a[200] ;
	
	int count = lb -> GetSelItems ( 200, a ) ;

	for ( int i = count - 1 ; i >= 0 ; i-- )
		lb -> DeleteString ( a[i] ) ;
}

void mydialog::delsounds( )
{
	int a[200] ;

	int count = ls -> GetSelItems ( 200, a ) ;

	for ( int i = count - 1 ; i >= 0 ; i-- )
		ls -> DeleteString ( a[i] ) ;
}

void mydialog::OnOK( )
{
	CDialog::OnOK( ) ;

	CString str_hkeybitmap = "Software\\Amazing\\wallpaper\\CurrentVersion\\bitmap" ;
	RegDeleteKey ( HKEY_CURRENT_USER, str_hkeybitmap ) ;
			
	CString str_hkeysound = "Software\\Amazing\\wallpaper\\CurrentVersion\\sound" ;
	RegDeleteKey ( HKEY_CURRENT_USER, str_hkeysound ) ;

	int index ;
	CString pathname ;

	int count = lb -> GetCount( ) ;

	for ( index = 0 ; index < count ; index++ )
	{
		lb -> GetText ( index, pathname ) ;

		CString str_childkey ;
		str_childkey.Format ( "BITMAP%d", index ) ;

		setregvalue ( HKEY_CURRENT_USER, str_hkeybitmap, str_childkey, pathname ) ;
	}

	setregvalue ( HKEY_CURRENT_USER, str_hkeybitmap, "COUNT", count ) ;
	setregvalue ( HKEY_CURRENT_USER, str_hkeybitmap, "NEXT", 0 ) ;

	CString s ;
	lb -> GetText ( 0, s ) ;
	CString str_hkey = "Control Panel\\desktop" ;
	setregvalue ( HKEY_CURRENT_USER, str_hkey, "Wallpaper", s ) ;

	int id = GetCheckedRadioButton ( IDC_RADIO1, IDC_RADIO2 ) ;
	CString style ;
	switch ( id )
	{
		case IDC_RADIO1 :

			style = "0" ;
			break ;

		case IDC_RADIO2 :

			style = "1" ;
			break ;
	}

	str_hkey = "Control Panel\\desktop" ;
	setregvalue ( HKEY_CURRENT_USER, str_hkey, "TileWallpaper", style ) ;
			
	count = ls -> GetCount( ) ;

	for ( index = 0 ; index < count ; index++ )
	{
		ls -> GetText ( index, pathname ) ;

		CString str_childkey ;
		str_childkey.Format ( "SOUND%d", index ) ;

		setregvalue ( HKEY_CURRENT_USER, str_hkeysound, str_childkey, pathname ) ;
	}

	setregvalue ( HKEY_CURRENT_USER, str_hkeysound, "COUNT", count ) ;
	setregvalue ( HKEY_CURRENT_USER, str_hkeysound, "NEXT", 0 ) ;

	ls -> GetText ( 0, s ) ;
	str_hkey = ".Default\\AppEvents\\Schemes\\Apps\\.Default\\SystemStart\\.current" ;
	setregvalue ( HKEY_USERS, str_hkey, "", s ) ;

	str_hkey = "Software\\Microsoft\\Windows\\CurrentVersion\\Run" ;
	s = ::GetCommandLine( ) ;
	s += " /change" ;

	setregvalue ( HKEY_LOCAL_MACHINE, str_hkey, "wallpaper", s ) ;
}
