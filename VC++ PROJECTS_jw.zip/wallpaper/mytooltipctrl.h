class mytooltipctrl : public CToolTipCtrl
{
	public :

		int addtool ( CWnd* pwnd, LPCTSTR text ) ;
		void OnWindowPosChanged ( WINDOWPOS FAR* lpwndpos ) ;

	DECLARE_MESSAGE_MAP( )
} ;
