void setregvalue ( HKEY hkey, CString str_hkey, CString str_childkey, DWORD childkeyvalue ) ;
void setregvalue ( HKEY hkey, CString str_hkey, CString str_childkey, CString childkeyvalue ) ;
