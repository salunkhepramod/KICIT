#include <afxwin.h>
#include <afxext.h>
#include <afxcmn.h> 
#include "globalfunc.h"
#include "mytooltipctrl.h"
#include "mydialog.h"
#include "myapp.h"

myapp a ;

int myapp::InitInstance( )
{
	CString str = ::GetCommandLine( ) ;

	if ( str.Find( " /change" ) > 0 ) 
	{
		setnextwallpaper( ) ;
		setnextstartupsound( ) ;
	}
	else
	{
		mydialog d ;
		d.DoModal( ) ;
	}

	return 0 ;
}

void myapp::setnextwallpaper( )
{
	CString str_hkey = "Software\\Amazing\\wallpaper\\CurrentVersion\\bitmap" ;
	HKEY hkeyresult ;

	if ( RegOpenKey ( HKEY_CURRENT_USER, ( LPCTSTR ) str_hkey, &hkeyresult ) != ERROR_SUCCESS )
		return ;

	BYTE count ;
	DWORD size = sizeof ( DWORD ) ;

	if ( RegQueryValueEx ( hkeyresult, ( LPCTSTR ) "COUNT", 0, 0, &count, &size ) != ERROR_SUCCESS  ) 
	{
		RegCloseKey ( hkeyresult ) ;
		return ;
	}

	BYTE index ;
	size = sizeof ( DWORD ) ;

	if ( RegQueryValueEx ( hkeyresult, ( LPCTSTR ) "NEXT", 0, 0, &index, &size ) != ERROR_SUCCESS ) 
	{
		RegCloseKey ( hkeyresult ) ;
		return ;
	}

	CString s ;
	s.Format ( "BITMAP%d", index ) ;
			
	BYTE pathname[255] ;
	size = 255 ;
	RegQueryValueEx ( hkeyresult, ( LPCTSTR ) s, 0, 0, pathname, &size ) ;

	RegCloseKey ( hkeyresult ) ;

	if ( index == count - 1 )
		index = 0 ;
	else
		index++ ;

	setregvalue ( HKEY_CURRENT_USER, str_hkey, "NEXT", index ) ;

	str_hkey = "Control Panel\\desktop" ;
	setregvalue ( HKEY_CURRENT_USER, str_hkey, "Wallpaper", (CString) pathname ) ;
}

void myapp::setnextstartupsound( )
{
	CString str_hkey = "Software\\Amazing\\wallpaper\\CurrentVersion\\sound" ;
	HKEY hkeyresult ;

	if ( RegOpenKey ( HKEY_CURRENT_USER, ( LPCTSTR ) str_hkey, &hkeyresult ) != ERROR_SUCCESS )
		return ;

	BYTE count ;
	DWORD size = sizeof ( DWORD ) ;

	if ( RegQueryValueEx ( hkeyresult, ( LPCTSTR ) "COUNT", 0, 0, &count, &size ) != ERROR_SUCCESS  ) 
	{
		RegCloseKey ( hkeyresult ) ;
		return ;
	}

	BYTE index ;
	size = sizeof ( DWORD ) ;

	if ( RegQueryValueEx ( hkeyresult, ( LPCTSTR ) "NEXT", 0, 0, &index, &size ) != ERROR_SUCCESS ) 
	{
		RegCloseKey ( hkeyresult ) ;
		return ;
	}

	CString s ;
	s.Format ( "SOUND%d", index ) ;

	BYTE pathname[255] ;
	size = 255 ;
	RegQueryValueEx ( hkeyresult, ( LPCTSTR ) s, 0, 0, pathname, &size ) ;

	RegCloseKey ( hkeyresult ) ;

	if ( index == count - 1 )
		index = 0 ;
	else
		index++ ;

	setregvalue ( HKEY_CURRENT_USER, str_hkey, "NEXT", index ) ;

	str_hkey = ".Default\\AppEvents\\Schemes\\Apps\\.Default\\SystemStart\\.current" ;
	setregvalue ( HKEY_USERS, str_hkey, "", ( CString ) pathname ) ;
}
