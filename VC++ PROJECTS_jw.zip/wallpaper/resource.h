//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by wallpaper.rc
//
#define IDD_DIALOG1                     101
#define IDB_BITMAP1                     103
#define IDB_BITMAP2                     104
#define IDB_BITMAP3                     105
#define IDB_BITMAP4                     106
#define IDB_BITMAP5                     107
#define IDC_LIST1                       1000
#define IDC_ADDBITMAPS                  1001
#define IDC_DELBITMAPS                  1002
#define IDC_LIST2                       1003
#define IDC_ADDSOUNDS                   1004
#define IDC_DELSOUNDS                   1005
#define IDC_RADIO1                      1006
#define IDC_RADIO2                      1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
