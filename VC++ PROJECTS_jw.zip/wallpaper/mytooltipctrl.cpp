#include <afxwin.h>
#include <afxcmn.h>
#include <mmsystem.h>
#include "mytooltipctrl.h"

BEGIN_MESSAGE_MAP ( mytooltipctrl, CToolTipCtrl )

	ON_WM_WINDOWPOSCHANGED( )

END_MESSAGE_MAP( )

int mytooltipctrl::addtool ( CWnd* pwnd, LPCTSTR text )
{
	TOOLINFO ti ;

	ti.cbSize = sizeof ( TOOLINFO ) ;
	ti.lpszText = ( LPTSTR ) text ;
	ti.hinst = AfxGetInstanceHandle ( ) ;
	ti.hwnd = pwnd -> GetParent( ) -> GetSafeHwnd( ) ;
	ti.uFlags = TTF_SUBCLASS | TTF_IDISHWND ;
	ti.uId = ( UINT ) pwnd -> GetSafeHwnd( ) ;

	return ( int ) SendMessage ( TTM_ADDTOOL, 0, ( LPARAM )&ti ) ;
}

void mytooltipctrl::OnWindowPosChanged ( WINDOWPOS FAR* lpwndpos )
{
	CToolTipCtrl::OnWindowPosChanged ( lpwndpos ) ;

	if ( lpwndpos -> flags & SWP_SHOWWINDOW )
		::PlaySound ( "music.wav", NULL, SND_FILENAME | SND_ASYNC ) ;
}
