class adddialog : public CDialog
{
	public :

		adddialog( ) ;
		int OnInitDialog( ) ;
		void OnOK( ) ;
} ;

