class categorydialog : public CDialog 
{
	public :

		CString m_filename ;

		categorydialog( ) ;
		int OnInitDialog( ) ;
		void OnOK( ) ;
} ;

