#include <afxwin.h>
#include "categorydialog.h"
#include "resource.h"

categorydialog::categorydialog( ) : CDialog ( IDD_DIALOG2 )
{
}

int categorydialog::OnInitDialog( )
{
	CheckRadioButton ( IDC_RADIO1, IDC_RADIO4, IDC_RADIO2 ) ;
	return 1 ;
}

void categorydialog::OnOK( )
{
	int rad ;
			
	rad = GetCheckedRadioButton ( IDC_RADIO1, IDC_RADIO4 ) ;
	CDialog::OnOK( ) ;

	switch ( rad )
	{
		case IDC_RADIO1 :
			m_filename = "office.jok" ;
			break ;

		case IDC_RADIO2 :
			m_filename = "party.jok" ;
			break ;

		case IDC_RADIO3 :
			m_filename = "teens.jok" ;
			break ;

		case IDC_RADIO4 :
			m_filename = "kids.jok" ;
			break ;
	}
}
