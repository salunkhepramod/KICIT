#include <afxwin.h>
#include "timerdialog.h"
#include "resource.h"

BEGIN_MESSAGE_MAP ( timerdialog, CDialog )
	ON_COMMAND ( IDC_KILLTIMER, killtimer )
END_MESSAGE_MAP( )

timerdialog::timerdialog ( BOOL n ) : CDialog ( IDD_DIALOG3 )
{
	m_timerstatus = n ;
}

int timerdialog::OnInitDialog( )
{
	CButton *kt ;
	kt = ( CButton * ) GetDlgItem ( IDC_KILLTIMER ) ;

	if ( m_timerstatus == TRUE )
	{
		CButton *r1 = ( CButton * ) GetDlgItem ( IDC_RADIO1 ) ;
		CButton *r2 = ( CButton * ) GetDlgItem ( IDC_RADIO2 ) ;
		CButton *r3 = ( CButton * ) GetDlgItem ( IDC_RADIO3 ) ;
		CButton *ok = ( CButton * ) GetDlgItem ( IDOK ) ;

		r1 -> EnableWindow ( FALSE ) ;
		r2 -> EnableWindow ( FALSE ) ;
		r3 -> EnableWindow ( FALSE ) ;
		ok -> EnableWindow ( FALSE ) ;

		kt -> EnableWindow ( TRUE ) ;
	}
	else
	{
		CheckRadioButton ( IDC_RADIO1, IDC_RADIO3, IDC_RADIO2 ) ;
		kt -> EnableWindow ( FALSE ) ;
	}

	return 1 ;
}

void timerdialog::OnOK( )
{
	int rad ;
			
	rad = GetCheckedRadioButton ( IDC_RADIO1, IDC_RADIO3 ) ;
	CDialog::OnOK( ) ;

	switch ( rad )
	{
		case IDC_RADIO1 :
					
			m_time = 60 * 60 * 1000 ;
			break ;
					
		case IDC_RADIO2 :
		
			m_time = 10 * 60 * 1000 ;
			break ;

		case IDC_RADIO3 :
			
			m_time = 5 * 60 * 1000 ;
			break ;
	}
}

void timerdialog::killtimer( )
{
	EndModalLoop ( IDC_KILLTIMER ) ;
}
