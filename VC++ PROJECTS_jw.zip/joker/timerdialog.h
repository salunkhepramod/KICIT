class timerdialog : public CDialog
{
	private :

		BOOL m_timerstatus ;

	public :
		
		int m_time ;

		timerdialog ( BOOL n ) ;
		int OnInitDialog( ) ;
		void OnOK( ) ;
		void killtimer( ) ;
	
	DECLARE_MESSAGE_MAP( )
} ;
