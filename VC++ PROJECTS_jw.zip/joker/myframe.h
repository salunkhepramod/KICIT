class myframe : public CFrameWnd 
{
	private :

		CToolBar m_t ;
		CStdioFile m_fp ;
		CString m_currentfile ;
		int m_count ;

		BOOL m_addingjoke, m_istimeron ;
		CFont m_myfont ;

	public :

		myframe( ) ;
		int OnCreate ( LPCREATESTRUCT l ) ;
		void writeontoolbar ( CCmdUI *item ) ;
		int OnEraseBkgnd ( CDC *pdc ) ;
		void draw ( CDC *p ) ;
		void addjoke( ) ;
		void category( ) ;
		void next( ) ;
		void previous( ) ;
		void timer( ) ;
		void OnTimer ( UINT n ) ;
		void minimize( ) ;
		void close( ) ;
		void about( ) ;
		void developedat( ) ;
		void help( ) ;

	DECLARE_MESSAGE_MAP()
} ;
