#include <afxwin.h>
#include <afxext.h>
#include "resource.h"

class adddialog : public CDialog
{
	public :

		adddialog( ) : CDialog ( IDD_DIALOG1 ) 
		{
		}

		int OnInitDialog( )
		{
			CheckRadioButton ( IDC_RADIO1, IDC_RADIO4, IDC_RADIO2 ) ;
			return 1 ;
		}

		void OnOK( )
		{
			int rad ;
			CString jokestring, filename ;
			CStdioFile ft ;

			rad = GetCheckedRadioButton ( IDC_RADIO1, IDC_RADIO4 ) ;
			GetDlgItemText ( IDC_EDIT1, jokestring ) ;

			CDialog::OnOK( ) ;

			if ( jokestring != "" ) 
			{
				switch ( rad )
				{
					case IDC_RADIO1 :
						filename = "office.jok" ;
						break ;

					case IDC_RADIO2 :
						filename = "party.jok" ;
						break ;
					
					case IDC_RADIO3 :
						filename = "teens.jok" ;
						break ;
					
					case IDC_RADIO4 :
						filename = "kids.jok" ;
						break ;
				}
		
				ft.Open ( filename, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeReadWrite ) ;
				ft.SeekToEnd( ) ;

				ft.WriteString ( "\r\nBEGIN\r\n" ) ;
				ft.WriteString ( jokestring ) ;
				ft.WriteString ( "\r\nEND\r\n" ) ;
				
				ft.Close( ) ;
			}
		}
} ;

class categorydialog : public CDialog 
{
	public :

		CString m_filename ;

		categorydialog( ) : CDialog ( IDD_DIALOG2 )
		{
		}

		int OnInitDialog( )
		{
			CheckRadioButton ( IDC_RADIO1, IDC_RADIO4, IDC_RADIO2 ) ;
			return 1 ;
		}

		void OnOK( )
		{
			int rad ;
			
			rad = GetCheckedRadioButton ( IDC_RADIO1, IDC_RADIO4 ) ;
			CDialog::OnOK( ) ;

			switch ( rad )
			{
				case IDC_RADIO1 :
					m_filename = "office.jok" ;
					break ;

				case IDC_RADIO2 :
					m_filename = "party.jok" ;
					break ;

				case IDC_RADIO3 :
					m_filename = "teens.jok" ;
					break ;

				case IDC_RADIO4 :
					m_filename = "kids.jok" ;
					break ;
			}
		}
} ;

class timerdialog : public CDialog
{
	private :

		BOOL m_timerstatus ;

	public :
		
		int m_time ;

		timerdialog ( BOOL n ) : CDialog ( IDD_DIALOG3 )
		{
			m_timerstatus = n ;
		}

		int OnInitDialog( )
		{
			CButton *kt ;
			kt = ( CButton * ) GetDlgItem ( IDC_KILLTIMER ) ;

			if ( m_timerstatus == TRUE )
			{
				CButton *r1 = ( CButton * ) GetDlgItem ( IDC_RADIO1 ) ;
				CButton *r2 = ( CButton * ) GetDlgItem ( IDC_RADIO2 ) ;
				CButton *r3 = ( CButton * ) GetDlgItem ( IDC_RADIO3 ) ;
				CButton *ok = ( CButton * ) GetDlgItem ( IDOK ) ;

				r1 -> EnableWindow ( FALSE ) ;
				r2 -> EnableWindow ( FALSE ) ;
				r3 -> EnableWindow ( FALSE ) ;
				ok -> EnableWindow ( FALSE ) ;

				kt -> EnableWindow ( TRUE ) ;
			}
			else
			{
				CheckRadioButton ( IDC_RADIO1, IDC_RADIO3, IDC_RADIO2 ) ;
				kt -> EnableWindow ( FALSE ) ;
			}

			return 1 ;
		}

		void OnOK( )
		{
			int rad ;
			
			rad = GetCheckedRadioButton ( IDC_RADIO1, IDC_RADIO3 ) ;
			CDialog::OnOK( ) ;

			switch ( rad )
			{
				case IDC_RADIO1 :
					
					m_time = 60 * 60 * 1000 ;
					break ;
					
				case IDC_RADIO2 :
					
					m_time = 10 * 60 * 1000 ;
					break ;

				case IDC_RADIO3 :
					
					m_time = 5 * 60 * 1000 ;
					break ;
			}
		}

		void killtimer( )
		{
			EndModalLoop ( IDC_KILLTIMER ) ;
		}
	
	DECLARE_MESSAGE_MAP( )
} ;

BEGIN_MESSAGE_MAP ( timerdialog, CDialog )
	ON_COMMAND ( IDC_KILLTIMER, killtimer )
END_MESSAGE_MAP( )

class myframe : public CFrameWnd 
{
	private :

		CToolBar m_t ;
		CStdioFile m_fp ;
		CString m_currentfile ;
		int m_count ;

		BOOL m_addingjoke, m_istimeron ;
		CFont m_myfont ;

	public :

		myframe( )
		{
			CString mywindowclass ;
			
			mywindowclass = AfxRegisterWndClass ( CS_HREDRAW | CS_VREDRAW,
				0, 0, AfxGetApp( ) -> LoadIcon ( IDI_ICON1 ) ) ;

			Create ( mywindowclass, "Joker" ) ;
		}

		int OnCreate ( LPCREATESTRUCT l )
		{
			CFrameWnd::OnCreate ( l ) ;

			m_t.Create ( this, WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_TOOLTIPS ) ;
			m_t.LoadToolBar ( IDR_TOOLBAR1 ) ;
	
			m_currentfile = "" ;
			m_count = 0 ;
			m_addingjoke = FALSE ;
			m_istimeron = FALSE ;

			m_myfont.CreateFont ( 25, 13, 0, 0, FW_NORMAL, 0, 0, 0, 0, 0, 0, 0, 0, "Arial" ) ;

			return 0 ;
		}

		void writeontoolbar ( CCmdUI *item )
		{
			POINT l ;
			CWindowDC d ( this ) ;
			CDC *memdc ;
			CBitmap mybitmap ;

			memdc = new CDC ;

			CRect r ;
		
			::GetCursorPos ( &l ) ;
			GetWindowRect ( &r ) ;
	
			if ( ( l.x >= r.left + 530 && l.x <= r.left + 530 + 55 ) && ( l.y >= r.top + 35 && l.y <= r.top + 35 + 50 ) )
			{
				mybitmap.LoadBitmap ( IDB_BITMAP3 ) ;

				memdc -> CreateCompatibleDC ( &d ) ;
				memdc -> SelectObject ( &mybitmap ) ;
			}
			else
			{
				mybitmap.LoadBitmap ( IDB_BITMAP2 ) ;

				memdc -> CreateCompatibleDC ( &d ) ;
				memdc -> SelectObject ( &mybitmap ) ;
			}

			d.BitBlt ( 530, 35, r.right - 530, 50, memdc, 0, 0, SRCCOPY ) ;

			delete memdc ;
		}

		int OnEraseBkgnd ( CDC *pdc )
		{
			draw ( pdc ) ;
			return 1 ;
		}

		void draw ( CDC *p )
		{
			CBitmap banana ;
			CDC bkmemdc ;
			CRect r ;
			int x, y ;

			banana.LoadBitmap ( IDB_BITMAP1 ) ;
			bkmemdc.CreateCompatibleDC ( p ) ;
			bkmemdc.SelectObject ( &banana ) ;

			GetClientRect ( &r ) ;

			for ( y = r.top + 65 ; y <= r.bottom ; y += 50 ) 
				for ( x = 0 ; x <= r.right ; x += 50 ) 
					p -> BitBlt ( x, y, 50, 50, &bkmemdc, 0, 0, SRCCOPY ) ;
		}

		void addjoke( )
		{
			adddialog a ;
			DWORD filepointerpos ;

			m_addingjoke = TRUE ;

			if ( m_currentfile != "" ) 
			{
				filepointerpos = m_fp.GetPosition( ) ;
				m_fp.Close( ) ;
				a.DoModal( ) ;
				m_fp.Open ( m_currentfile, CFile::modeRead ) ;
				m_fp.Seek ( filepointerpos, CFile::begin ) ;
			}
			else
				a.DoModal( ) ;

			m_addingjoke = FALSE ;
		}

		void category( )
		{
			categorydialog c ;
			DWORD filepos ;

			if ( c.DoModal( ) == IDOK )
			{
				if ( m_currentfile != "" ) 
				{
					filepos = m_fp.GetPosition( ) ;
					m_fp.Close( ) ;
				}

				if ( m_fp.Open ( c.m_filename, CFile::modeRead ) == 0 )
				{
					MessageBox ( "Jokes of this category does not exist", "Joking !" ) ;
					if ( m_currentfile != "" )
					{
						m_fp.Open ( m_currentfile, CFile::modeRead ) ;
						m_fp.Seek ( filepos, CFile::begin ) ;
					}
				}
				else
					m_currentfile = c.m_filename ;
			}
		}

		void next( )
		{
			char str[100] ;
			int y = 100, l ;

			if ( m_currentfile == "" ) 
			{
				MessageBox ( "Select Category", "Joking !" ) ;
				return ;
			}

			CClientDC d ( this ) ;

			d.SetBkMode ( TRANSPARENT ) ;
			d.SetTextColor ( RGB ( 255, 0, 0 ) ) ;
			d.SelectObject ( &m_myfont ) ;
					
			while ( m_fp.ReadString ( str, 99 ) != NULL )
			{
				l = strlen ( str ) ;
				str[l-2] = '\0' ;

				if ( strcmp ( str, "BEGIN" ) == 0 )
				{
					draw ( &d ) ;
					m_count++ ;
					continue ;
				}

				if ( strcmp ( str, "END" ) == 0 )
					return ;
			
				d.TextOut ( 100, y, str, strlen ( str ) ) ;
				y += 20 ;
			}

			if ( m_istimeron == TRUE )
			{
				m_fp.SeekToBegin( ) ;
				m_count = 0 ;
			}

			MessageBox ( "No More Jokes", "Joking!" ) ;
		}
		
		void previous( )
		{
			char str[100] ;
			int y = 100, l, i = 0 ;

			if ( m_currentfile == "" ) 
			{
				MessageBox ( "Select Category", "Joking !" ) ;
				return ;
			}

			if ( m_count == 1 ) 
				return ;

			CClientDC d ( this ) ;

			draw ( &d ) ;
			
			d.SetBkMode ( TRANSPARENT ) ;
			d.SetTextColor ( RGB ( 255, 0, 0 ) ) ;
			d.SelectObject ( &m_myfont ) ;

			m_fp.SeekToBegin( ) ;

			m_count-- ;
			while ( m_fp.ReadString ( str, 99 ) != NULL)
			{
				l = strlen ( str ) ;
				str[l-2] = '\0' ;

				if ( strcmp ( str, "BEGIN" ) == 0 )
					i++ ;
				
				if ( i == m_count ) 
					break ;
			}

			while ( m_fp.ReadString ( str, 99 ) != NULL)
			{
				l = strlen ( str ) ;
				str[l-2] = '\0' ;

				if ( strcmp ( str, "END" ) != 0 )
				{
					d.TextOut ( 100, y, str, strlen ( str ) ) ;
					y += 20 ;
				}
				else
					break ;
			}
		}

		void timer( )
		{
			if ( m_currentfile == "" )
			{
				MessageBox ( "Select Category", "Joking !" ) ;
				return ;
			}

			timerdialog t ( m_istimeron ) ;

			switch ( t.DoModal( ) )
			{
				case IDOK :

					SetTimer ( 1, t.m_time, NULL ) ;
					m_istimeron = TRUE ;
					ShowWindow ( 2 ) ;
					break ;

				case IDC_KILLTIMER :
					
					m_istimeron = FALSE ;
					KillTimer ( 1 ) ;
					break ;
			}
		}
		
		void OnTimer ( UINT n )
		{
			switch ( n )
			{
				case 1 :

					if ( m_addingjoke == TRUE )
						return ;
		
					ShowWindow ( 3 ) ;
					next( ) ;
					SetTimer ( 2, 30 * 1000, NULL ) ;
					break ;

				case 2 :

					ShowWindow ( 2 ) ;
					KillTimer ( 2 ) ;
			}
		}

		void minimize( )
		{
			ShowWindow ( 2 ) ;
		}
		
		void close( )
		{
			if ( m_currentfile != "" )
				m_fp.Close( ) ;

			DestroyWindow( ) ;
		}

		void about( )
		{
			CRect r ;
			GetWindowRect ( &r ) ;

			CMenu mymenu ;
			mymenu.CreatePopupMenu( ) ;

			mymenu.AppendMenu ( MF_STRING, 801, "&Developed At..." ) ;
			mymenu.AppendMenu ( MF_STRING, 802, "&Help... " ) ;
			
			mymenu.TrackPopupMenu ( TPM_CENTERALIGN, r.left + 440, r.top + 87, this, 0 ) ;
		}


		void developedat( )
		{
			MessageBox ( "Developed at ICIT", "Joking!" ) ;
		}

		void help( )
		{
			MessageBox ( "Just position the cursor on the toolbar buttons\n and you will understand everything", "Joking!" ) ;
		}

	DECLARE_MESSAGE_MAP()
} ;

BEGIN_MESSAGE_MAP ( myframe, CFrameWnd )

	ON_WM_CREATE( )
	ON_WM_ERASEBKGND( ) 

	ON_COMMAND ( 101, addjoke )
	ON_COMMAND ( 102, category )
	ON_COMMAND ( 103, next )
	ON_COMMAND ( 104, previous)
	ON_COMMAND ( 105, timer )
	ON_COMMAND ( 106, minimize )
	ON_COMMAND ( 107, close )

	ON_COMMAND ( 108, about )
	ON_COMMAND ( 801, developedat )
	ON_COMMAND ( 802, help )

	ON_UPDATE_COMMAND_UI ( 101, writeontoolbar ) 

	ON_WM_TIMER( )

END_MESSAGE_MAP() 

class myapp : public CWinApp
{
	public :

		int InitInstance( )
		{	
			myframe *b ;
			b = new myframe ;
			b -> ShowWindow ( 3 ) ;
			m_pMainWnd = b ;   
			
			return 1 ;
		}
} ;

myapp a ;

