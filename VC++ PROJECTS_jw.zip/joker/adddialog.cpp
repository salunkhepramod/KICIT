#include <afxwin.h>
#include "adddialog.h"
#include "resource.h"

adddialog::adddialog( ) : CDialog ( IDD_DIALOG1 ) 
{
}

int adddialog::OnInitDialog( )
{
	CheckRadioButton ( IDC_RADIO1, IDC_RADIO4, IDC_RADIO2 ) ;
	return 1 ;
}

void adddialog::OnOK( )
{
	int rad ;
	CString jokestring, filename ;
	CStdioFile ft ;

	rad = GetCheckedRadioButton ( IDC_RADIO1, IDC_RADIO4 ) ;
	GetDlgItemText ( IDC_EDIT1, jokestring ) ;

	CDialog::OnOK( ) ;

	if ( jokestring != "" ) 
	{
		switch ( rad )
		{
			case IDC_RADIO1 :
				filename = "office.jok" ;
				break ;

			case IDC_RADIO2 :
				filename = "party.jok" ;
				break ;
					
			case IDC_RADIO3 :
				filename = "teens.jok" ;
				break ;
					
			case IDC_RADIO4 :
				filename = "kids.jok" ;
				break ;
		}
		
		ft.Open ( filename, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeReadWrite ) ;
		ft.SeekToEnd( ) ;

		ft.WriteString ( "\r\nBEGIN\r\n" ) ;
		ft.WriteString ( jokestring ) ;
		ft.WriteString ( "\r\nEND\r\n" ) ;
				
		ft.Close( ) ;
	}
}
