#include <afxwin.h>

class tipdialog : public CDialog
{
	private :

		CStdioFile m_f ;
		int m_showtip ;

	public :

		tipdialog ( int n ) ;
		int OnInitDialog( ) ;
		void nexttip( ) ;
		HBRUSH OnCtlColor ( CDC* pDC, CWnd* pWnd, UINT nCtlColor ) ;
		void OnPaint() ;
		void OnOK( ) ;

	DECLARE_MESSAGE_MAP( )
} ;
