#include "resource.h"

#include "tipdialog.h"

tipdialog::tipdialog ( int n ):CDialog ( IDD_DIALOG1 )
{
	m_showtip = n ;
}

int tipdialog::OnInitDialog( )
{
	CheckDlgButton ( IDC_STARTUP, m_showtip ) ;
				
	m_f.Open ( "tips.txt", CFile::modeRead ) ;
	nexttip( ) ;
	return 1;
}

void tipdialog::nexttip( )
{
	CString str ;

	while ( m_f.ReadString ( str ) != NULL )
	{
		if ( *str == ' ' || *str == '\t' || *str == '\n' || *str == ';' ) 
			 continue ;

		SetDlgItemText ( IDC_TIPSTRING, str ) ;
		break ;
	}
}

HBRUSH tipdialog::OnCtlColor ( CDC* pDC, CWnd* pWnd, UINT nCtlColor )
{
	if ( pWnd -> GetDlgCtrlID( ) == IDC_TIPSTRING )
		return ( HBRUSH ) GetStockObject ( WHITE_BRUSH ) ;

	return CDialog::OnCtlColor ( pDC, pWnd, nCtlColor ) ;
}

void tipdialog::OnPaint( )
{
	CPaintDC d ( this ) ; 

	// get paint area for the big static control
	CWnd *p = GetDlgItem ( IDC_BULB ) ;
			
	CRect r ;
	p -> GetWindowRect ( &r ) ;
			
	ScreenToClient ( &r ) ;

	// paint the background white.
	CBrush mybrush ;
	mybrush.CreateStockObject ( WHITE_BRUSH ) ;
	d.FillRect ( r, &mybrush ) ;

	// load bitmap and get dimensions of the bitmap
	CBitmap bmp ;
	bmp.LoadBitmap ( IDB_BITMAP1 ) ;

	BITMAP bmpinfo ;
	bmp.GetBitmap ( &bmpinfo ) ;

	// draw bitmap in top corner and validate only top portion of window
	CDC pdc ;
	pdc.CreateCompatibleDC ( &d ) ;
	pdc.SelectObject ( &bmp ) ;
			
	r.bottom = bmpinfo.bmHeight + r.top ;
	d.BitBlt ( r.left, r.top, r.Width( ), r.Height( ), &pdc, 0, 0, SRCCOPY ) ;

	// draw out "Did you know..." message next to the bitmap
	CString str = "Did you know" ;
	r.left += bmpinfo.bmWidth ;
	d.DrawText ( str, r, DT_VCENTER | DT_SINGLELINE ) ;
}

void tipdialog::OnOK( )
{
	m_showtip = IsDlgButtonChecked ( IDC_STARTUP ) ;

	if ( m_showtip )
		AfxGetApp( ) -> WriteProfileInt ( "Config", "SHOWTIP", m_showtip ) ;
	else
		AfxGetApp( ) -> WriteProfileInt ( "Config", "SHOWTIP", m_showtip ) ;

	CDialog::OnOK( ) ;
}

BEGIN_MESSAGE_MAP ( tipdialog, CDialog )

	ON_WM_CTLCOLOR( )
	ON_WM_PAINT( )
	ON_COMMAND ( IDC_NEXTTIP, nexttip )

END_MESSAGE_MAP( )

