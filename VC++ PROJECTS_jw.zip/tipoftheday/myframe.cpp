#include "resource.h"

#include "myframe.h"
#include "tipdialog.h"

BEGIN_MESSAGE_MAP ( myframe, CFrameWnd )
	ON_COMMAND ( 101, tipofday )
END_MESSAGE_MAP( )

myframe::myframe( )
{
	Create ( 0, "Tip of the Day", WS_OVERLAPPEDWINDOW, rectDefault, 0, MAKEINTRESOURCE ( IDR_MENU1 ) ) ;
} 

void myframe::tipofday( )
{
	int showtip = AfxGetApp( ) -> GetProfileInt ( "Config", "SHOWTIP", 1 ) ;
	tipdialog t ( showtip ) ;
	t.DoModal( ) ;
}

