#include <afxwin.h>

class myframe : public CFrameWnd
{
	public :

		myframe( ) ;
		void tipofday( ) ;

	DECLARE_MESSAGE_MAP( )
} ;

