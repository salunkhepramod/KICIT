#include "myapp.h"
#include "myframe.h"
#include "tipdialog.h"

myapp a ;

int myapp::InitInstance( )
{
	SetRegistryKey ( "Our Tip Of The Day" ) ;

	myframe *p ;
	p = new myframe ;
	p -> ShowWindow ( 3 ) ;
	m_pMainWnd = p ;

	int showtip =  GetProfileInt ( "Config", "SHOWTIP", 1 ) ;
	if ( showtip )
	{
		tipdialog t ( 1 ) ;
		t.DoModal( ) ;
	}

	return 1 ;
} 
