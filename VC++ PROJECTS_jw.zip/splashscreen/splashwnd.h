#include <afxwin.h>

class splashwnd : public CWnd
{
	public :

		void Create ( CWnd *p ) ;
		int OnCreate ( LPCREATESTRUCT l ) ;
		void OnPaint( ) ;
		void OnTimer( ) ;

	DECLARE_MESSAGE_MAP( )
} ;
