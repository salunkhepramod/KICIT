#include <afxwin.h>
#include "splashwnd.h"

class myframe : public CFrameWnd
{
	private :

		splashwnd b ;

	public :
		
		myframe( ) ;
		int OnCreate ( LPCREATESTRUCT l ) ;

	DECLARE_MESSAGE_MAP( )
} ;
