#include "splashwnd.h"
#include "resource.h"

BEGIN_MESSAGE_MAP ( splashwnd, CWnd )
	
	ON_WM_CREATE( )
	ON_WM_PAINT( )
	ON_WM_TIMER( )

END_MESSAGE_MAP( )

void splashwnd::Create ( CWnd *p )
{
	CString classname ;
	classname = AfxRegisterWndClass ( 0, NULL, 0, NULL ) ;
			
	CreateEx ( 0, classname, NULL, WS_POPUP | WS_VISIBLE, 
				CRect ( 0, 0, 100, 100), p, NULL ) ;
}
		
int splashwnd::OnCreate ( LPCREATESTRUCT l )
{
	CWnd::OnCreate ( l ) ;

	CenterWindow( ) ;
	SetTimer ( 1, 1000, NULL ) ;

	return 0 ;
}

void splashwnd::OnPaint( )
{
	CPaintDC d ( this ) ;	

	CDC p ;
	CBitmap m ;
	m.LoadBitmap ( IDB_BITMAP1 ) ;

	p.CreateCompatibleDC ( &d ) ;
	p.SelectObject ( &m ) ;

	d.BitBlt ( 0, 0, 100, 100, &p, 0, 0, SRCCOPY ) ;
}

void splashwnd::OnTimer( )
{
	DestroyWindow( ) ;
}
