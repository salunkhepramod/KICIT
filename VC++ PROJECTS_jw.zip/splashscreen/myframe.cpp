#include "myframe.h"

BEGIN_MESSAGE_MAP ( myframe, CFrameWnd )
	ON_WM_CREATE( )
END_MESSAGE_MAP( )

myframe::myframe( )
{
	Create ( 0, "Splash Screen" ) ;
} 

int myframe::OnCreate ( LPCREATESTRUCT l )
{
	CFrameWnd::OnCreate ( l ) ;
	b.Create ( this ) ;
	return 0 ;
}
