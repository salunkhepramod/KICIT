#include <afxwin.h>
#include "info.h"
#include "mydoc.h"
#include "myview.h"
#include "resource.h"

BEGIN_MESSAGE_MAP ( myview, CScrollView ) 

	ON_WM_ERASEBKGND( )
	ON_COMMAND ( 501, changemode )
	ON_WM_LBUTTONDOWN( )
	ON_WM_MOUSEMOVE( )

END_MESSAGE_MAP( )

IMPLEMENT_DYNCREATE ( myview, CScrollView ) 

myview::myview( )
{
	CTime t = CTime::GetCurrentTime( ) ;

	m_today.dd = t.GetDay( ) ;
	m_today.mm = t.GetMonth( ) ;
	m_today.yy = t.GetYear( ) ;

	m_modeflag = 0 ;

	m_cur1 = AfxGetApp( ) -> LoadStandardCursor ( IDC_ARROW ) ;
	m_cur2 = AfxGetApp( ) -> LoadCursor ( IDC_CURSOR1 ) ;
}

void myview::OnInitialUpdate( )
{
	CScrollView::OnInitialUpdate( ) ;
	SetScrollSizes ( MM_TEXT, CSize ( 1000, 1000 ) ) ;
}

int myview::OnEraseBkgnd ( CDC *pdc ) 
{
	info curr ;
	mydoc *pdoc = ( mydoc * ) GetDocument( ) ;

	curr = pdoc -> getcurrentinfo( ) ;

	CRect r ;
	GetClientRect ( &r ) ;
		
	CBrush mybrush ( curr.windowbk ) ;
	FillOutsideRect ( pdc, &mybrush ) ;
	pdc -> FillRect ( &r, &mybrush ) ;

	return 1 ;
}

void myview::OnDraw ( CDC *d )
{
	mydoc *pdoc = ( mydoc* ) GetDocument( ) ;

	int xm, ym, xd, yd, xnum, ynum, m, i, wd, ht, firstday ;
	CString str ;
	long int normaldays, leapdays, totaldays ;

	info curr ;
	curr = pdoc -> getcurrentinfo( ) ;

	m_myfont.DeleteObject( ) ;
	m_myfont.CreateFont ( curr.height, curr.width, 0, 0, curr.weight, curr.italic, 
	curr.underline, curr.strikeout, 0, 0, 0, 0, 0, curr.facename ) ;

	d -> SelectObject ( &m_myfont ) ;

	CString titlestr ;
	CString recevtitle = pdoc -> GetPathName( ) ;

	char *temp = strrchr ( ( LPCTSTR ) recevtitle, '\\' ) ;
	recevtitle = temp + 1 ;

	if ( recevtitle == "" )
		titlestr.Format ( "Untitled %d", curr.yy ) ;
	else
		titlestr.Format ( "%s %d", recevtitle, curr.yy ) ;

	pdoc -> SetTitle ( titlestr ) ;

	TEXTMETRIC tm ;
	d -> GetTextMetrics ( &tm ) ;
	wd = tm.tmMaxCharWidth ;
	ht = tm.tmExternalLeading + tm.tmHeight ;

	SetScrollSizes ( MM_TEXT, CSize ( wd * 72, ht * 50 ) ) ;

	if ( curr.yy % 4 == 0 && curr.yy % 100 != 0 || curr.yy % 400 == 0 )
		m_days[1] = 29 ;
	else
		m_days[1] = 28 ;

	xd = 10 ;
	ym = 5 ;
	xm = xd + ( 10 - strlen ( m_months[0] ) / 2 ) * wd ;
	yd = ym + ht + 2 ;

	d -> SetBkMode ( TRANSPARENT ) ;

	for ( m = 1 ; m <= 12 ; m++ ) 
	{
		normaldays = ( curr.yy - 1 ) * 365l ;
		leapdays = ( curr.yy - 1 ) / 4 + ( curr.yy - 1 ) / 400 - ( curr.yy - 1 ) / 100 ;
		totaldays = normaldays + leapdays ;
			
		for ( i = 0 ; i <= m - 2 ; i++ )
			totaldays += m_days[i] ;

		firstday = totaldays % 7 ;

		d -> SetTextColor ( curr.mnt );
		d -> TextOut ( xm, ym, m_months[m-1], strlen ( m_months[m-1] ) ) ;
					
		d -> SetTextColor ( curr.wkday ) ;
		int xdname = xd ;
		for ( i = 0 ; i <= 6 ; i++ )
		{
			d -> TextOut ( xdname, yd, m_daynames[i], strlen ( m_daynames[i] ) ) ;
			xdname = xdname + wd * 3 ;
		}
					
		xnum = xd + firstday * wd * 3 ;
		ynum = yd + ht + 2 ;
					
		d -> SetTextColor ( curr.dat );
		for ( i = 1 ; i <= m_days[m-1] ; i++ )
		{
			str.Format ( "%2d", i ) ;
					
			if ( m == m_today.mm && i == m_today.dd && curr.yy == m_today.yy )
			{
				d -> SetTextColor ( curr.tddat ) ;
				
				d -> SetBkMode ( OPAQUE ) ;
				d -> SetBkColor ( curr.tddatbox );
						
				d -> TextOut ( xnum, ynum, str, str.GetLength( ) ) ;
				d -> SetTextColor ( curr.dat ) ;
				d -> SetBkMode ( TRANSPARENT ) ;
			}
			else
				d -> TextOut ( xnum, ynum, str, str.GetLength( ) ) ;
						
			xnum = xnum + wd * 3 ;
			if ( xnum > xd + wd * 6 * 3 )
			{
				xnum = xd ;
				ynum = ynum + ht + 2 ;
			}
		}
					
		if ( m % 3 == 0 )
		{
			xd = 10 ;
			ym = ym + ht * 12 ;
			yd = ym + ht + 2 ;
			xm = xd + ( 10 - strlen ( m_months[m-1] ) / 2 ) * wd ;
		}
		else
		{
			xd = xd + wd * 8 * 3 ;
			xm = xd + ( 10 - strlen ( m_months[m-1] ) / 2 ) * wd ;
		}
	}

	m_pos = d -> GetViewportOrg( ) ;
}

void myview::changemode( )
{
	m_modeflag = 1 ;
}

void myview::OnLButtonDown ( UINT flags, CPoint pt )
{
	if ( m_modeflag == 0 )
		return ;

	int xm, ym, xd, yd, xnum, ynum, m, i, wd, ht, firstday ;
	long int normaldays, leapdays, totaldays ;
	info date ;

	CClientDC d ( this ) ;

	d.SetViewportOrg ( m_pos.x, m_pos.y ) ;
	d.SelectObject ( &m_myfont ) ;

	TEXTMETRIC tm ;
	d.GetTextMetrics ( &tm ) ;
	wd = tm.tmMaxCharWidth ;
	ht = tm.tmExternalLeading + tm.tmHeight ;

	mydoc *pdoc = ( mydoc * ) GetDocument( ) ;

	if ( m_modeflag == 1 )
		date = m_firstdate = pdoc -> getcurrentinfo( ) ;
	else
		date = m_seconddate = pdoc -> getcurrentinfo( ) ;

	xd = 10 ;
	ym = 5 ;
				
	pt.x = pt.x - m_pos.x ;
	pt.y = pt.y - m_pos.y ;

	xm = xd + ( 10 - strlen ( m_months[0] ) / 2 ) * wd ;
	yd = ym + ht + 2 ;

	for ( m = 1 ; m <= 12 ; m++ ) 
	{
		normaldays = ( date.yy - 1 ) * 365l ;
		leapdays = ( date.yy - 1 ) / 4 + ( date.yy - 1 ) / 400 - ( date.yy - 1 ) / 100 ;
		totaldays = normaldays + leapdays ;
				
		for ( i = 0 ; i <= m - 2 ; i++ )
			totaldays += m_days[i] ;

		firstday = totaldays % 7 ;

		int xdname = xd ;
		for ( i = 0 ; i <= 6 ; i++ )
			xdname = xdname + wd * 3 ;
						
		xnum = xd + firstday * wd * 3 ;
		ynum = yd + ht + 2 ;
						
		for ( i = 1 ; i <= m_days[m-1] ; i++ )
		{
			if ( pt.x >= xnum && pt.x <= xnum + 2 * wd && pt.y >= ynum && pt.y <= ynum + ht )
			{
				if ( m_modeflag == 1 )
				{
					m_firstdate.dd = i ;
					m_firstdate.mm = m ;
								
					f_totdays = totaldays + i ;
					m_modeflag = 2 ;
				}
				else
				{
					m_seconddate.dd = i ;
					m_seconddate.mm = m ;

					int diff = ( totaldays + i ) - f_totdays ;
					if ( diff < 0 )
						diff = -diff ;

					m_modeflag = 0 ;

					CString datestr ;
					datestr.Format ( "The difference of days \nbetween %d %d %d and %d %d %d \nis %d", m_firstdate.dd, m_firstdate.mm, m_firstdate.yy, m_seconddate.dd, m_seconddate.mm, m_seconddate.yy, diff ) ;
					MessageBox ( datestr, "Result"  ) ;
				}

				return ;
			}							
			xnum = xnum + wd * 3 ;
			if ( xnum > xd + wd * 6 * 3 )
			{
				xnum = xd ;
				ynum = ynum + ht + 2 ;
			}
		}
						
		if ( m % 3 == 0 )
		{
			xd = 10 ;
			ym = ym + ht * 12 ;
			yd = ym + ht + 2 ;
			xm = xd + ( 10 - strlen ( m_months[m-1] ) / 2 ) * wd ;
		}
		else
		{
			xd = xd + wd * 8 * 3 ;
			xm = xd + ( 10 - strlen ( m_months[m-1] ) / 2 ) * wd ;
		}
	}
}

void myview::OnMouseMove ( UINT flags, CPoint pt )
{
	if ( m_modeflag == 1 || m_modeflag == 2 )
		SetCursor ( m_cur2 ) ;
}

int myview::m_days[ ] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 } ;
char* myview::m_months[ ] = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" } ;
char* myview::m_daynames[ ] = { "MO", "TU", "WE", "TH", "FR", "SA", "SU" } ;
