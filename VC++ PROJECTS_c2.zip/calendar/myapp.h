class myapp : public CWinApp
{
	public :
	
		int InitInstance( ) ;

	DECLARE_MESSAGE_MAP( )
} ;
