//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by calendar.rc
//
#define IDR_MAINFRAME                   101
#define IDD_DIALOG1                     104
#define IDC_CURSOR1                     105
#define IDD_DIALOG2                     106
#define IDI_ICON1                       107
#define IDI_ICON2                       108
#define IDC_EDIT1                       1006
#define IDC_SPIN1                       1007
#define IDC_ICONVIEW                    1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
