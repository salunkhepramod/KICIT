class mydoc : public CDocument
{	
	DECLARE_DYNCREATE ( mydoc )

	private :

		info m_current ;

	public :

		mydoc( ) ;
		BOOL OnNewDocument( ) ;
		BOOL OnOpenDocument ( LPCTSTR path ) ;
		BOOL OnSaveDocument ( LPCTSTR path ) ;
		info getcurrentinfo( ) ;
		void previous( ) ;
		void next( ) ;
		void present( ) ;
		void select( ) ;
		void Serialize ( CArchive& ar ) ;
		void selectfont( ) ;
		void selectcolor ( int n ) ;
		void about( ) ;

	DECLARE_MESSAGE_MAP( )
} ;
