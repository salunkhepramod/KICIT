#include <afxwin.h>
#include <afxcmn.h>
#include <afxext.h>
#include "info.h"
#include "mydoc.h"
#include "yeardialog.h"
#include "aboutdialog.h"

BEGIN_MESSAGE_MAP ( mydoc, CDocument )

	ON_COMMAND ( 101, previous )
	ON_COMMAND ( 102, next )
	ON_COMMAND ( 103, present )
	ON_COMMAND ( 104, select )

	ON_COMMAND ( 301, selectfont )

	ON_COMMAND_RANGE ( 201, 206, selectcolor )

	ON_COMMAND ( 601, about )

END_MESSAGE_MAP( )

IMPLEMENT_DYNCREATE ( mydoc, CDocument ) 

mydoc::mydoc( )
{
}

BOOL mydoc::OnNewDocument( )
{
	CDocument::OnNewDocument( ) ;
			
	CTime t = CTime::GetCurrentTime( ) ;

	m_current.dd = t.GetDay( ) ;
	m_current.mm = t.GetMonth( ) ;
	m_current.yy = t.GetYear( ) ;

	m_current.height = 13 ;
	m_current.width = 5 ;
	m_current.weight = 2 ;
	m_current.italic = 0 ;
	m_current.underline = 0 ;
	m_current.strikeout = 0 ;
	m_current.facename = "Times New Roman" ;
	m_current.windowbk = RGB ( 0, 0, 200 ) ;
	m_current.mnt = RGB ( 255, 0, 0 ) ;
	m_current.wkday = RGB ( 0, 128, 0 ) ;
	m_current.dat = RGB ( 128, 128, 200 ) ;
	m_current.tddat = RGB ( 255, 0, 200 ) ;
	m_current.tddatbox = RGB ( 0, 255, 200 ) ;

	SetModifiedFlag ( TRUE ) ;
	return 1 ;
}

BOOL mydoc::OnOpenDocument ( LPCTSTR path )
{
	CDocument::OnOpenDocument ( path ) ;
	return 1 ;
}

BOOL mydoc::OnSaveDocument ( LPCTSTR path )
{
	CDocument::OnSaveDocument ( path ) ;
	return 1 ;
}

info mydoc::getcurrentinfo( )
{
	return m_current ;
}

void mydoc::previous( )
{
	m_current.yy-- ;

	UpdateAllViews( 0 ) ;
	SetModifiedFlag ( TRUE ) ;
}

void mydoc::next( )
{
	m_current.yy++ ;

	UpdateAllViews( 0 ) ;
	SetModifiedFlag ( TRUE ) ;
}

void mydoc::present( )
{
	CTime t = CTime::GetCurrentTime( ) ;

	m_current.dd = t.GetDay( ) ;
	m_current.mm = t.GetMonth( ) ;
	m_current.yy = t.GetYear( ) ;

	UpdateAllViews ( 0 ) ;
	SetModifiedFlag ( TRUE ) ;
}

void mydoc::select( )
{
	info temp ;
	CTime t = CTime::GetCurrentTime( ) ;

	temp.dd = t.GetDay( ) ;
	temp.mm = t.GetMonth( ) ;
	temp.yy = t.GetYear( ) ;

	yeardialog d ( temp.yy ) ;
	d.DoModal( ) ;

	m_current.yy = d.getyear( ) ;

	UpdateAllViews ( 0 ) ;
	SetModifiedFlag ( TRUE ) ;
}

void mydoc::Serialize ( CArchive& ar ) 
{
	CObject::Serialize ( ar ) ;

	if ( ar.IsStoring( ) )
		ar  << m_current.yy 
			<< m_current.height << m_current.width << m_current.weight 
			<< m_current.italic << m_current.underline << m_current.strikeout 
			<< m_current.facename 
			<< m_current.windowbk << m_current.wkday << m_current.dat 
			<< m_current.tddat << m_current.tddatbox ;
	else
		ar >> m_current.yy 
			>> m_current.height >> m_current.width >> m_current.weight 
			>> m_current.italic >> m_current.underline >> m_current.strikeout 
			>> m_current.facename 
			>> m_current.windowbk >> m_current.wkday >> m_current.dat 
			>> m_current.tddat >> m_current.tddatbox ;
}

void mydoc::selectfont( )
{
	CFontDialog f ;
	if ( f.DoModal( ) == IDOK )
	{
		m_current.height = f.GetSize( ) / 10 ;
		m_current.width = 0 ;
		m_current.weight = f.GetWeight( ) ;
		m_current.italic = f.IsItalic( ) ;
		m_current.underline = f.IsUnderline( ) ;
		m_current.strikeout = f.IsStrikeOut( ) ;
		m_current.facename = f.GetFaceName( ) ;

		UpdateAllViews ( 0 ) ;
		SetModifiedFlag ( TRUE ) ;
	}
}

void mydoc::selectcolor ( int n )
{
	CColorDialog c ;
			
	if ( c.DoModal( ) == IDOK )
	{
		switch ( n )
		{
			case 201 :
				m_current.windowbk = c.GetColor( ) ;
				break ;

			case 202 :
				m_current.mnt = c.GetColor( ) ;
				break ;

			case 203 :
				m_current.wkday = c.GetColor( ) ;
				break ;

			case 204 :
				m_current.dat = c.GetColor( ) ;
				break ;

			case 205 :
				m_current.tddat = c.GetColor( ) ;
				break ;

			case 206 :
				m_current.tddatbox = c.GetColor( ) ;
				break ;
		}

		UpdateAllViews ( 0 ) ;
		SetModifiedFlag ( TRUE ) ;
	}
}

void mydoc::about( )
{
	aboutdialog d ;
	d.DoModal( ) ;
}
