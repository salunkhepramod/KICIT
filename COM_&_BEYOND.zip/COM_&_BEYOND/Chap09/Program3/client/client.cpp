#include <afxwin.h>
#include "about.h"
# include "resource.h"

class myframe : public CFrameWnd
{
	public :

		myframe( ) 
		{
			Create ( 0, "Test", WS_OVERLAPPEDWINDOW, rectDefault, 0, MAKEINTRESOURCE ( IDR_MENU1 ) ) ;
		}

		void about( )
		{
			aboutdialog d ( "Advanced Visual C++. Version 1.0" ) ;
			d.DoModal( ) ;
		}

	DECLARE_MESSAGE_MAP( )
} ;

BEGIN_MESSAGE_MAP ( myframe, CFrameWnd )
	ON_COMMAND ( 101, about ) 
END_MESSAGE_MAP( )

class myapp : public CWinApp
{
	public :

		int InitInstance( )
		{
			myframe *p ;
			p = new myframe ;
			m_pMainWnd = p ; ;
			p -> ShowWindow ( 3 ) ;
			return 1 ;
		}
} ;

myapp a ;



	