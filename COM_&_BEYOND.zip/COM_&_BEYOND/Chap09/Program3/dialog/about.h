class AFX_EXT_CLASS  aboutdialog : public CDialog
{
	public :
		
		CString string ;
		aboutdialog ( CString str ) ;
		virtual int  OnInitDialog( ) ;
} ;
