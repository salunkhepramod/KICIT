# include "stdafx.h"
# include "about.h"

# include "resource.h"

aboutdialog::aboutdialog ( CString str ) : CDialog ( IDD_DIALOG1 )
{
	string = str ;
}

int aboutdialog::OnInitDialog()
{
	
	SetDlgItemText ( IDC_STATIC1, string ) ;
	return CDialog::OnInitDialog() ;
}



