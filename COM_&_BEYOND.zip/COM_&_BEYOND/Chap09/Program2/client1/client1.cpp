// Linking an exported function explicitly
#include <afxwin.h>

class myframe : public CFrameWnd
{
	private:

		HMODULE h ;

	public :

		myframe( )
		{
			Create ( 0, "Client" ) ;
		}

		void OnCreate ( LPCREATESTRUCT l )
		{
			CFrameWnd::OnCreate ( l ) ;
			h = ::LoadLibrary ( "font.dll" ) ;
		}

		void OnLButtonDown ( UINT flags, CPoint pt ) 
		{
			CClientDC d ( this ) ;

			typedef void ( pfun ) ( CDC *, CString, int, COLORREF, CPoint, 
								CString ) ;
			pfun *f = 0 ;
			f= ( pfun * ) ::GetProcAddress ( h, "display" ) ;
			(*f ) ( &d, "Arial", 30, RGB ( 0, 0, 255 ), pt, "Hello" ) ;
		}
		void OnDestroy( )
		{
			::FreeLibrary ( h ) ;
		}

	DECLARE_MESSAGE_MAP( )
} ;

BEGIN_MESSAGE_MAP ( myframe, CFrameWnd )

	ON_WM_CREATE( )
	ON_WM_LBUTTONDOWN( )
	ON_WM_DESTROY( )

END_MESSAGE_MAP( )

class myapp : CWinApp
{
	public :

		BOOL InitInstance( )
		{
			myframe *p ;
			p = new myframe ;
			m_pMainWnd = p ;
			p -> ShowWindow ( SW_SHOWNORMAL ) ;

			return TRUE ;
		}
} ;

myapp a ;
