#include <stdafx.h>

__declspec ( dllexport ) display ( CDC *p, CString name, int size, COLORREF c, CPoint pt, CString text )
{
	int ht = - ( ( p -> GetDeviceCaps ( LOGPIXELSY ) * size ) / 72 ) ;
	CFont myfont ;
	myfont.CreateFont ( ht, 0, 0, 0, FW_NORMAL, 0, 0, 0, 
						DEFAULT_CHARSET, 
						OUT_CHARACTER_PRECIS, 
						CLIP_CHARACTER_PRECIS, 
						DEFAULT_QUALITY, 
						DEFAULT_PITCH | FF_DONTCARE, name ) ;
	
	CFont *prevfont = p -> SelectObject ( &myfont ) ;
	p -> SetTextColor  ( c ) ;
	p -> SetBkMode ( TRANSPARENT ) ;
	p -> TextOut ( pt.x, pt.y, text ) ;
	p -> SelectObject ( prevfont ) ;
}
