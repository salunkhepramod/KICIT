#include <afxwin.h>
#include "fontfunction.h"

class myframe : public CFrameWnd
{
	public :

		myframe( )
		{
			Create ( 0, "Client" ) ;
		}

		void OnLButtonDown ( UINT flags, CPoint pt ) 
		{
			CClientDC d ( this ) ;

			display ( &d, "Arial", 72, RGB ( 255, 0, 255 ), pt, "Hello" ) ;
		}

	DECLARE_MESSAGE_MAP( )
} ;

BEGIN_MESSAGE_MAP ( myframe, CFrameWnd )
	ON_WM_LBUTTONDOWN( )
END_MESSAGE_MAP( )

class myapp : CWinApp
{
	public :

		BOOL InitInstance( )
		{
			myframe *p ;
			p = new myframe ;
			m_pMainWnd = p ;
			p -> ShowWindow ( SW_SHOWNORMAL ) ;

			return TRUE ;
		}
} ;

myapp a ;
