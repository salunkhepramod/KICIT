#include <afxwin.h>
#include <afxext.h>
#include "myframe.h"
#include "textview.h"
#include "graphicsview.h"

IMPLEMENT_DYNCREATE ( myframe, CFrameWnd ) 

BOOL myframe::OnCreateClient ( LPCREATESTRUCT l, CCreateContext *p ) 
{
	splitter.CreateStatic ( this, 1, 2 ) ;

	splitter.CreateView ( 0, 0, RUNTIME_CLASS ( graphicsview ), CSize ( 128, 0 ), p ) ;
	splitter.CreateView ( 0, 1, RUNTIME_CLASS ( textview ), CSize ( 0, 0 ), p ) ;

	return TRUE ;
}
