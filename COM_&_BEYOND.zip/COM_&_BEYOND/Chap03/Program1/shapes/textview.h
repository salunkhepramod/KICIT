class textview : public CView
{
	DECLARE_DYNCREATE ( textview )

	public :

		void OnDraw ( CDC *p ) ;
} ;
