#include <afxwin.h>
#include "cshape.h"
#include "crect.h"

IMPLEMENT_SERIAL ( crect, cshape, 1 ) 

crect::crect ( )
{
}

crect::crect ( CPoint from, CPoint to, int wd, COLORREF clr, UINT brsty, 
				COLORREF brclr ) 
{
	startpt = from ;
	endpt = to ;
			
	lnwidth = wd ;
	lncolor = clr ;

	brstyle = brsty ;
	brcolor = brclr ;
}

void crect::Serialize ( CArchive &ar )
{
	CObject::Serialize ( ar ) ;

	if ( ar.IsStoring( ) ) 
		ar << startpt << endpt << lnwidth << ( DWORD ) lncolor << brstyle 
			<< ( DWORD ) brcolor ;
	else
		ar >> startpt >> endpt >> lnwidth >> ( DWORD ) lncolor >> brstyle 
			>> ( DWORD ) brcolor ;
}

void crect::draw ( CDC *p )
{
	CPen mypen ( PS_SOLID, lnwidth, lncolor ) ;
	CBrush mybrush ;
		
	if ( brstyle == PS_SOLID )
		mybrush.CreateSolidBrush ( brcolor ) ;
	else
		mybrush.CreateStockObject ( NULL_BRUSH ) ;

	CPen *prevpen = p -> SelectObject ( &mypen ) ;
	CBrush *prevbrush = p -> SelectObject ( &mybrush ) ;

	p -> Rectangle ( startpt.x, startpt.y, endpt.x, endpt.y ) ;

	p -> SelectObject ( prevpen ) ;
	p -> SelectObject ( prevbrush ) ;
}
