class myframe : public CFrameWnd
{
	DECLARE_DYNCREATE ( myframe )

	public :
		
		CSplitterWnd splitter ;
		CSplitterWnd splitterdyn ;
		virtual BOOL OnCreateClient ( LPCREATESTRUCT, CCreateContext* ) ;
} ;
