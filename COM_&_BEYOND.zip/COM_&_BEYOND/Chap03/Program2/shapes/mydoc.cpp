#include <afxwin.h>
#include "cshape.h"
#include "cline.h"
#include "crect.h"
#include "mydoc.h"

#include "resource.h"

IMPLEMENT_DYNCREATE ( mydoc, CDocument ) 

BEGIN_MESSAGE_MAP ( mydoc, CDocument )

	ON_COMMAND_RANGE ( ID_WIDTH_VTHIN, ID_WIDTH_VTHICK, onwidth ) 
	ON_COMMAND_RANGE ( ID_COLOR_BLACK, ID_COLOR_WHITE, oncolor ) 
	ON_COMMAND_RANGE ( ID_BLACK_BRUSH, ID_NULL_BRUSH, onbrush ) 
	ON_COMMAND_RANGE ( ID_LINE, ID_RECTANGLE, onshape ) 

END_MESSAGE_MAP( )

const int mydoc::linewidth[5] = { 1, 8, 16, 24, 32 } ;

const COLORREF mydoc::linecolor[8] = 
{ 
	RGB ( 0, 0, 0 ), 
	RGB ( 0, 0, 255 ), 
	RGB ( 0, 255, 0 ), 
	RGB ( 0, 255, 255 ), 
	RGB ( 255, 0, 0 ), 
	RGB ( 255, 0, 255 ), 
	RGB ( 255, 255, 0 ), 
	RGB ( 255, 255, 255 ), 
} ;		

const UINT mydoc::brushstyle[2] = { BS_SOLID, BS_NULL } ;

const COLORREF mydoc::brushcolor[8] = 
{ 
	RGB ( 0, 0, 0 ), 
	RGB ( 0, 0, 255 ), 
	RGB ( 0, 255, 0 ), 
	RGB ( 0, 255, 255 ), 
	RGB ( 255, 0, 0 ), 
	RGB ( 255, 0, 255 ), 
	RGB ( 255, 255, 0 ), 
	RGB ( 255, 255, 255 ), 
} ;		

mydoc::mydoc( )
{
	arr.SetSize ( 0, 100 ) ;
}

BOOL mydoc::OnNewDocument( )
{
	if ( !CDocument::OnNewDocument( ) )
		return FALSE ;

	linecount = rectcount = 0 ;

	init_width_color_brush_shape( ) ;

	return true ;
}

BOOL mydoc::OnOpenDocument ( LPCTSTR filepath )
{
	if ( !CDocument::OnOpenDocument ( filepath ) )
		return FALSE ;

	init_width_color_brush_shape( ) ;

	return true ;
}

void mydoc::init_width_color_brush_shape( )
{
	wd = linewidth[0] ;
	clr = linecolor[0] ;
			
	currentshape = 'L' ;
		
	br_sty = brushstyle[0] ;
	br_clr = brushcolor[1] ;
}

cshape* mydoc::getobject ( int i )
{
	return ( cshape * ) arr[i] ;
}

int mydoc::getobjectscount( )
{
	return arr.GetSize( ) ;
}

void mydoc::Serialize ( CArchive &ar )
{
	arr.Serialize ( ar ) ;

	if ( ar.IsStoring( ) ) 
		ar << linecount << rectcount ;
	else
		ar >> linecount >> rectcount ;
}

cline* mydoc::addline ( CPoint from, CPoint to )
{
	cline *line ;
	line = new cline ( from, to, wd, clr ) ;

	arr.Add ( line ) ;

	SetModifiedFlag( ) ;

	UpdateAllViews ( NULL ) ;

	linecount++ ;

	return line ;
}

crect* mydoc::addrect ( CPoint from, CPoint to )
{
	crect *rect ;
	rect = new crect ( from, to, wd, clr, br_sty, br_clr ) ;

	arr.Add ( rect ) ;

	SetModifiedFlag( ) ;

	UpdateAllViews ( NULL ) ;

	rectcount++ ;

	return rect ;
}

void mydoc::onwidth ( UINT id )
{
	wd = linewidth[id - ID_WIDTH_VTHIN] ;

	POSITION pos = GetFirstViewPosition( ) ;
	CView *v = ( CView * ) GetNextView ( pos ) ;
	UpdateAllViews ( v ) ;
}

void mydoc::oncolor ( UINT id )
{
	clr = linecolor[id - ID_COLOR_BLACK] ;

	POSITION pos = GetFirstViewPosition( ) ;
	CView *v = ( CView * ) GetNextView ( pos ) ;
	UpdateAllViews ( v ) ;
}

void mydoc::onshape ( UINT id )
{
	switch ( id ) 
	{
		case ID_LINE :
			currentshape = 'L' ;
			break ;

		case ID_RECTANGLE :
			currentshape = 'R' ;
			break ;
	}

	POSITION pos = GetFirstViewPosition( ) ;
	CView *v = ( CView * ) GetNextView ( pos ) ;
	UpdateAllViews ( v ) ;
}

char mydoc::getshape( )
{
	return currentshape ;
}

void mydoc::onbrush ( UINT id )
{
	switch ( id )
	{
		case ID_BLACK_BRUSH :
		case ID_BLUE_BRUSH :
		case ID_GREEN_BRUSH :
		case ID_CYAN_BRUSH :
		case ID_RED_BRUSH :
		case ID_MAGENTA_BRUSH :
		case ID_YELLOW_BRUSH :
		case ID_WHITE_BRUSH :

			br_sty = brushstyle[0] ;
			br_clr = brushcolor[id - ID_BLACK_BRUSH] ;
			break ;

		case ID_NULL_BRUSH :

			br_sty = brushstyle[1] ;
			break ;
	}

	POSITION pos = GetFirstViewPosition( ) ;
	CView *v = ( CView * ) GetNextView ( pos ) ;
	UpdateAllViews ( v ) ;
}

int mydoc::getwidth( )
{
	return ( wd ) ;
}

COLORREF mydoc::getcolor( )
{
	return ( clr ) ;
}

UINT mydoc::getbrushstyle( )
{
	return ( br_sty ) ;
}

COLORREF mydoc::getbrushcolor( )
{
	return ( br_clr ) ;
}

void mydoc::DeleteContents( )
{
	int count = arr.GetSize( ) ;

	for ( int i = 0 ; i < count ; i++ )
		delete arr[i] ;

	arr.RemoveAll( ) ;
}

int mydoc::getlinecount( )
{
	return linecount ;
}

int mydoc::getrectcount( )
{
	return rectcount ;
}