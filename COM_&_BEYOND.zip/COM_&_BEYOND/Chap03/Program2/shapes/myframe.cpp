#include <afxwin.h>
#include <afxext.h>
#include "myframe.h"
#include "textview.h"
#include "graphicsview.h"

IMPLEMENT_DYNCREATE ( myframe, CFrameWnd ) 

BOOL myframe::OnCreateClient ( LPCREATESTRUCT l, CCreateContext *p ) 
{
	splitter.CreateStatic ( this, 1, 2 ) ;
	splitterdyn.Create ( &splitter, 2, 1, CSize ( 1, 1 ), p ) ;

	splitter.SetColumnInfo ( 0, 200, 1 ) ;
	splitter.CreateView ( 0, 1, RUNTIME_CLASS ( textview ), CSize ( 0, 0 ), p ) ;


	return TRUE ;
}
