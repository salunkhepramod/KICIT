class myapp : public CWinApp
{
	private :
	
		CRuntimeClass *d, *cf, *v ;

	public :

		BOOL InitInstance( ) ;

	DECLARE_MESSAGE_MAP( )
} ;
