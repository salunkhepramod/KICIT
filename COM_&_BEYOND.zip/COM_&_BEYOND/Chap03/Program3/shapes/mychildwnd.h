class mychildwnd : public CMDIChildWnd
{
	DECLARE_DYNCREATE ( mychildwnd ) 

	public :
		
		CSplitterWnd splitter ;
		CSplitterWnd splitterdyn ;
		virtual BOOL OnCreateClient ( LPCREATESTRUCT, CCreateContext* ) ;
} ;
