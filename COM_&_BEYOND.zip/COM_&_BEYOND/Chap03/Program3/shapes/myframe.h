class myframe : public CMDIFrameWnd
{
	DECLARE_DYNCREATE ( myframe )
} ;
