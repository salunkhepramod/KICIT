#include <afxwin.h>
#include "cshape.h"
#include "ccircle.h"
#include "mydoc_cir.h"

#include "resource.h"

IMPLEMENT_DYNCREATE ( mydoc_cir, CDocument ) 

BEGIN_MESSAGE_MAP ( mydoc_cir, CDocument )

	ON_COMMAND_RANGE ( ID_WIDTH_VTHIN, ID_WIDTH_VTHICK, 
  							  onwidth ) 
	ON_COMMAND_RANGE ( ID_COLOR_BLACK, 	ID_COLOR_WHITE, 
							  oncolor ) 
	ON_COMMAND_RANGE ( ID_BLACK_BRUSH, 	ID_NULL_BRUSH, 
							  onbrush ) 

END_MESSAGE_MAP( )

const int mydoc_cir::linewidth[5] = { 1, 8, 16, 24, 32 } ;

const COLORREF mydoc_cir::linecolor[8] = 
{ 
	RGB ( 0, 0, 0 ), 
	RGB ( 0, 0, 255 ), 
	RGB ( 0, 255, 0 ), 
	RGB ( 0, 255, 255 ), 
	RGB ( 255, 0, 0 ), 
	RGB ( 255, 0, 255 ), 
	RGB ( 255, 255, 0 ), 
	RGB ( 255, 255, 255 ), 
} ;		

const UINT mydoc_cir::brushstyle[2] = { BS_SOLID, BS_NULL } ;

const COLORREF mydoc_cir::brushcolor[8] = 
{ 
	RGB ( 0, 0, 0 ), 
	RGB ( 0, 0, 255 ), 
	RGB ( 0, 255, 0 ), 
	RGB ( 0, 255, 255 ), 
	RGB ( 255, 0, 0 ), 
	RGB ( 255, 0, 255 ), 
	RGB ( 255, 255, 0 ), 
	RGB ( 255, 255, 255 ), 
} ;		

mydoc_cir::mydoc_cir( )
{
	arr.SetSize ( 0, 100 ) ;
}

BOOL mydoc_cir::OnNewDocument( )
{
	if ( !CDocument::OnNewDocument( ) )
		return FALSE ;

	circlecount = 0 ;

	init_width_color_brush_shape( ) ;
	
	return true ;
}

BOOL mydoc_cir::OnOpenDocument ( LPCTSTR filepath )
{
	if ( !CDocument::OnOpenDocument ( filepath ) )
		return FALSE ;

	init_width_color_brush_shape( ) ;

	return true ;
}

void mydoc_cir::init_width_color_brush_shape( )
{
	wd = linewidth[0] ;
	clr = linecolor[0] ;
			
	br_sty = brushstyle[0] ;
	br_clr = brushcolor[1] ;
}

ccircle* mydoc_cir::getobject ( int i )
{
	return ( ccircle* ) arr[i] ;
}

int mydoc_cir::getobjectscount( )
{
	return arr.GetSize( ) ;
}

void mydoc_cir::Serialize ( CArchive &ar )
{
	arr.Serialize ( ar ) ;

	if ( ar.IsStoring( ) ) 
		ar << circlecount ;
	else
		ar >> circlecount ;
}

ccircle* mydoc_cir::addcircle ( CPoint from, CPoint to )
{
	ccircle *circ ;
	circ = new ccircle ( from, to, wd, clr, br_sty, br_clr ) ;

	arr.Add ( circ ) ;

	SetModifiedFlag( ) ;

	circlecount++ ;

	return circ ;
}

void mydoc_cir::onwidth ( UINT id )
{
	wd = linewidth[id - ID_WIDTH_VTHIN] ;
}

void mydoc_cir::oncolor ( UINT id )
{
	clr = linecolor[id - ID_COLOR_BLACK] ;
}

void mydoc_cir::onbrush ( UINT id )
{
	switch ( id )
	{
		case ID_BLACK_BRUSH :
		case ID_BLUE_BRUSH :
		case ID_GREEN_BRUSH :
		case ID_CYAN_BRUSH :
		case ID_RED_BRUSH :
		case ID_MAGENTA_BRUSH :
		case ID_YELLOW_BRUSH :
		case ID_WHITE_BRUSH :

			br_sty = brushstyle[0] ;
			br_clr = brushcolor[id - ID_BLACK_BRUSH] ;
			break ;

		case ID_NULL_BRUSH :

			br_sty = brushstyle[1] ;
			break ;
	}
}

int mydoc_cir::getwidth( )
{
	return ( wd ) ;
}

COLORREF mydoc_cir::getcolor( )
{
	return ( clr ) ;
}

UINT mydoc_cir::getbrushstyle( )
{
	return ( br_sty ) ;
}

COLORREF mydoc_cir::getbrushcolor( )
{
	return ( br_clr ) ;
}

void mydoc_cir::DeleteContents( )
{
	int count = arr.GetSize( ) ;

	for ( int i = 0 ; i < count ; i++ )
		delete arr[i] ;

	arr.RemoveAll( ) ;
}
