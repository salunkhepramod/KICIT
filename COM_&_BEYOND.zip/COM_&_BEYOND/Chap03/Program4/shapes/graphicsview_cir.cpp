#include <afxwin.h>
#include "ccircle.h"
#include "mydoc_cir.h"
#include "graphicsview_cir.h"

IMPLEMENT_DYNCREATE ( graphicsview_cir, CScrollView ) 

BEGIN_MESSAGE_MAP ( graphicsview_cir, CScrollView )

	ON_WM_LBUTTONDOWN( )
	ON_WM_MOUSEMOVE( )
	ON_WM_LBUTTONUP( )

END_MESSAGE_MAP( )

void graphicsview_cir::OnInitialUpdate( ) 
{ 
	SetScrollSizes ( MM_TEXT, CSize ( 2048, 2048 ) ) ;
	CScrollView::OnInitialUpdate ( ) ;
}

void graphicsview_cir::OnDraw ( CDC *p ) 
{ 
	int objectcount = 0 ;

	mydoc_cir *doc = ( mydoc_cir * ) GetDocument( ) ;
	int count = doc -> getobjectscount( ) ;

	for ( int i = 0 ; i < count ; i++ )
		doc -> getobject ( i ) -> draw ( p ) ;
}

void graphicsview_cir::OnLButtonDown ( UINT flags, CPoint pt )
{
	mydoc_cir *doc = ( mydoc_cir * ) GetDocument( ) ;

	CClientDC d ( this ) ;
	OnPrepareDC ( &d ) ;
	d.DPtoLP ( &pt ) ;
			
	CPen mypen ( PS_SOLID, doc -> getwidth( ), doc -> getcolor( ) ) ;

	CPen *prevpen = d.SelectObject ( &mypen ) ;
	int prevmode = d.SetROP2 ( R2_NOTXORPEN ) ;

	CBrush mybrush ;
	if ( doc -> getbrushstyle( ) == PS_SOLID )
		mybrush.CreateSolidBrush ( doc -> getbrushcolor( ) ) ;
	else
		mybrush.CreateStockObject( NULL_BRUSH ) ;

	CBrush *prevbrush = d.SelectObject ( &mybrush ) ;

	str_pt = end_pt = pt ;

	d.Ellipse ( str_pt.x, str_pt.y, end_pt.x, end_pt.y ) ;

	d.SelectObject ( prevpen ) ;
	d.SetROP2 ( prevmode ) ;
	d.SelectObject ( prevbrush ) ;

	SetCapture( ) ;
}

void graphicsview_cir::OnMouseMove ( UINT flags, CPoint pt )
{
	if ( GetCapture( ) == this )
	{
		mydoc_cir *doc = ( mydoc_cir * ) GetDocument( ) ;
				
		CClientDC d ( this ) ;

		OnPrepareDC ( &d ) ;
		d.DPtoLP ( &pt ) ;

		CPen mypen ( PS_SOLID, ( ( mydoc_cir * ) GetDocument( ) ) -> getwidth( ), 						( ( mydoc_cir * ) GetDocument( ) ) -> getcolor( ) );

		CPen *prevpen = d.SelectObject ( &mypen ) ;
		int prevmode = d.SetROP2 ( R2_NOTXORPEN ) ;

		CBrush mybrush ;
		if ( doc -> getbrushstyle( ) == PS_SOLID )
			mybrush.CreateSolidBrush ( doc -> getbrushcolor( ) ) ;
		else
			mybrush.CreateStockObject( NULL_BRUSH ) ;

		CBrush *prevbrush = d.SelectObject ( &mybrush ) ;

		d.Ellipse ( str_pt.x, str_pt.y, end_pt.x, end_pt.y ) ;
		d.Ellipse ( str_pt.x, str_pt.y, pt.x, pt.y ) ;

		end_pt = pt ;

		d.SelectObject ( prevpen ) ;
		d.SetROP2 ( prevmode ) ;
		d.SelectObject ( prevbrush ) ;
	}
}

void graphicsview_cir::OnLButtonUp ( UINT flags, CPoint pt )
{
	if ( GetCapture( ) == this ) 
	{
		::ReleaseCapture( ) ;
				
		mydoc_cir *doc = ( mydoc_cir * ) GetDocument( ) ;

		CClientDC d ( this ) ;
	
		OnPrepareDC ( &d ) ;
		d.DPtoLP ( &pt ) ;

		end_pt = pt ;

		ccircle* circ ;
		circ = doc -> addcircle ( str_pt, end_pt ) ;
		circ -> draw ( &d ) ;
	}
}
