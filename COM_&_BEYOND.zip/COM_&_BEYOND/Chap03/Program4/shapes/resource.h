//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by shapes.rc
//
#define IDR_MAINFRAME                   101
#define IDR_CHILDFRAME2                 105
#define IDR_CHILDFRAME                  444
#define IDR_CHILDFRAME1                 444
#define ID_COLOR_BLACK                  40008
#define ID_COLOR_BLUE                   40009
#define ID_COLOR_GREEN                  40010
#define ID_COLOR_CYAN                   40011
#define ID_COLOR_RED                    40012
#define ID_COLOR_MAGENTA                40013
#define ID_COLOR_YELLOW                 40014
#define ID_COLOR_WHITE                  40015
#define ID_WIDTH_VTHIN                  40017
#define ID_WIDTH_THIN                   40018
#define ID_WIDTH_MEDIUM                 40019
#define ID_WIDTH_THICK                  40020
#define ID_WIDTH_VTHICK                 40021
#define ID_LINE                         40025
#define ID_RECTANGLE                    40026
#define ID_BLACK_BRUSH                  40027
#define ID_BLUE_BRUSH                   40028
#define ID_GREEN_BRUSH                  40029
#define ID_CYAN_BRUSH                   40030
#define ID_RED_BRUSH                    40031
#define ID_MAGENTA_BRUSH                40032
#define ID_YELLOW_BRUSH                 40033
#define ID_WHITE_BRUSH                  40034
#define ID_NULL_BRUSH                   40035
#define ID_FILE_NEW                     0xE100
#define ID_FILE_OPEN                    0xE101
#define ID_FILE_MRU_FILE1               0xE110

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40036
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
