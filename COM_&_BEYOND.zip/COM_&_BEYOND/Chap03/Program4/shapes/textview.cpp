#include <afxwin.h>
#include "cshape.h"
#include "cline.h"
#include "crect.h"
#include "mydoc_lnrt.h"
#include "textview.h"

IMPLEMENT_DYNCREATE ( textview, CScrollView ) 

void textview::OnDraw ( CDC *p ) 
{ 
	mydoc_lnrt *doc = ( mydoc_lnrt * ) GetDocument( ) ;

	CString linecountstr, rectcountstr, shapestr, linecolorstr, linewidthstr, brushcolorstr ;

	linecountstr.Format ( "linecount : %u", doc -> getlinecount( ) ) ;
	rectcountstr.Format ( "rectcount : %u", doc -> getrectcount( ) ) ;

	p -> TextOut ( 10, 10, linecountstr, strlen ( linecountstr ) ) ;
	p -> TextOut ( 10, 40, rectcountstr, strlen ( rectcountstr ) ) ;

	switch ( doc -> getshape( ) )
	{
		case 'L' :
			shapestr = "Line" ;
			break ;

		case 'R' :
			shapestr = "Rectangle" ; 
			break ;
	}

	p -> TextOut ( 10, 70, shapestr, strlen ( shapestr ) ) ;

	int R = GetRValue ( doc -> getcolor( ) ) ;
	int G = GetGValue ( doc -> getcolor( ) ) ;
	int B = GetBValue ( doc -> getcolor( ) ) ;

	linecolorstr.Format ( "Line Color : RGB ( %3u, %3u, %3u )", R, G, B ) ;
	p -> TextOut ( 10, 100, linecolorstr, strlen ( linecolorstr ) ) ;
	
	linewidthstr.Format ( "Line Width : %u", doc -> getwidth( ) ) ;
	p -> TextOut ( 10, 130, linewidthstr, strlen ( linewidthstr ) ) ;

	if ( doc -> getbrushstyle( ) == PS_SOLID )
	{
		R = GetRValue ( doc -> getbrushcolor( ) ) ;
		G = GetGValue ( doc -> getbrushcolor( ) ) ;
		B = GetBValue ( doc -> getbrushcolor( ) ) ;

		brushcolorstr.Format ( "Brush Color : RGB ( %3u, %3u, %3u )", R, G, B ) ;
	}
	else
		brushcolorstr = "Null Brush" ;

	p -> TextOut ( 10, 160, brushcolorstr, strlen ( brushcolorstr ) ) ;
}
