class mydoc_cir : public CDocument
{
	DECLARE_DYNCREATE ( mydoc_cir ) 
		
	private :

		CObArray arr ;

		static const int linewidth[5] ;
		static const COLORREF linecolor[8] ;

		static const COLORREF brushcolor[8] ;
		static const UINT brushstyle[2] ;

		int wd ;
		COLORREF clr ;
		int br_sty ;
		COLORREF br_clr ;

		int circlecount ;

	public :
		
		mydoc_cir( ) ;
		BOOL OnNewDocument( ) ;
		BOOL OnOpenDocument ( LPCTSTR filepath ) ;
		void init_width_color_brush_shape( ) ;
		ccircle* getobject ( int i ) ;
		int getobjectscount( ) ;
		void Serialize ( CArchive &ar ) ;
		ccircle* addcircle ( CPoint from, CPoint to ) ;
		void onwidth ( UINT id ) ;
		void oncolor ( UINT id ) ;
		char getshape( ) ;
		void onbrush ( UINT id ) ;
		int getwidth( ) ;
		COLORREF getcolor( ) ;
		UINT getbrushstyle( ) ;
		COLORREF getbrushcolor( ) ;
		void DeleteContents( ) ;

	DECLARE_MESSAGE_MAP( )
} ;
