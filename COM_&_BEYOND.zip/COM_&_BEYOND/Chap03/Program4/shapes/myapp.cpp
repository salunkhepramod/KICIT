#include <afxwin.h>
#include <afxext.h>
#include "cshape.h"
#include "cline.h"
#include "crect.h"
#include "ccircle.h"
#include "mydoc_lnrt.h"
#include "mydoc_cir.h"
#include "textview.h"
#include "graphicsview_lnrt.h"
#include "graphicsview_cir.h"
#include "myframe.h"
#include "mychildwnd.h"
#include "myapp.h"

#include "resource.h"

myapp a ;

BEGIN_MESSAGE_MAP ( myapp, CWinApp )

	ON_COMMAND ( ID_FILE_NEW, CWinApp::OnFileNew ) 
	ON_COMMAND ( ID_FILE_OPEN, CWinApp::OnFileOpen ) 

END_MESSAGE_MAP( )

BOOL myapp::InitInstance( )
{
	SetRegistryKey ( "Drawing Software" ) ;
	LoadStdProfileSettings( ) ;

	// first document type
	d = RUNTIME_CLASS ( mydoc_lnrt ) ;
	cf = RUNTIME_CLASS ( mychildwnd ) ;
	v = RUNTIME_CLASS ( graphicsview_lnrt ) ;
	CMultiDocTemplate *t ;
	t = new CMultiDocTemplate ( IDR_CHILDFRAME1, d, cf, v ) ;
	AddDocTemplate ( t ) ;
	////////////////////////////////////

	// second document type
	d = RUNTIME_CLASS ( mydoc_cir ) ;
	cf = RUNTIME_CLASS ( CMDIChildWnd ) ;
	v = RUNTIME_CLASS ( graphicsview_cir ) ;
	t = new CMultiDocTemplate ( IDR_CHILDFRAME2, d, cf, v ) ;
	AddDocTemplate ( t ) ;
	////////////////////////////////////

	myframe *f = new myframe ;
	f -> LoadFrame ( IDR_MAINFRAME ) ;
	m_pMainWnd = f ;

	EnableShellOpen( ) ;

	RegisterShellFileTypes ( TRUE ) ;

	CCommandLineInfo str ;
	ParseCommandLine ( str ) ;

	if ( !ProcessShellCommand ( str ) )
		return FALSE ;

	m_pMainWnd -> DragAcceptFiles( ) ;

	f -> ShowWindow ( SW_SHOWMAXIMIZED ) ;

	return TRUE ;
} 
