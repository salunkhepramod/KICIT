class graphicsview_cir : public CScrollView
{
	DECLARE_DYNCREATE ( graphicsview_cir ) ;

	private :

		CPoint str_pt ;
		CPoint end_pt ;
	
	public :

		void OnInitialUpdate( ) ;
		void OnDraw ( CDC *p ) ;
		void OnLButtonDown ( UINT flags, CPoint pt ) ;
		void OnMouseMove ( UINT flags, CPoint pt ) ;
		void OnLButtonUp ( UINT flags, CPoint pt ) ;

	DECLARE_MESSAGE_MAP( )
} ;
