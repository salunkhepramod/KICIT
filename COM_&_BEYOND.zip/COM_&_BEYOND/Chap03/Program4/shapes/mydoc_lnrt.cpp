#include <afxwin.h>
#include "cshape.h"
#include "cline.h"
#include "crect.h"
#include "mydoc_lnrt.h"

#include "resource.h"

IMPLEMENT_DYNCREATE ( mydoc_lnrt, CDocument ) 

BEGIN_MESSAGE_MAP ( mydoc_lnrt, CDocument )

	ON_COMMAND_RANGE ( ID_WIDTH_VTHIN, ID_WIDTH_VTHICK, 
  							  onwidth ) 
	ON_COMMAND_RANGE ( ID_COLOR_BLACK, 	ID_COLOR_WHITE, 
							  oncolor ) 
	ON_COMMAND_RANGE ( ID_BLACK_BRUSH, 	ID_NULL_BRUSH, 
							  onbrush ) 
	ON_COMMAND_RANGE ( ID_LINE, ID_RECTANGLE, onshape ) 

END_MESSAGE_MAP( )

const int mydoc_lnrt::linewidth[5] = { 1, 8, 16, 24, 32 } ;

const COLORREF mydoc_lnrt::linecolor[8] = 
{ 
	RGB ( 0, 0, 0 ), 
	RGB ( 0, 0, 255 ), 
	RGB ( 0, 255, 0 ), 
	RGB ( 0, 255, 255 ), 
	RGB ( 255, 0, 0 ), 
	RGB ( 255, 0, 255 ), 
	RGB ( 255, 255, 0 ), 
	RGB ( 255, 255, 255 ), 
} ;		

const UINT mydoc_lnrt::brushstyle[2] = { BS_SOLID, BS_NULL } ;

const COLORREF mydoc_lnrt::brushcolor[8] = 
{ 
	RGB ( 0, 0, 0 ), 
	RGB ( 0, 0, 255 ), 
	RGB ( 0, 255, 0 ), 
	RGB ( 0, 255, 255 ), 
	RGB ( 255, 0, 0 ), 
	RGB ( 255, 0, 255 ), 
	RGB ( 255, 255, 0 ), 
	RGB ( 255, 255, 255 ), 
} ;		

mydoc_lnrt::mydoc_lnrt( )
{
	arr.SetSize ( 0, 100 ) ;
}

BOOL mydoc_lnrt::OnNewDocument( )
{
	if ( !CDocument::OnNewDocument( ) )
		return FALSE ;

	linecount = rectcount = 0 ;

	init_width_color_brush_shape( ) ;
	
	return true ;
}

BOOL mydoc_lnrt::OnOpenDocument ( LPCTSTR filepath )
{
	if ( !CDocument::OnOpenDocument ( filepath ) )
		return FALSE ;

	init_width_color_brush_shape( ) ;

	return true ;
}

void mydoc_lnrt::init_width_color_brush_shape( )
{
	wd = linewidth[0] ;
	clr = linecolor[0] ;
			
	currentshape = 'L' ;
		
	br_sty = brushstyle[0] ;
	br_clr = brushcolor[1] ;
}

cshape* mydoc_lnrt::getobject ( int i )
{
	return ( cshape* ) arr[i] ;
}

int mydoc_lnrt::getobjectscount( )
{
	return arr.GetSize( ) ;
}

void mydoc_lnrt::Serialize ( CArchive &ar )
{
	arr.Serialize ( ar ) ;

	if ( ar.IsStoring( ) ) 
		ar << linecount << rectcount ;
	else
		ar >> linecount >> rectcount ;
}

cline* mydoc_lnrt::addline ( CPoint from, CPoint to )
{
	cline *line ;
	line = new cline ( from, to, wd, clr ) ;

	arr.Add ( line ) ;

	SetModifiedFlag( ) ;

	UpdateAllViews ( NULL ) ;

	linecount++ ;

	return line ;
}

crect* mydoc_lnrt::addrect ( CPoint from, CPoint to )
{
	crect *rect ;
	rect = new crect ( from, to, wd, clr, br_sty, br_clr ) ;

	arr.Add ( rect ) ;

	SetModifiedFlag( ) ;

	UpdateAllViews ( NULL ) ;

	rectcount++ ;

	return rect ;
}

void mydoc_lnrt::onwidth ( UINT id )
{
	wd = linewidth[id - ID_WIDTH_VTHIN] ;

	POSITION pos = GetFirstViewPosition( ) ;
	CView *v = ( CView * ) GetNextView ( pos ) ;
	UpdateAllViews ( v ) ;
}

void mydoc_lnrt::oncolor ( UINT id )
{
	clr = linecolor[id - ID_COLOR_BLACK] ;

	POSITION pos = GetFirstViewPosition( ) ;
	CView *v = ( CView * ) GetNextView ( pos ) ;
	UpdateAllViews ( v ) ;
}

void mydoc_lnrt::onshape ( UINT id )
{
	switch ( id ) 
	{
		case ID_LINE :
			currentshape = 'L' ;
			break ;

		case ID_RECTANGLE :
			currentshape = 'R' ;
			break ;
	}

	POSITION pos = GetFirstViewPosition( ) ;
	CView *v = ( CView * ) GetNextView ( pos ) ;
	UpdateAllViews ( v ) ;
}

char mydoc_lnrt::getshape( )
{
	return currentshape ;
}

void mydoc_lnrt::onbrush ( UINT id )
{
	switch ( id )
	{
		case ID_BLACK_BRUSH :
		case ID_BLUE_BRUSH :
		case ID_GREEN_BRUSH :
		case ID_CYAN_BRUSH :
		case ID_RED_BRUSH :
		case ID_MAGENTA_BRUSH :
		case ID_YELLOW_BRUSH :
		case ID_WHITE_BRUSH :

			br_sty = brushstyle[0] ;
			br_clr = brushcolor[id - ID_BLACK_BRUSH] ;
			break ;

		case ID_NULL_BRUSH :

			br_sty = brushstyle[1] ;
			break ;
	}

	POSITION pos = GetFirstViewPosition( ) ;
	CView *v = ( CView * ) GetNextView ( pos ) ;
	UpdateAllViews ( v ) ;
}

int mydoc_lnrt::getwidth( )
{
	return ( wd ) ;
}

COLORREF mydoc_lnrt::getcolor( )
{
	return ( clr ) ;
}

UINT mydoc_lnrt::getbrushstyle( )
{
	return ( br_sty ) ;
}

COLORREF mydoc_lnrt::getbrushcolor( )
{
	return ( br_clr ) ;
}

void mydoc_lnrt::DeleteContents( )
{
	int count = arr.GetSize( ) ;

	for ( int i = 0 ; i < count ; i++ )
		delete arr[i] ;

	arr.RemoveAll( ) ;
}

int mydoc_lnrt::getlinecount( )
{
	return linecount ;
}

int mydoc_lnrt::getrectcount( )
{
	return rectcount ;
}