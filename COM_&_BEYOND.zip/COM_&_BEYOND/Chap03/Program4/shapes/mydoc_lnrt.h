class mydoc_lnrt : public CDocument
{
	DECLARE_DYNCREATE ( mydoc_lnrt ) 
		
	private :

		CObArray arr ;

		static const int linewidth[5] ;
		static const COLORREF linecolor[8] ;

		static const COLORREF brushcolor[8] ;
		static const UINT brushstyle[2] ;

		char currentshape ;

		int wd ;
		COLORREF clr ;
		int br_sty ;
		COLORREF br_clr ;

		int linecount, rectcount ;

	public :
		
		mydoc_lnrt( ) ;
		BOOL OnNewDocument( ) ;
		BOOL OnOpenDocument ( LPCTSTR filepath ) ;
		void init_width_color_brush_shape( ) ;
		cshape* getobject ( int i ) ;
		int getobjectscount( ) ;
		void Serialize ( CArchive &ar ) ;
		cline* addline ( CPoint from, CPoint to ) ;
		crect* addrect ( CPoint from, CPoint to ) ;
		void onwidth ( UINT id ) ;
		void oncolor ( UINT id ) ;
		void onshape ( UINT id ) ;
		char getshape( ) ;
		void onbrush ( UINT id ) ;
		int getwidth( ) ;
		COLORREF getcolor( ) ;
		UINT getbrushstyle( ) ;
		COLORREF getbrushcolor( ) ;
		void DeleteContents( ) ;
		int getlinecount( ) ;
		int getrectcount( ) ;

	DECLARE_MESSAGE_MAP( )
} ;
