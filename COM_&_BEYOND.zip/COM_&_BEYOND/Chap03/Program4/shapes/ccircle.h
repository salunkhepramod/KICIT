class ccircle : public CObject
{
	DECLARE_SERIAL ( ccircle ) 

	private :	

		CPoint startpt ;
		CPoint endpt ;
		int lnwidth ;
		COLORREF lncolor ;
		UINT brstyle ;
		COLORREF brcolor ;

	public :

		ccircle( ) ;
		ccircle ( CPoint from, CPoint to, int wd, COLORREF clr, UINT brsty, 
				COLORREF brclr ) ;
		void Serialize ( CArchive &ar ) ;
		void draw ( CDC *p ) ;
} ;
