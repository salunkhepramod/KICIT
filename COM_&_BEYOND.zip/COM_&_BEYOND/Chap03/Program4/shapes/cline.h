class cline : public cshape
{
	DECLARE_SERIAL ( cline ) 

	private :	

		CPoint startpt ;
		CPoint endpt ;
		int width ;
		COLORREF color ;

	public :

		static int linecount ;

		cline( ) ;
		cline ( CPoint from, CPoint to, int wd, COLORREF clr ) ;
		void Serialize ( CArchive &ar ) ;
		void draw ( CDC *p ) ;
} ;
