// Machine generated IDispatch wrapper class(es) created with ClassWizard
/////////////////////////////////////////////////////////////////////////////
// IMyMath wrapper class

class IMyMath : public COleDispatchDriver
{
public:
	IMyMath() {}		// Calls COleDispatchDriver default constructor
	IMyMath(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	IMyMath(const IMyMath& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

// Attributes
public:

// Operations
public:
	long MyAdd(short x, short y);
	long MySubtract(short x, short y);
};
