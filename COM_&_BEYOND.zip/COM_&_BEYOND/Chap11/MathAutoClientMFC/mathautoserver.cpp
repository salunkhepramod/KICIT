// Machine generated IDispatch wrapper class(es) created with ClassWizard

#include "stdafx.h"
#include "mathautoserver.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



/////////////////////////////////////////////////////////////////////////////
// IMyMath properties

/////////////////////////////////////////////////////////////////////////////
// IMyMath operations

long IMyMath::MyAdd(short x, short y)
{
	long result;
	static BYTE parms[] =
		VTS_I2 VTS_I2;
	InvokeHelper(0x1, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		x, y);
	return result;
}

long IMyMath::MySubtract(short x, short y)
{
	long result;
	static BYTE parms[] =
		VTS_I2 VTS_I2;
	InvokeHelper(0x2, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		x, y);
	return result;
}
