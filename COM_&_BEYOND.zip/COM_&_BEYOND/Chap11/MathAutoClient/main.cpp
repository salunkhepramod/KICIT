// File Main.cpp
// The file contains Automation Controller code. 

#include <stdio.h>
#include<objbase.h>
static const CLSID AUTOMATH_CLSID = 
	{0xe50e1890, 0x7cc, 0x11d3 ,
		{0xa6, 0xf3, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0}
	};
#define NUM_ARGS 2

int main(void)
{

	IClassFactory *pclsf;
	IDispatch *pDsp;
	VARIANTARG varg[NUM_ARGS];
	VARIANT result;
	DISPID dispid;
	DISPPARAMS params;
	
	//Initialize the OLE libraries
	CoInitialize(NULL);
	
	// get the IClassFactory interface pointer
	HRESULT hr = CoGetClassObject(
					AUTOMATH_CLSID,
					CLSCTX_LOCAL_SERVER,
					NULL,
					IID_IClassFactory,
					(void **)&pclsf);
	if ( !SUCCEEDED(hr) )
	{
		printf("CoGetClassObject failed with error %x\n",hr);
		return 1;
	}
	
	// use IClassFactory's createInstance to create the COM object
	// and get the IDispatch interface pointer.
	hr = pclsf->CreateInstance(
					NULL,
					IID_IDispatch,
					(void **)&pDsp);
	if ( !SUCCEEDED(hr) )
	{
		printf("Class Factory CreateInstance failed with error %x\n",hr);
		return 1;
	}
	

	// Get the dispatch id for MySubtract method.
	OLECHAR *funcName = L"MySubtract";
	hr = pDsp->GetIDsOfNames(IID_NULL,
							 &funcName,
							 1,
							 GetUserDefaultLCID(),
							 &dispid);
	if ( !SUCCEEDED(hr) )
	{
		printf("IDispatch GetIDsOfNames failed with error %x\n",hr);
		pDsp->Release();	
		pclsf->Release();
		return 1;
	}
	
	// Use IDispatch->Invoke to call MySubtract method.
	for ( int i=0; i < NUM_ARGS; i++)
		::VariantInit(&varg[i]);
	varg[0].vt = VT_I2;
	varg[1].vt = VT_I2;
	V_I2(&varg[0]) = 111;
	V_I2(&varg[1]) = 222;
	params.cArgs = 2;
	params.rgvarg = varg;
	params.cNamedArgs = 0;
	params.rgdispidNamedArgs = NULL;

	::VariantInit(&result);
	result.vt = VT_I4;
	V_I4(&result) = 0;  // initialization.

	unsigned int err;
	hr = pDsp->Invoke( dispid,
					   IID_NULL,
					   GetUserDefaultLCID(),
					   DISPATCH_METHOD,
					   &params,
					   &result,
					   NULL,
					   &err);
	if ( !SUCCEEDED(hr) )
	{
		printf("IDispatch Invoke  failed with error %x\n",hr);	
	}
	else
		printf("The automation subtraction returned  %d -  %d = %d\n",
			V_I2(&varg[1]), V_I2(&varg[0]), V_I4(&result) );

	pDsp->Release();	
	pclsf->Release();
	return 0;
}




