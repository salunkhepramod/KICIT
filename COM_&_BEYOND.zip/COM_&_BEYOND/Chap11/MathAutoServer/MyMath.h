#if !defined(AFX_MYMATH_H__2EA0A936_0C94_11D3_A6F9_000000000000__INCLUDED_)
#define AFX_MYMATH_H__2EA0A936_0C94_11D3_A6F9_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// MyMath.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CMyMath command target

class CMyMath : public CCmdTarget
{
	DECLARE_DYNCREATE(CMyMath)

	CMyMath();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyMath)
	public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMyMath();

	// Generated message map functions
	//{{AFX_MSG(CMyMath)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	DECLARE_OLECREATE(CMyMath)

	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CMyMath)
	afx_msg long MyAdd(short x, short y);
	afx_msg long MySubtract(short x, short y);
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYMATH_H__2EA0A936_0C94_11D3_A6F9_000000000000__INCLUDED_)
