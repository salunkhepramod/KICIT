// MyMath.cpp : implementation file
//

#include "stdafx.h"
#include "mathautoserver.h"
#include "MyMath.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyMath

IMPLEMENT_DYNCREATE(CMyMath, CCmdTarget)

CMyMath::CMyMath()
{
	EnableAutomation();
	
	// To keep the application running as long as an OLE automation 
	//	object is active, the constructor calls AfxOleLockApp.
	
	AfxOleLockApp();
}

CMyMath::~CMyMath()
{
	// To terminate the application when all objects created with
	// 	with OLE automation, the destructor calls AfxOleUnlockApp.
	
	AfxOleUnlockApp();
}


void CMyMath::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}


BEGIN_MESSAGE_MAP(CMyMath, CCmdTarget)
	//{{AFX_MSG_MAP(CMyMath)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CMyMath, CCmdTarget)
	//{{AFX_DISPATCH_MAP(CMyMath)
	DISP_FUNCTION(CMyMath, "MyAdd", MyAdd, VT_I4, VTS_I2 VTS_I2)
	DISP_FUNCTION(CMyMath, "MySubtract", MySubtract, VT_I4, VTS_I2 VTS_I2)
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IMyMath to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {2EA0A935-0C94-11D3-A6F9-000000000000}
static const IID IID_IMyMath =
{ 0x2ea0a935, 0xc94, 0x11d3, { 0xa6, 0xf9, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0 } };

BEGIN_INTERFACE_MAP(CMyMath, CCmdTarget)
	INTERFACE_PART(CMyMath, IID_IMyMath, Dispatch)
END_INTERFACE_MAP()

// {E50E1890-07CC-11D3-A6F3-000000000000}
IMPLEMENT_OLECREATE(CMyMath, "MathAutoServer.CMyMath", 0xe50e1890, 0x7cc, 0x11d3, 0xa6, 0xf3, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0)

/////////////////////////////////////////////////////////////////////////////
// CMyMath message handlers

long CMyMath::MyAdd(short x, short y) 
{
	// TODO: Add your dispatch handler code here

	return x+y;
}

long CMyMath::MySubtract(short x, short y) 
{
	// TODO: Add your dispatch handler code here

	return x-y;
}
