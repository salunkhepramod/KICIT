#include <afxwin.h>

#include "mydoc.h"
#include "myframe.h"
#include "myview.h"
#include "myapp.h"

#include "resource.h"

myapp a ;

BOOL myapp::InitInstance( )
{
	CRuntimeClass *d, *f, *v ;

	d = RUNTIME_CLASS ( mydoc ) ;
	f = RUNTIME_CLASS ( myframe ) ;
	v = RUNTIME_CLASS ( myview ) ;

	CSingleDocTemplate *t ;

	t = new CSingleDocTemplate ( IDR_MAINFRAME, d, f, v ) ;
	AddDocTemplate ( t ) ;

	CCommandLineInfo c ;
	ParseCommandLine ( c ) ;

	if ( !ProcessShellCommand ( c ) )
		return FALSE ;

	return TRUE;
}