#include <gl\gl.h>

class myview : public CView
{
	DECLARE_DYNCREATE ( myview ) ;

	private :

		HGLRC m_hGRC ;
		HPALETTE m_hpalette ;
		CClientDC *m_d ;

	public :

		BOOL PreCreateWindow ( CREATESTRUCT& cs ) ;

		int OnCreate ( LPCREATESTRUCT l ) ;
		void OnSize ( UINT type, int cx, int cy ) ;
		void OnDraw ( CDC *p ) ;
		void drawline( ) ;
		void setuplogicalpalette( ) ;
		void OnDestroy( ) ;

	DECLARE_MESSAGE_MAP( )
} ;