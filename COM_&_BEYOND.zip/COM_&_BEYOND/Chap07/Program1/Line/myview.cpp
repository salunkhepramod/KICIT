#include <afxwin.h>
#include "myview.h"

#include "resource.h"

IMPLEMENT_DYNCREATE ( myview, CView ) 

BEGIN_MESSAGE_MAP ( myview, CView )

	ON_WM_CREATE( )
	ON_WM_SIZE( )
	ON_WM_DESTROY( ) 

END_MESSAGE_MAP( )

BOOL myview::PreCreateWindow ( CREATESTRUCT& cs )
{
	cs.style |= WS_CLIPCHILDREN | WS_CLIPSIBLINGS ;
	return CView::PreCreateWindow ( cs ) ;
}

int myview::OnCreate ( LPCREATESTRUCT l )
{
	CView::OnCreate ( l ) ;

	PIXELFORMATDESCRIPTOR pfd =
	{
		sizeof ( PIXELFORMATDESCRIPTOR ), 
		1,
		PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL,
		PFD_TYPE_RGBA,
		24,
		0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 
		32,
		0, 0,
		PFD_MAIN_PLANE,
		0,
		0, 0, 0
	} ;

	m_d = new CClientDC ( this ) ;

	int pixformat = ChoosePixelFormat ( m_d -> m_hDC, &pfd ) ;
	SetPixelFormat ( m_d -> m_hDC, pixformat, &pfd ) ;

	DescribePixelFormat ( m_d -> m_hDC, pixformat, sizeof ( pfd ), &pfd ) ;

	if ( pfd.dwFlags & PFD_NEED_PALETTE )
		setuplogicalpalette( ) ;

	m_hGRC = wglCreateContext ( m_d -> m_hDC ) ;
	wglMakeCurrent ( m_d -> m_hDC, m_hGRC ) ;

	return 0 ;
}

void myview::setuplogicalpalette( )
{
    struct
    {
        WORD ver ;
        WORD num ;
        PALETTEENTRY entries[256];
    } logicalpalette = { 0x300, 256 } ;

    BYTE reds[ ] = { 0, 20, 40, 120, 140, 180, 220, 255 } ;
    BYTE greens[ ] = { 0, 20, 40, 120, 140, 180, 220, 255 } ;
    BYTE blues[ ] = { 0, 20, 40, 120, 140, 180, 220, 255 } ;

    for ( int cn = 0 ; cn < 256 ; ++cn )
    {	
        logicalpalette.entries[cn].peRed = reds[cn & 0x07] ;
        logicalpalette.entries[cn].peGreen = greens[( cn >> 0x03 ) & 0x07] ;
        logicalpalette.entries[cn].peBlue = blues[( cn >> 0x06 ) & 0x03] ;
        logicalpalette.entries[cn].peFlags = 0 ;
    }

    m_hpalette = CreatePalette ( ( LOGPALETTE* ) &logicalpalette ) ;

	if ( m_hpalette )
	{
		SelectPalette ( m_d -> m_hDC, m_hpalette, FALSE ) ;
		RealizePalette ( m_d -> m_hDC ) ;
	}
}

void myview::OnSize ( UINT type, int cx, int cy )
{
	glViewport ( 0, 0, cx, cy ) ;
}

void myview::OnDraw ( CDC *p )
{
	drawline( ) ;
}

void myview::drawline( ) 
{
	glClearColor ( 0.0f, 0.0f, 0.0f, 0.0f ) ;
	glClear ( GL_COLOR_BUFFER_BIT ) ;

    glBegin ( GL_LINES ) ;

		glColor3f ( 0.0f, 1.0f, 0.0f ) ; 
        glVertex2f ( 0.25f, 0.25f ) ;
        glVertex2f ( 0.75f, 0.25f ) ;

	glEnd( ) ;

	glFlush( ) ;
}

void myview::OnDestroy( )
{
//	wglMakeCurrent ( NULL, NULL ) ;
	wglDeleteContext ( m_hGRC ) ;


	if ( m_hpalette )
		DeleteObject ( m_hpalette ) ;

	delete m_d ;
}