#include <afxwin.h>
#include "mydoc.h"

IMPLEMENT_DYNCREATE ( mydoc, CDocument ) 