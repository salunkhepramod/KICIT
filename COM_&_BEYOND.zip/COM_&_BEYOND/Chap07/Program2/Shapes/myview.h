#include <gl\gl.h>

class myview : public CView
{
	DECLARE_DYNCREATE ( myview )

	private :

		HGLRC m_hGRC ;
		HPALETTE m_hpalette ;
		CClientDC *m_d ;

		int color, shape ;
		GLfloat rr, gg, bb ;

	public :

		BOOL PreCreateWindow ( CREATESTRUCT& cs ) ;
		int OnCreate ( LPCREATESTRUCT l ) ;
		void OnSize ( UINT type, int cx, int cy ) ;
		void OnDraw ( CDC *p ) ;
		void drawshapes( ) ;
		void setuplogicalpalette( ) ;
		void red( ) ;
		void green( ) ;
		void blue( ) ;

		void onshape ( int id ) ;
		void drawpixels( ) ;
		void drawlines( ) ;
		void drawlinestrips( ) ;
		void drawlineloop( ) ;
		void drawpolygons( ) ;
		void drawtriangles( ) ;
		void drawtrianglestrips( ) ;
		void drawtrianglefan( ) ;
		void drawquads( ) ;
		void drawquadstrips( ) ;

		void OnDestroy( ) ;

	DECLARE_MESSAGE_MAP( )
} ;
