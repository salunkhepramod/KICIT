#include <afxwin.h>
#include "myview.h"

#include "resource.h"

#define RED		1
#define GREEN	2
#define BLUE	3

#define PIXELS			4
#define LINES			5
#define LINESTRIPS		6
#define LINELOOP		7
#define POLYGONS		8
#define TRIANGLES		9
#define TRIANGLESTRIPS	10
#define TRIANGLEFAN		11
#define QUADS			12
#define QUADSTRIPS		13

IMPLEMENT_DYNCREATE ( myview, CView ) 

BEGIN_MESSAGE_MAP ( myview, CView )

	ON_WM_CREATE( )
	ON_WM_SIZE( )
	
	ON_COMMAND ( 101, red )
	ON_COMMAND ( 102, green )
	ON_COMMAND ( 103, blue )

	ON_COMMAND_RANGE ( 201, 210, onshape )

	ON_WM_DESTROY( ) 

END_MESSAGE_MAP( )

BOOL myview::PreCreateWindow ( CREATESTRUCT& cs )
{
	cs.style |= WS_CLIPCHILDREN | WS_CLIPSIBLINGS ;
	return CView::PreCreateWindow ( cs ) ;
}

int myview::OnCreate ( LPCREATESTRUCT l )
{
	CView::OnCreate ( l ) ;

	PIXELFORMATDESCRIPTOR pfd =
	{
		sizeof ( PIXELFORMATDESCRIPTOR ), 
		1,
		PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL,
		PFD_TYPE_RGBA,
		24,
		0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 
		32,
		0, 0,
		PFD_MAIN_PLANE,
		0,
		0, 0, 0
	} ;

	m_d = new CClientDC ( this ) ;

	int index = ChoosePixelFormat ( m_d -> m_hDC, &pfd ) ;
	SetPixelFormat ( m_d -> m_hDC, index, &pfd ) ;

	DescribePixelFormat ( m_d -> m_hDC, index, sizeof ( pfd ), &pfd ) ;

	if ( pfd.dwFlags & PFD_NEED_PALETTE )
		setuplogicalpalette( ) ;

	m_hGRC = wglCreateContext ( m_d -> m_hDC ) ;
	wglMakeCurrent ( m_d -> m_hDC, m_hGRC ) ;

	color = RED ;
	rr = 1.0f ;
	gg = bb = 0.0f ;

	shape = PIXELS ;

	return 0 ;
}

void myview::setuplogicalpalette( )
{
    struct
    {
        WORD ver ;
        WORD num ;
        PALETTEENTRY entries[256];
    } logicalpalette = { 0x300, 256 };

    BYTE reds[ ] = { 0, 20, 40, 120, 140, 180, 220, 255 } ;
    BYTE greens[ ] = { 0, 20, 40, 120, 140, 180, 220, 255 } ;
    BYTE blues[ ] = { 0, 20, 40, 120, 140, 180, 220, 255 } ;

    for ( int cn = 0 ; cn < 256 ; ++cn )
    {	
        logicalpalette.entries[cn].peRed = reds[cn & 0x07] ;
        logicalpalette.entries[cn].peGreen = greens[( cn >> 0x03 ) & 0x07] ;
        logicalpalette.entries[cn].peBlue = blues[( cn >> 0x06 ) & 0x03] ;
        logicalpalette.entries[cn].peFlags = 0 ;
    }

    m_hpalette = CreatePalette ( ( LOGPALETTE* ) &logicalpalette ) ;

	if ( m_hpalette )
	{
		SelectPalette ( m_d -> m_hDC, m_hpalette, FALSE ) ;
		RealizePalette ( m_d -> m_hDC ) ;
	}
}

void myview::OnSize ( UINT type, int cx, int cy )
{
	glViewport ( 0, 0, cx, cy ) ;
}

void myview::OnDraw ( CDC *p )
{
	drawshapes( ) ;
}

void myview::drawshapes( )
{
	glClearColor ( 0.0f, 0.0f, 0.0f, 0.0f ) ; 
	glClear ( GL_COLOR_BUFFER_BIT ) ;
	glColor3f ( rr, gg, bb ) ;

	switch ( shape )
	{
		case PIXELS : 

			drawpixels( ) ; 
			break;

		case LINES : 

			drawlines( ) ; 
			break;

		case LINESTRIPS : 

			drawlinestrips( ) ; 
			break;

		case LINELOOP : 

			drawlineloop( ) ; 
			break;

		case POLYGONS : 

			drawpolygons( ) ; 
			break;

		case TRIANGLES : 

			drawtriangles( ) ; 
			break;

		case TRIANGLESTRIPS : 

			drawtrianglestrips( ) ; 
			break;

		case TRIANGLEFAN : 

			drawtrianglefan( ) ; 
			break;

		case QUADS : 

			drawquads( ) ; 
			break;

		case QUADSTRIPS : 

			drawquadstrips( ) ; 
			break;
	}

	glFlush( ) ;
} ;

void myview::red( )
{
	color = RED ;
	rr = 1.0f ;
	gg = 0.0f ;
	bb = 0.0f ;
	Invalidate( ) ;
}

void myview::green( )
{
	color = GREEN ;
	rr = 0.0f ;
	gg = 1.0f ;
	bb = 0.0f ;
	Invalidate( ) ;
}

void myview::blue( )
{
	color = BLUE ;
	rr = 0.0f ;
	gg = 0.0f ;
	bb = 1.0f ;
	Invalidate( ) ;
}

void myview::onshape ( int id )
{
	switch ( id ) 
	{
		case 201 :	

			shape = PIXELS ;
			Invalidate( ) ;
			break ;

		case 202 :	

			shape = LINES ;
			Invalidate( ) ;
			break ;

		case 203 :	

			shape = LINESTRIPS ;
			Invalidate( ) ;
			break ;

		case 204 :	

			shape = LINELOOP ;
			Invalidate( ) ;
			break ;

		case 205 :	

			shape = POLYGONS ;
			Invalidate( ) ;
			break ;

		case 206 :	

			shape = TRIANGLES ;
			Invalidate( ) ;
			break ;

		case 207 :	

			shape = TRIANGLESTRIPS ;
			Invalidate( ) ;
			break ;

		case 208 :	

			shape = TRIANGLEFAN ;
			Invalidate( ) ;
			break ;

		case 209 :	

			shape = QUADS ;
			Invalidate( ) ;
			break ;

		case 210 :	

			shape = QUADSTRIPS ;
			Invalidate( ) ;
			break ;
	}
}

void myview::drawpixels( )
{
	GLfloat ps[2] ;
	glGetFloatv ( GL_POINT_SIZE_RANGE, ps ) ;

	glPointSize ( ps[1] ) ;

	glBegin ( GL_POINTS ) ;

		glVertex2f ( 0.0f, 0.0f ) ;
		glVertex2f ( 0.75f, 0.75f ) ; 
		glVertex2f ( -0.75f, -0.75f ) ; 
		glVertex2f ( -0.75f, 0.75f ) ; 
		glVertex2f ( 0.75f, -0.75f ) ; 

	glEnd( ) ;
}

void myview::drawlines( )
{
	GLfloat lw[2] ;
	glGetFloatv ( GL_LINE_WIDTH_RANGE, lw ) ;

	if ( lw[1] >= 4.0f )
		glLineWidth ( 4.0f ) ;
	else
		glLineWidth ( lw[1] ) ;

	glBegin ( GL_LINES ) ;

		glVertex2f ( -0.75f, 0.75f ) ;
		glVertex2f ( -0.75f, -0.75f ) ;
            
		glVertex2f ( -0.25f, 0.75f ) ;
		glVertex2f ( -0.25f, -0.75f ) ;

	glEnd( ) ;

	glLineStipple ( 1, 0x3333 ) ;
	glEnable ( GL_LINE_STIPPLE ) ; 
 
	glBegin ( GL_LINES ) ;

		glVertex2f ( 0.25f, 0.75f ) ;
		glVertex2f ( 0.25f, -0.75f ) ;

		glVertex2f ( 0.75f, 0.75f ) ;
		glVertex2f ( 0.75f, -0.75f ) ;
            
	glEnd( ) ;

	glDisable ( GL_LINE_STIPPLE ) ;
}

void myview::drawlinestrips( )
{
	GLfloat lw[2] ;
	glGetFloatv ( GL_LINE_WIDTH_RANGE, lw ) ;

	if ( lw[1] >= 4.0f )
		glLineWidth ( 4.0f ) ;
	else 
		glLineWidth ( lw[1] ) ;

	glBegin ( GL_LINE_STRIP ) ;

		glVertex2f ( -0.75f, -1.0f ) ;
		glVertex2f ( -0.75f, 1.0f ) ; 

		glVertex2f ( -0.25f, -1.0f ) ;
		glVertex2f ( -0.25f, 1.0f ) ; 

		glVertex2f ( 0.25f, -1.0f ) ;
		glVertex2f ( 0.25f, 1.0f ) ;

		glVertex2f ( 0.75f, -1.0f ) ;
		glVertex2f ( 0.75f, 1.0f ) ;

	glEnd( ) ;
}

void myview::drawlineloop( )
{
	GLfloat lw[2] ;
	glGetFloatv ( GL_LINE_WIDTH_RANGE, lw ) ;

	if ( lw[1] >= 4.0f )
		glLineWidth ( 4.0f ) ;
	else 
		glLineWidth ( lw[1] ) ;

	glBegin ( GL_LINE_LOOP ) ;

		glVertex2f ( -0.75f, -1.0f ) ;
		glVertex2f ( -0.75f, 1.0f ) ; 

		glVertex2f ( -0.25f, -1.0f ) ;
		glVertex2f ( -0.25f, 1.0f ) ; 

		glVertex2f ( 0.25f, -1.0f ) ;
		glVertex2f ( 0.25f, 1.0f ) ;

		glVertex2f ( 0.75f, -1.0f ) ;
		glVertex2f ( 0.75f, 1.0f ) ;

	glEnd( ) ;
}

void myview::drawpolygons( )
{
	glLineWidth(1.0f) ;
	glPolygonMode ( GL_FRONT_AND_BACK, GL_LINE ) ;

	glBegin ( GL_POLYGON ) ;
	
		glVertex2f ( -0.5f, 0.75f ) ;
		glVertex2f ( -0.75f, 0.5f ) ;
		glVertex2f ( -0.75f, -0.25f ) ; 
		glVertex2f ( -0.5f, -0.75f ) ;
		glVertex2f ( -0.25f, -0.25f ) ;
		glVertex2f ( -0.25f, 0.5f ) ; 

	glEnd( ) ;

	GLubyte pattern[ ] =
	{
		0xff, 0x00, 0xff, 0x00, 0x0f, 0xf0, 0x0f, 0xf0,
		0x00, 0xff, 0x00, 0xff, 0x0f, 0xf0, 0x0f, 0xf0,
		0xff, 0x00, 0xff, 0x00, 0x0f, 0xf0, 0x0f, 0xf0,
		0x00, 0xff, 0x00, 0xff, 0x0f, 0xf0, 0x0f, 0xf0,
		0xff, 0x00, 0xff, 0x00, 0x0f, 0xf0, 0x0f, 0xf0,
		0x00, 0xff, 0x00, 0xff, 0x0f, 0xf0, 0x0f, 0xf0,
		0xff, 0x00, 0xff, 0x00, 0x0f, 0xf0, 0x0f, 0xf0,
		0x00, 0xff, 0x00, 0xff, 0x0f, 0xf0, 0x0f, 0xf0,
		0xff, 0x00, 0xff, 0x00, 0x0f, 0xf0, 0x0f, 0xf0,
		0x00, 0xff, 0x00, 0xff, 0x0f, 0xf0, 0x0f, 0xf0,
		0xff, 0x00, 0xff, 0x00, 0x0f, 0xf0, 0x0f, 0xf0,
		0x00, 0xff, 0x00, 0xff, 0x0f, 0xf0, 0x0f, 0xf0,
		0xff, 0x00, 0xff, 0x00, 0x0f, 0xf0, 0x0f, 0xf0,
		0x00, 0xff, 0x00, 0xff, 0x0f, 0xf0, 0x0f, 0xf0,
		0xff, 0x00, 0xff, 0x00, 0x0f, 0xf0, 0x0f, 0xf0,
		0x00, 0xff, 0x00, 0xff, 0x0f, 0xf0, 0x0f, 0xf0
	};

	glPolygonMode ( GL_FRONT_AND_BACK, GL_FILL ) ;
	glPolygonStipple ( pattern ) ;
	glEnable ( GL_POLYGON_STIPPLE ) ;

	glBegin ( GL_POLYGON ) ;

		glVertex2f ( 0.5f, 0.75f ) ;
		glVertex2f ( 0.25f, 0.5f ) ;
		glVertex2f ( 0.25f, -0.25f ) ;
		glVertex2f ( 0.5f, -0.75f ) ;
		glVertex2f ( 0.75f, -0.25f ) ;
		glVertex2f ( 0.75f, 0.5f ) ;

	glEnd( ) ;

	glDisable ( GL_POLYGON_STIPPLE ) ;
}

void myview::drawtriangles( )
{
	glPolygonMode ( GL_FRONT_AND_BACK, GL_LINE ) ;

	glBegin ( GL_TRIANGLES ) ;

		glVertex2f ( 0.0f, 0.3f ) ;
		glVertex2f ( -0.85f, -0.5f ) ;
		glVertex2f ( 0.0f, -0.5f ) ;

		glVertex2f ( 0.75f, 0.5f ) ;
		glVertex2f ( 0.75f, -0.5f ) ;
		glVertex2f ( 0.4f, -0.5f ) ;

	glEnd( ) ;
}

void myview::drawtrianglestrips( )
{
	glPolygonMode ( GL_FRONT_AND_BACK, GL_LINE ) ;

	glBegin ( GL_TRIANGLE_STRIP ) ;

		glVertex2f ( -0.75f, 0.25f ) ;
		glVertex2f ( -0.75f, -0.25f ) ;
		glVertex2f ( -0.25f, 0.25f ) ;

		glVertex2f ( 0.0f, -0.25f ) ;

		glVertex2f ( 0.25f, 0.5f ) ;

		glVertex2f ( 0.50f, 0.3f ) ;

		glVertex2f ( 0.75f, 0.3f ) ;

	glEnd( ) ;
}

void myview::drawtrianglefan( )
{
	glPolygonMode ( GL_FRONT_AND_BACK, GL_LINE ) ;

	glBegin ( GL_TRIANGLE_FAN ) ;

		glVertex2f ( -0.25f, 0.25f ) ;
		glVertex2f ( -0.25f, -0.25f ) ;
		glVertex2f ( 0.25f, 0.25f ) ;

		glVertex2f ( 0.25f, 0.5f ) ;

		glVertex2f ( -0.05f, 0.7f ) ;

		glVertex2f ( -0.45f, 0.5f ) ;

	glEnd( ) ;
}

void myview::drawquads( )
{
	glPolygonMode ( GL_FRONT_AND_BACK, GL_LINE ) ;

	glBegin ( GL_QUADS ) ;

		glVertex2f ( -0.75f, 0.75f ) ;
		glVertex2f ( -0.75f, 0.25f ) ;
		glVertex2f ( -0.25f, 0.0f ) ;
		glVertex2f ( 0.0f, 0.5f ) ;

		glVertex2f ( -0.55f, -0.25f);
		glVertex2f ( -0.75f, -0.45f);
		glVertex2f ( -0.25f, -0.7f);
		glVertex2f ( 0.5f, -0.25f);

	glEnd(  ) ;
}

void myview::drawquadstrips( )
{
	glPolygonMode ( GL_FRONT_AND_BACK, GL_LINE);

	glBegin ( GL_QUAD_STRIP);

		glVertex2f ( -0.75f, 0.25f ) ;
		glVertex2f ( -0.65f, 0.75f ) ;
		glVertex2f ( -0.55f, 0.1f ) ;
		glVertex2f ( -0.25f, 0.6f ) ;

		glVertex2f ( -0.15f, -0.2f ) ;
		glVertex2f ( 0.0f, 0.45f ) ;

		glVertex2f ( 0.25f, -0.7f ) ;
		glVertex2f ( 0.5f, 0.65f ) ;

		glVertex2f ( 0.75f, -0.3f ) ;
		glVertex2f ( 0.85f, 0.45f ) ; 

	glEnd( ) ;
}

void myview::OnDestroy( )
{
	wglDeleteContext ( m_hGRC ) ;


	if ( m_hpalette )
		DeleteObject ( m_hpalette ) ;

	delete m_d ;
}