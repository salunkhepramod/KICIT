// File Main.cpp
// The file contains Automation Controller code. 

#include <stdio.h>
#include<objbase.h>

static const CLSID AUTOMATH_CLSID = 
	{0xe50e1890, 0x7cc, 0x11d3 ,
		{0xa6, 0xf3, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0}
	};
#define NUM_ARGS 2

int main(int argc, char *argv[])
{

	WCHAR serverName[512];
	COSERVERINFO serverInfo;
	IClassFactory *pclsf;
	IDispatch *pDsp;
	VARIANTARG varg[NUM_ARGS];
	VARIANT result;
	DISPID dispid;
	DISPPARAMS params;
	MULTI_QI mqi[2];
	
	// fill in the remote server information.
	memset(&serverInfo, 0, sizeof( serverInfo));

	// convert  ascii to unicode in serverInfo.
	int y = MultiByteToWideChar(
				CP_ACP,
				0,
				argv[1],
				-1,
				serverName,
				512);
	serverInfo.pwszName = serverName;
	
	// fill in the information for the desired interfaces.
	mqi[0].pIID = &IID_IUnknown;
	mqi[0].pItf = NULL;
	mqi[0].hr   = S_OK;

	mqi[1].pIID = &IID_IDispatch;
	mqi[1].pItf = NULL;
	mqi[1].hr   = S_OK;

	//Initialize the OLE libraries
	CoInitialize(NULL);
	
	// get the IClassFactory interface pointer
	HRESULT hr = CoCreateInstanceEx(
					AUTOMATH_CLSID,
					NULL,
					CLSCTX_REMOTE_SERVER,
					&serverInfo,
					2,
					mqi);

	if ( !SUCCEEDED(hr) )
	{
		printf("CoCreateInstance failed: error = %x\n",hr);
		return 1;
	}
	

	if ( !SUCCEEDED(mqi[1].hr) )
	{
		printf("No IDispatch pointer: error = %x\n",hr);
		return 1;
	}
	
	pDsp = (IDispatch *)mqi[1].pItf;

	// Get the dispatch id for MySubtract method.
	OLECHAR *funcName = L"MySubtract";
	hr = pDsp->GetIDsOfNames(IID_NULL,
							 &funcName,
							 1,
							 GetUserDefaultLCID(),
							 &dispid);
	if ( !SUCCEEDED(hr) )
	{
		printf("IDispatch GetIDsOfNames failed: error =%x\n",hr);
		pDsp->Release();	
		pclsf->Release();
		return 1;
	}
	
	// Use IDispatch->Invoke to call MySubtract method.
	for ( int i=0; i < NUM_ARGS; i++)
		::VariantInit(&varg[i]);
	varg[0].vt = VT_I2;
	varg[1].vt = VT_I2;
	V_I2(&varg[0]) = 101;
	V_I2(&varg[1]) = 200;
	params.cArgs = 2;
	params.rgvarg = varg;
	params.cNamedArgs = 0;
	params.rgdispidNamedArgs = NULL;

	::VariantInit(&result);
	result.vt = VT_I4;
	V_I4(&result) = 0;  // initialization.

	unsigned int err;
	hr = pDsp->Invoke( dispid,
					   IID_NULL,
					   GetUserDefaultLCID(),
					   DISPATCH_METHOD,
					   &params,
					   &result,
					   NULL,
					   &err);
	if ( !SUCCEEDED(hr) )
	{
		printf("IDispatch Invoke  failed with error %x\n",hr);	
	}
	else
		printf("The automation subtraction returned  %d -  %d = %d\n",
			V_I2(&varg[1]), V_I2(&varg[0]), V_I4(&result) );

	mqi[0].pItf->Release();	
	mqi[1].pItf->Release();
	return 0;
}




