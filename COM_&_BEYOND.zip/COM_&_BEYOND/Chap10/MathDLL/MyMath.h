#if !defined(AFX_MYMATH_H__566A4393_FFEC_11D2_936E_000000000000__INCLUDED_)
#define AFX_MYMATH_H__566A4393_FFEC_11D2_936E_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// MyMath.h : header file
//
#include "interface.h"


/////////////////////////////////////////////////////////////////////////////
// CMyMath command target

class CMyMath : public CCmdTarget
{
	DECLARE_DYNCREATE(CMyMath)

	CMyMath();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyMath)
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMyMath();

	// Generated message map functions
	//{{AFX_MSG(CMyMath)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

	BEGIN_INTERFACE_PART(MyMathObj,IMyMath)
		STDMETHOD_(LONG, MyAdd) (INT, INT);
		STDMETHOD_(LONG,MySubtract) (INT, INT);
	END_INTERFACE_PART(MyMathObj)	
	
	DECLARE_INTERFACE_MAP()
	DECLARE_OLECREATE(CMyMath)
	
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYMATH_H__566A4393_FFEC_11D2_936E_000000000000__INCLUDED_)
