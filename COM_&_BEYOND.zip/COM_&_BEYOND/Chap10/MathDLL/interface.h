// file Interface.h
// This files contains interface related declarations.

#ifndef _MATHDLL_INTERFACE_H_
#define _MATHDLL_INTERFACE_H_

DECLARE_INTERFACE_(IMyMath, IUnknown)
{
    STDMETHOD_(LONG, MyAdd) (INT, INT) PURE;
    STDMETHOD_(LONG,MySubtract) (INT, INT) PURE;
};

// {E8ED5340-F35E-11d2-BDA8-00A0C970EFDB}
EXTERN_C const GUID IID_IMyMath = 
{0xe8ed5340, 0xf35e, 0x11d2, {0xbd, 0xa8, 0x0, 0xa0, 0xc9, 0x70, 0xef, 0xdb}};

#endif
