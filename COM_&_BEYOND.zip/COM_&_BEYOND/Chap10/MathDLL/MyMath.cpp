// MyMath.cpp : implementation file
//

#include "stdafx.h"
#include "MathDLL.h"
#include "MyMath.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyMath

IMPLEMENT_DYNCREATE(CMyMath, CCmdTarget)

// {EE6E8F60-FECC-11d2-A6E6-000000000000}
IMPLEMENT_OLECREATE(CMyMath, "MyMathDLL.MyMath", 
0xee6e8f60, 0xfecc, 0x11d2, 0xa6, 0xe6, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0);

BEGIN_INTERFACE_MAP(CMyMath, CCmdTarget)
   INTERFACE_PART(CMyMath, IID_IMyMath, MyMathObj)
END_INTERFACE_MAP()


CMyMath::CMyMath()
{
}

CMyMath::~CMyMath()
{
}


BEGIN_MESSAGE_MAP(CMyMath, CCmdTarget)
	//{{AFX_MSG_MAP(CMyMath)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyMath message handlers

// IMyMath functions
STDMETHODIMP_(LONG)
CMyMath :: XMyMathObj :: MyAdd ( INT x, INT y)
{
	return (x + y);
}

STDMETHODIMP_(LONG)
CMyMath :: XMyMathObj :: MySubtract( INT x, INT y)
{
	return(x-y);
}


//IUknown functions
STDMETHODIMP_(ULONG)
CMyMath :: XMyMathObj :: AddRef ( void )
{
	METHOD_PROLOGUE(CMyMath,MyMathObj)
	return pThis->ExternalAddRef();
}

STDMETHODIMP_(ULONG)
CMyMath :: XMyMathObj :: Release ( void)
{
	METHOD_PROLOGUE(CMyMath,MyMathObj)
	return pThis->ExternalRelease();
}

STDMETHODIMP 
CMyMath :: XMyMathObj :: QueryInterface ( REFIID riid, LPVOID FAR *ppv)
{
	METHOD_PROLOGUE(CMyMath,MyMathObj)
	return pThis->ExternalQueryInterface(&riid,ppv);
}