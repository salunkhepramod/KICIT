#include <stdio.h>
#include<objbase.h>
#include "interface.h"
static const CLSID MYMATH_CLSID = 
{0xee6e8f60, 0xfecc, 0x11d2,{0xa6, 0xe6, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0}};

int main(void)
{

	IClassFactory *pclsf;
	IUnknown *pUnk;
	IMyMath *pMath;
	int x,y;
	long result;

	//Initialize the OLE libraries
	CoInitialize(NULL);
	
	// get the IClassFactory interface pointer
	HRESULT hr = CoGetClassObject(
					MYMATH_CLSID,
					CLSCTX_INPROC,
					NULL,
					IID_IClassFactory,
					(void **)&pclsf);
	if ( !SUCCEEDED(hr) )
	{
		printf("CoGetClassObject failed with error %x\n",hr);
		return 1;
	}
		
	// use IClassFactory's createInstance to create the COM object
	// and get the IUnknown interface pointer.
	hr = pclsf->CreateInstance(
					NULL,
					IID_IUnknown,
					(void **)&pUnk);
	if ( !SUCCEEDED(hr) )
	{
		printf("Class Factory CreateInstance failed with error %x\n",hr);
		return 1;
	}
	
	// Query the IUnknown to get to IMyMath interface
	hr = pUnk->QueryInterface(
					IID_IMyMath,
					(void **)&pMath);
	if ( !SUCCEEDED(hr) )
	{
		printf("QueryInterface failed with error %x\n",hr);
		return 1;
	}
	
	// Use IMyMath interface for additions
	printf("Input two numbers you want to add\n");
	scanf("%d\n%d",&x,&y);
	result = pMath->MyAdd(x,y);
	printf("The two numbers %d and %d add to %d\n",x,y,result);

	// Release the interface pointers.
	pMath->Release();
	pclsf->Release();


	return 0;
}
