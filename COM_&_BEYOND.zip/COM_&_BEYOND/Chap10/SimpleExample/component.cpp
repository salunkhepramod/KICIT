// file component.cpp
// This contains implementation of member functions of the component.

#include "component.h"

ULONG STDMETHODCALLTYPE CMyMath :: AddRef()
{
	return ++m_RefCount;
}

ULONG STDMETHODCALLTYPE CMyMath :: Release()
{
	int count;
	count = --m_RefCount;
	if ( m_RefCount == 0)
		delete this;
	return count;
}

HRESULT STDMETHODCALLTYPE CMyMath :: QueryInterface( const IID &iid, void **ppv)
{
	if ( iid == IID_IUnknown )
	{		
		*ppv = (IUnknown *)this;
		AddRef();
	}
	else if ( iid == IID_IMyMath )
	{
		*ppv = ( IMyMath *) this;
		AddRef();
	}
	else
		return E_NOINTERFACE;

	return S_OK;
}

LONG STDMETHODCALLTYPE CMyMath :: MyAdd ( int x, int y )
{
	return x + y;
}

LONG STDMETHODCALLTYPE CMyMath :: MySubtract ( int x, int y )
{
	return x - y;
}