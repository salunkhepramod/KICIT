// file interface.h
// This file contains definition for IMyMath interface and its IID. 

#include <stdio.h>
#include <objbase.h>

// {41F40320-F36B-11d2-A6D7-000000000000}
static const IID IID_IMyMath=
{ 0x41f40320, 0xf36b, 0x11d2, { 0xa6, 0xd7, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0 } };

interface IMyMath : public IUnknown
{ 
	virtual LONG STDMETHODCALLTYPE MyAdd( int, int)= 0;
	virtual LONG STDMETHODCALLTYPE MySubtract( int, int)= 0;
};
