// file Component.h
// This file contains the the declaration for component class.

#include "interface.h"

class CMyMath : public IMyMath
{
protected:
	int m_RefCount;
public:
	CMyMath() { m_RefCount = 0;}   // constructor

	// IUnknown functions
	virtual HRESULT STDMETHODCALLTYPE QueryInterface( const IID & iid, void **ppv);
	virtual ULONG STDMETHODCALLTYPE AddRef();
	virtual ULONG STDMETHODCALLTYPE Release();
	
	// IMyMath functions
	virtual LONG STDMETHODCALLTYPE MyAdd (int x, int y);
	virtual LONG STDMETHODCALLTYPE MySubtract( int x , int y );
};
