// file main.cpp
// This contains the client code and one other helper function.

#include <stdio.h>
#include "component.h"


HRESULT COMCreateInstance (const IID &iid, void **ppv)
{
	CMyMath *mathobj = new CMyMath;
	if ( mathobj->QueryInterface( iid, ppv) == E_NOINTERFACE)
	{
		delete mathobj;
		return E_NOINTERFACE;
	}
	else
	{
		return S_OK;
	}
}
// client programming
int main()
{
	HRESULT result;
	IUnknown *unkPtr;
	IMyMath *mathPtr;

	// create the COM object and get interface pointer to IUnknown
	result  = COMCreateInstance ( IID_IUnknown, (void **)&unkPtr);
	if ( !SUCCEEDED(result) )
	{
		printf("Couldn't create the instance : error = %x\n",result);
		return 1;
	}

	// use IUnknown pointer to get to IMyMath interface.
	result = unkPtr->QueryInterface( IID_IMyMath, (void **)&mathPtr);
	if ( !SUCCEEDED(result) )
	{
		printf("Couldn't get IMyMath interface pointer : error = %x\n",result);
		return 1;
	}

	// now we have the IMyMath interface pointer, use it to do the work.
	int x = 1025;
	int y = 25;
	LONG sum = mathPtr->MyAdd(x,y);
	printf("IMyMath interface adds %d and %d to %d\n",x,y,sum);

	LONG difference = mathPtr->MySubtract(x, y);
	printf("IMyMath interface subtracts %d and %d to %d\n",x,y,difference);

	unkPtr->Release();
	mathPtr->Release();
	return 0;
}

