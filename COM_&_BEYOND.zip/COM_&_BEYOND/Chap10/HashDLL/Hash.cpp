// Hash.cpp : implementation file
//

#include "stdafx.h"
#include "HashDLL.h"
#include "Hash.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHash

IMPLEMENT_DYNCREATE(CHash, CCmdTarget)

// {A9A0CAC0-381A-11d3-8220-000000000000}
IMPLEMENT_OLECREATE(CHash, "HashDLL.CHash", 
0xa9a0cac0, 0x381a, 0x11d3, 0x82, 0x20, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0);

BEGIN_INTERFACE_MAP(CHash, CCmdTarget)
   INTERFACE_PART(CHash, IID_IHash, HashObj)
END_INTERFACE_MAP()

CHash::CHash()
{
}

CHash::~CHash()
{
}


BEGIN_MESSAGE_MAP(CHash, CCmdTarget)
	//{{AFX_MSG_MAP(CHash)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHash message handlers
// IHash functions


STDMETHODIMP_(VOID)
CHash :: XHashObj :: SetBucketSize ( UINT x)
{
	METHOD_PROLOGUE(CHash,HashObj);
	pThis->m_numBuckets = x;
	pThis->m_buckets = ( LinkElement *)malloc( x*sizeof(LinkElement));
	for ( unsigned int i= 0; i < x; i++)
	{
		pThis->m_buckets[i].flink = &pThis->m_buckets[i];
		pThis->m_buckets[i].blink = &pThis->m_buckets[i] ;
		pThis->m_buckets[i].value = 0;    // This will not be used.

	}
}


STDMETHODIMP_(LONG)
CHash :: XHashObj :: Add ( INT x)
{
	METHOD_PROLOGUE(CHash,HashObj);

	//Hash the number i.e. find the appropriate bucket.
	int i  = x % pThis->m_numBuckets;
	
	// Allocate a new LinkElement struct.
	LinkElement *newElement = ( LinkElement *)malloc( sizeof(LinkElement));

	// populate the element.
	newElement->value = x;
	
	// add the element to the doubly linked list of the bucket.
	newElement->flink = pThis->m_buckets[i].flink;
	newElement->blink = &pThis->m_buckets[i];
	pThis->m_buckets[i].flink->blink = newElement;
	pThis->m_buckets[i].flink = newElement;

	return (x);
}

STDMETHODIMP_(LONG)
CHash :: XHashObj :: Delete( INT x)
{
	METHOD_PROLOGUE(CHash,HashObj);
	int i = x % pThis->m_numBuckets;
	LinkElement *ptr = pThis->m_buckets[i].flink;
	while (ptr != &(pThis->m_buckets[i]))
	{
		if (ptr->value == x)
		{
			ptr->blink->flink = ptr->flink;
			ptr->flink->blink = ptr->blink;
			free(ptr);
			return 1;
		}
		ptr = ptr->flink;
	}

	return 0;	
}

STDMETHODIMP_(BOOL)
CHash :: XHashObj :: Check( INT x)
{

	METHOD_PROLOGUE(CHash,HashObj);
	int i = x % pThis->m_numBuckets;
	LinkElement *ptr = pThis->m_buckets[i].flink;
	while (ptr != &(pThis->m_buckets[i]))
	{
		if (ptr->value == x)
			return TRUE;
		ptr = ptr->flink;
	}

	return FALSE;
}


//IUknown functions
STDMETHODIMP_(ULONG)
CHash :: XHashObj :: AddRef ( void)
{
	METHOD_PROLOGUE(CHash,HashObj)
	return pThis->ExternalAddRef();
}

STDMETHODIMP_(ULONG)
CHash :: XHashObj :: Release ( void)
{
	METHOD_PROLOGUE(CHash,HashObj)
	return pThis->ExternalRelease();
}

STDMETHODIMP 
CHash :: XHashObj :: QueryInterface ( REFIID riid, LPVOID FAR *ppv)
{
	METHOD_PROLOGUE(CHash,HashObj)
	return pThis->ExternalQueryInterface(&riid,ppv);
}
