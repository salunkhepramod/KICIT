#if !defined(AFX_HASH_H__79270620_3818_11D3_8220_000000000000__INCLUDED_)
#define AFX_HASH_H__79270620_3818_11D3_8220_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// Hash.h : header file
//

#include "hashInterface.h"

struct tagLinkElement{
	int value;
	struct tagLinkElement *flink;
	struct tagLinkElement *blink;
};
typedef struct tagLinkElement LinkElement;

/////////////////////////////////////////////////////////////////////////////
// CHash command target

class CHash : public CCmdTarget
{
	DECLARE_DYNCREATE(CHash)

	CHash();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:
	UINT m_numBuckets;
	LinkElement *m_buckets;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHash)
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CHash();

	// Generated message map functions
	//{{AFX_MSG(CHash)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
	
	BEGIN_INTERFACE_PART(HashObj,IHash)
		STDMETHOD_(LONG, Add) (INT);
		STDMETHOD_(LONG,Delete) (INT);
		STDMETHOD_(BOOL,Check) (INT);
		STDMETHOD_(VOID, SetBucketSize) (UINT);
	END_INTERFACE_PART(HashObj)	
	
	DECLARE_INTERFACE_MAP()
	DECLARE_OLECREATE(CHash)
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HASH_H__79270620_3818_11D3_8220_000000000000__INCLUDED_)
