// file Interface.h
// This files contains interface related declarations.

#ifndef _HASHDLL_INTERFACE_H_
#define _HASHDLL_INTERFACE_H_

DECLARE_INTERFACE_(IHash, IUnknown)
{
    STDMETHOD_(LONG, Add) (INT) PURE;
    STDMETHOD_(LONG,Delete) (INT) PURE;
    STDMETHOD_(BOOL,Check) (INT) PURE;
    STDMETHOD_(VOID,SetBucketSize) (UINT) PURE;

};

// {E8ED5340-F35E-11d2-BDA8-00A0C970EFDB}
EXTERN_C const GUID IID_IHash = 
{ 0x6ba39710, 0x3819, 0x11d3, { 0x82, 0x20, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0 } };

#endif