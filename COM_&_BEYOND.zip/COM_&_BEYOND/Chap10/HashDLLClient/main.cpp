#include <stdio.h>
#include<objbase.h>
#include "HashInterface.h"
static const CLSID HASH_CLSID = 
{0xa9a0cac0, 0x381a, 0x11d3,{0x82, 0x20, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0}};

int main(void)
{

	IClassFactory *pclsf;
	IUnknown *pUnk;
	IHash *pHash;
	int tmpRand;

	//Initialize the OLE libraries
	CoInitialize(NULL);
		
	// get the IClassFactory interface pointer
	HRESULT hr = CoGetClassObject(
					HASH_CLSID,
					CLSCTX_INPROC,
					NULL,
					IID_IClassFactory,
					(void **)&pclsf);
	if ( !SUCCEEDED(hr) )
	{
		printf("CoGetClassObject failed with error %x\n",hr);
		return 1;
	}
		
	// use IClassFactory's createInstance to create the COM object
	// and get the IUnknown interface pointer.
	hr = pclsf->CreateInstance(
					NULL,
					IID_IUnknown,
					(void **)&pUnk);
	if ( !SUCCEEDED(hr) )
	{
		printf("Class Factory CreateInstance failed with error %x\n",hr);
		return 1;
	}
	
	// Query the IUnknown to get to IMyMath interface
	hr = pUnk->QueryInterface(
					IID_IHash,
					(void **)&pHash);
	if ( !SUCCEEDED(hr) )
	{
		printf("QueryInterface failed with error %x\n",hr);
		return 1;
	}
	
	// Use IMyMath interface for additions
	pHash->SetBucketSize(100);

	for (int i=0; i < 1000; i ++)
	{

		tmpRand = rand() % 32000;
		
		// Generate a random number that is not in the hash table.
		while (pHash->Check(tmpRand) == TRUE )
			tmpRand = rand() % 32000;
		
		// remember the number that we generated in the ith iteration.
		pHash->Add(tmpRand);
		printf("%dth random number is %d\n",i,tmpRand);
	
	}
	

	// Release the interface pointers.
	pHash->Release();
	pclsf->Release();


	return 0;
}
