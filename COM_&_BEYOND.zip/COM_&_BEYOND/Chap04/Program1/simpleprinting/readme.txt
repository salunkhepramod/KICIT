Informs the device driver that a new print job is 
starting and that all subsequent StartPage and 
EndPage calls should be spooled under the same job 
until an EndDoc call occurs. This ensures that 
documents longer than one page will not be 
interspersed with other jobs.