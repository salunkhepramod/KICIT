class myview : public CScrollView
{
	DECLARE_DYNCREATE ( myview )

	public :

		virtual void OnInitialUpdate( ) ;
		void OnDraw ( CDC *p ) ;
		virtual BOOL OnPreparePrinting ( CPrintInfo *p ) ;
		void OnPrepareDC ( CDC *p, CPrintInfo *info ) ;

	DECLARE_MESSAGE_MAP( )
} ;
