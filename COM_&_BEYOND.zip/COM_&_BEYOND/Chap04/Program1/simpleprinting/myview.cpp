#include <afxwin.h>
#include <afxext.h>
#include "mydoc.h"
#include "myview.h"

IMPLEMENT_DYNCREATE ( myview, CScrollView ) 

BEGIN_MESSAGE_MAP ( myview, CScrollView )

	ON_COMMAND ( ID_FILE_PRINT, CScrollView::OnFilePrint ) 
	ON_COMMAND ( ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview ) 

END_MESSAGE_MAP( )

void myview::OnInitialUpdate( ) 
{
	CScrollView::OnInitialUpdate( ) ;
	SetScrollSizes ( MM_LOENGLISH, CSize ( 827, 1169 ) ) ;
}

void myview::OnDraw ( CDC *p ) 
{ 
	CPen mypen ;
	CBrush mybrush ;
	CFont myfont ;

	mypen.CreatePen ( PS_SOLID, 3, RGB ( 0, 0, 255 ) ) ;
	mybrush.CreateSolidBrush ( RGB ( 255, 0, 0 ) ) ;
	myfont.CreatePointFont ( 300, "Arial", p ) ;

	CPen* prevpen = p -> SelectObject ( &mypen ) ;
	CBrush* prevbrush = p -> SelectObject ( &mybrush ) ;
	CFont* prevfont = p -> SelectObject ( &myfont ) ;

	p -> Ellipse ( 100, -10, 300, -200 ) ;
	p -> Rectangle ( 300, -300, 500, -500 ) ;
	p -> TextOut ( 100, -600, "Hello", 5 ) ;

	p -> SelectObject ( prevpen ) ;
	p -> SelectObject ( prevbrush ) ;
	p -> SelectObject ( prevfont ) ;
}

BOOL myview::OnPreparePrinting ( CPrintInfo *info )
{
	info -> SetMaxPage ( 1 ) ;
	return DoPreparePrinting ( info ) ;
}

void myview::OnPrepareDC ( CDC *p, CPrintInfo *info )
{
	CScrollView::OnPrepareDC ( p, info ) ;
	if ( p -> IsPrinting( ) )
	{
		int n = info -> m_nCurPage ;
	}
}
