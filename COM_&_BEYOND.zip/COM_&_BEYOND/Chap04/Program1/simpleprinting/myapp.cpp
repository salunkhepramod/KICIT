#include <afxwin.h>
#include <afxext.h>
#include "mydoc.h"
#include "myview.h"
#include "myframe.h"
#include "myapp.h"

#include "resource.h"

myapp a ;

BEGIN_MESSAGE_MAP ( myapp, CWinApp )
	ON_COMMAND ( ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup ) 
END_MESSAGE_MAP( )

BOOL myapp::InitInstance( )
{
	d = RUNTIME_CLASS ( mydoc ) ;
	f = RUNTIME_CLASS ( myframe ) ;
	v = RUNTIME_CLASS ( myview ) ;

	CSingleDocTemplate *t ;
	t = new CSingleDocTemplate ( IDR_MAINFRAME, d, f, v ) ;

	AddDocTemplate ( t ) ;

	CCommandLineInfo str ;
	ParseCommandLine ( str ) ;

	if ( !ProcessShellCommand ( str ) )
		return FALSE ;

	return TRUE ;
} 
