#include <afxwin.h>
#include "mydialog.h"
#include "mydoc.h"
#include "myview.h"

#include "resource.h"

IMPLEMENT_DYNCREATE ( mydoc, CDocument ) 

BEGIN_MESSAGE_MAP ( mydoc, CDocument ) 
	ON_COMMAND ( ID_OPEN, openfile )
END_MESSAGE_MAP( )

void mydoc::openfile( )
{
	mydialog d ( IDD_DIALOG1 ) ;

	if ( d.DoModal( ) == IDOK )
	{
		CStdioFile fr ( d.filepath_str, CFile::modeRead  ) ;//| CFile::typeText ) ;

		filelines_str.RemoveAll( ) ;
		CString str ;
		while ( fr.ReadString ( str ) ) 
		{
			filelines_str.AddTail ( str ) ;
		}

		SetTitle ( d.filename_str ) ;

		UpdateAllViews ( NULL ) ;
	}

	POSITION pos = GetFirstViewPosition( ) ;
	myview *p = ( myview * ) GetNextView ( pos ) ;
	p -> setview( ) ;
}
