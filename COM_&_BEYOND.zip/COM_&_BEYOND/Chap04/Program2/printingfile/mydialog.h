class mydialog : public CDialog 
{
	public :	

		CString filepath_str ;
		CString filename_str ;

		mydialog ( int n ) ;
		virtual BOOL OnInitDialog( ) ;
		virtual void DoDataExchange ( CDataExchange *pdx ) ;
		void browse( ) ;

	DECLARE_MESSAGE_MAP( )
} ;