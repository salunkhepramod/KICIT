class mydoc : public CDocument
{
	DECLARE_DYNCREATE ( mydoc )

	public :

		CStringList filelines_str ;
		void openfile( ) ;

	DECLARE_MESSAGE_MAP( )
} ;
