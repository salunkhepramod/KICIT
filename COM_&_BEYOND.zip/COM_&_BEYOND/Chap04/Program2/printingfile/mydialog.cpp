#include <afxwin.h>
#include <afxdlgs.h>
#include "mydialog.h"

#include "resource.h"

BEGIN_MESSAGE_MAP ( mydialog, CDialog )
	ON_COMMAND ( IDC_BROWSE, browse ) 
END_MESSAGE_MAP( )

mydialog::mydialog ( int n ) : CDialog ( n )
{
}

BOOL mydialog::OnInitDialog( )
{
	filepath_str = "Enter filename here or browse" ;
	return CDialog::OnInitDialog( ) ;
}

void mydialog::DoDataExchange ( CDataExchange *pdx )
{
	DDX_Text ( pdx, IDC_EDIT1, filepath_str ) ;
}

void mydialog::browse( )
{
	CFileDialog f ( TRUE, NULL, NULL, NULL, "Text Files(*.txt)|*.txt|CPP Files(*.cpp,*.h)|*.cpp;*.h||" )  ;

	if ( f.DoModal( ) == IDOK )
	{
		CString s = f.GetPathName( ) ;
		filename_str = f.GetFileName( ) ;
		SetDlgItemText ( IDC_EDIT1, s ) ;
	}
}