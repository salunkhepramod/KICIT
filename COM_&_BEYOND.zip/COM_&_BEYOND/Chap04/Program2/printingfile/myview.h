class myview : public CScrollView
{
	DECLARE_DYNCREATE ( myview )

	private :

		mydoc *doc ;
		CFont scr_font, prn_font ;
		int scr_ht, scr_wd, prn_ht, prn_wd, linesperpage, charsperline, max_page ;
		CStringList prn_str ;

	public :

		virtual void OnInitialUpdate( ) ;
		void setview( ) ;
		void OnDraw ( CDC *p ) ;
		virtual BOOL OnPreparePrinting ( CPrintInfo *p ) ;
		void OnBeginPrinting ( CDC *p, CPrintInfo *info ) ;
		void OnPrint ( CDC *p, CPrintInfo *info ) ;
		void OnEndPrinting ( CDC *p, CPrintInfo *info ) ;

	DECLARE_MESSAGE_MAP( )
} ;
