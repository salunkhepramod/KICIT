#include <afxwin.h>
#include <afxext.h>
#include "mydoc.h"
#include "myview.h"

IMPLEMENT_DYNCREATE ( myview, CScrollView ) 

BEGIN_MESSAGE_MAP ( myview, CScrollView )

	ON_COMMAND ( ID_FILE_PRINT, CScrollView::OnFilePrint ) 
	ON_COMMAND ( ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview ) 

END_MESSAGE_MAP( )

void myview::OnInitialUpdate( ) 
{
	CScrollView::OnInitialUpdate( ) ;

	doc = ( mydoc * ) GetDocument( ) ;

	CClientDC d ( this ) ;
	d.SetMapMode ( MM_LOENGLISH ) ;
	scr_font.CreatePointFont ( 100, "Arial", &d ) ;

	CFont *prevfont = d.SelectObject ( &scr_font ) ;

	TEXTMETRIC tm ;
	d.GetTextMetrics ( &tm) ;
	scr_ht = tm.tmHeight + tm.tmExternalLeading ;
	scr_wd = tm.tmMaxCharWidth ;

	d.SelectObject ( prevfont ) ;

	setview( ) ;
} 

void myview::setview( )
{
	int maxlinelen = 0 ;
	CString str ;

	POSITION pos = doc -> filelines_str.GetHeadPosition( ) ;
	int count = doc -> filelines_str.GetCount( ) ;
	
	for ( int i = 0 ; i < count ; i++ )
	{
		str = doc -> filelines_str.GetNext ( pos ) ;
		if ( str.GetLength( ) > maxlinelen )
			maxlinelen = str.GetLength( ) ;
	}
	
	SetScrollSizes ( MM_LOENGLISH, CSize ( maxlinelen * scr_wd + 5 * scr_wd, doc -> filelines_str.GetCount( ) * scr_ht + 5 * scr_ht ) ) ;
}

void myview::OnDraw ( CDC *p ) 
{ 
	CFont* prevfont = p -> SelectObject ( &scr_font ) ;

	int count = doc -> filelines_str.GetCount( ) ;

	POSITION pos_screen = doc -> filelines_str.GetHeadPosition( ) ;
	for ( int i = 0, y = -10 ; i < count ; i++ )
	{
		p -> TabbedTextOut ( 10, y, ( CString ) doc -> filelines_str.GetNext ( pos_screen ) , 0, NULL, 10 ) ;
		y -= scr_ht ;
	}

	p -> SelectObject ( prevfont ) ;
}

BOOL myview::OnPreparePrinting ( CPrintInfo *p )
{
	return DoPreparePrinting ( p ) ;
}

void myview::OnBeginPrinting ( CDC *p, CPrintInfo *info )
{
	p -> SetMapMode ( MM_LOENGLISH ) ;
	prn_font.CreatePointFont ( 100, "Arial", p ) ;
	CFont *prevfont = p -> SelectObject ( &prn_font ) ;

	TEXTMETRIC tm ;
	p -> GetTextMetrics ( &tm) ;
	prn_ht = tm.tmHeight + tm.tmExternalLeading ;
	prn_wd = tm.tmAveCharWidth + 1 ;

	// total number of pixels per page in device coordinates
	int vertpixels = p -> GetDeviceCaps ( VERTRES ) ;
	int horzpixels = p -> GetDeviceCaps ( HORZRES ) ;

	// convert into logical coordinates
	CSize sz ( horzpixels, vertpixels ) ;
	p -> DPtoLP ( &sz ) ;

	linesperpage = sz.cy / prn_ht ;
	charsperline = sz.cx / prn_wd ;
	
	// make space for header and footer
	linesperpage = linesperpage - 10 ;

	CString tempstr ;
	POSITION temppos = doc -> filelines_str.GetHeadPosition( ) ;
	int tempcount = doc -> filelines_str.GetCount( ) ;
	for ( int i = 0 ; i < tempcount ; i++ )
	{
		tempstr = doc -> filelines_str.GetNext ( temppos ) ;
		prn_str.AddTail ( tempstr ) ;
	}

	POSITION pos = prn_str.GetHeadPosition( ) ;
	POSITION pos_prev1, pos_prev2 ;
	
	int count = prn_str.GetCount( ) ;

	CString str, pa ;
	for ( i = 0 ; i < count ; i++ )
	{
		if ( pos == NULL ) 
			break ;

		pos_prev1 = pos_prev2 = pos ;
		str = prn_str.GetNext ( pos ) ;

		str.Replace ( "\t", "    " ) ;

		int len = str.GetLength( ) ;
		if ( len > charsperline ) 
		{
			int linecount = max ( 1, ( len + ( charsperline - 1 ) ) / charsperline ) ;
	
			CString left_str ;
			int remain_len, left_len = 0 ;
			for ( int j = 0 ; j < linecount ; j++ )
			{
				left_str = str.Left ( charsperline ) ;
				prn_str.InsertAfter ( pos_prev2, left_str ) ;
				
				left_len += left_str.GetLength( ) ;
				remain_len = len - left_len ;
				
				prn_str.GetNext ( pos_prev2 ) ;
				str = str.Right ( remain_len ) ;
			}
			str = "" ;

			pa = prn_str.GetAt ( pos_prev1 ) ;
			prn_str.RemoveAt ( pos_prev1 ) ;
			pa.FreeExtra( ) ;
		}
		else
		{
			prn_str.InsertAfter ( pos_prev1, str ) ;
			pa = prn_str.GetAt ( pos_prev1 ) ;
			prn_str.RemoveAt ( pos_prev1 ) ;
			pa.FreeExtra( ) ;
		}
	}

	count = prn_str.GetCount( ) ;
	max_page = max ( 1, ( count + ( linesperpage - 1 ) ) / linesperpage ) ;
	p -> SelectObject ( prevfont ) ;
	info -> SetMaxPage ( max_page ) ;
}

void myview::OnPrint ( CDC *p, CPrintInfo *info )
{
	CFont* prevfont = p -> SelectObject ( &prn_font ) ;

	TEXTMETRIC tm ;
	p -> GetTextMetrics ( &tm ) ;

	// center coordinate
	int horzpixels = p -> GetDeviceCaps ( HORZRES ) ;
	CSize sz ( horzpixels, 0 ) ; p -> DPtoLP ( &sz ) ;
	int center = sz.cx / 2 ;

	// printheader
	CString title = doc -> GetTitle( ) ;
	UINT l = center - ( ( title.GetLength( ) / 2 )  * tm.tmAveCharWidth ) ;
	p -> TextOut ( l, 0, title ) ;

	// printpage
	int count = prn_str.GetCount( ) ;

	int start = ( ( info -> m_nCurPage ) - 1 ) * linesperpage ;
	int end = start + linesperpage ;
	
	POSITION pos = prn_str.FindIndex ( linesperpage * ( ( info -> m_nCurPage ) - 1 ) ) ;
	for ( int i = start, y = - ( prn_ht * 5 ) ; i < end && i < count ; i++ )
	{
		p -> TextOut ( 10, y, ( CString ) prn_str.GetNext ( pos ) ) ;
		y -= prn_ht ;
	}

	// printfooter
	CString pagenumber ;
	pagenumber.Format ( "%2d / %2d", info -> m_nCurPage, max_page ) ;
	l = center - ( ( pagenumber.GetLength( ) / 2 )  * tm.tmAveCharWidth ) ;
	p -> TextOut ( l, - ( linesperpage + 5 + 3 ) * prn_ht, pagenumber ) ;

	p -> SelectObject ( prevfont ) ;
}

void myview::OnEndPrinting ( CDC *p, CPrintInfo *info )
{
	prn_str.RemoveAll( ) ;
	prn_font.DeleteObject( ) ;
}
