// MyGameDlg.h : header file
//
//{{AFX_INCLUDES()
#include "tictactoe.h"
//}}AFX_INCLUDES

#if !defined(AFX_MYGAMEDLG_H__0636DF66_9EA5_11D3_BDCF_00A0C970EFDB__INCLUDED_)
#define AFX_MYGAMEDLG_H__0636DF66_9EA5_11D3_BDCF_00A0C970EFDB__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define INVALID -1
#define ME 0
#define OPPONENT 1

#define CROSS 0
#define CIRCLE 1
/////////////////////////////////////////////////////////////////////////////
// CMyGameDlg dialog

class CMyGameDlg : public CDialog
{
// Construction
public:
	CMyGameDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMyGameDlg)
	enum { IDD = IDD_MYGAME_DIALOG };
	CTicTacToe	m_TicTacToe;
	CString	m_Result;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyGameDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMyGameDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonRestart();
	afx_msg void OnGameWon(short who);
	afx_msg void OnRadioCircle();
	afx_msg void OnRadioCross();
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYGAMEDLG_H__0636DF66_9EA5_11D3_BDCF_00A0C970EFDB__INCLUDED_)
