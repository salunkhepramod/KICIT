// MyTimerCtl.cpp : Implementation of the CMyTimerCtrl ActiveX Control class.

#include "stdafx.h"
#include "MyTimer.h"
#include "MyTimerCtl.h"
#include "MyTimerPpg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CMyTimerCtrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CMyTimerCtrl, COleControl)
	//{{AFX_MSG_MAP(CMyTimerCtrl)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CMyTimerCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CMyTimerCtrl)
	DISP_PROPERTY(CMyTimerCtrl, "beep", m_beep, VT_BOOL)
	DISP_FUNCTION(CMyTimerCtrl, "StartTimer", StartTimer, VT_EMPTY, VTS_I4)
	DISP_STOCKPROP_CAPTION()
	DISP_STOCKPROP_BACKCOLOR()
	DISP_STOCKPROP_FORECOLOR()
	//}}AFX_DISPATCH_MAP
	DISP_FUNCTION_ID(CMyTimerCtrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CMyTimerCtrl, COleControl)
	//{{AFX_EVENT_MAP(CMyTimerCtrl)
	EVENT_CUSTOM("TimerExpired", FireTimerExpired, VTS_NONE)
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CMyTimerCtrl, 2)
	PROPPAGEID(CMyTimerPropPage::guid)
	PROPPAGEID(CLSID_CColorPropPage)
END_PROPPAGEIDS(CMyTimerCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CMyTimerCtrl, "MYTIMER.MyTimerCtrl.1",
	0x6d2d5845, 0x266c, 0x11d3, 0x90, 0x21, 0, 0, 0, 0, 0, 0)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CMyTimerCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DMyTimer =
		{ 0x6d2d5843, 0x266c, 0x11d3, { 0x90, 0x21, 0, 0, 0, 0, 0, 0 } };
const IID BASED_CODE IID_DMyTimerEvents =
		{ 0x6d2d5844, 0x266c, 0x11d3, { 0x90, 0x21, 0, 0, 0, 0, 0, 0 } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwMyTimerOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CMyTimerCtrl, IDS_MYTIMER, _dwMyTimerOleMisc)


/////////////////////////////////////////////////////////////////////////////
// CMyTimerCtrl::CMyTimerCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CMyTimerCtrl

BOOL CMyTimerCtrl::CMyTimerCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_MYTIMER,
			IDB_MYTIMER,
			afxRegApartmentThreading,
			_dwMyTimerOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// CMyTimerCtrl::CMyTimerCtrl - Constructor

CMyTimerCtrl::CMyTimerCtrl()
{
	InitializeIIDs(&IID_DMyTimer, &IID_DMyTimerEvents);

	// TODO: Initialize your control's instance data here.
	m_remainingTime = 0;
	m_beep = FALSE;
}


/////////////////////////////////////////////////////////////////////////////
// CMyTimerCtrl::~CMyTimerCtrl - Destructor

CMyTimerCtrl::~CMyTimerCtrl()
{
	// TODO: Cleanup your control's instance data here.
}


/////////////////////////////////////////////////////////////////////////////
// CMyTimerCtrl::OnDraw - Drawing function

void CMyTimerCtrl::OnDraw(
			CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
	// TODO: Replace the following code with your own drawing code.

	// Set the background color and draw the rectangle.
	CBrush backBrush(TranslateColor(GetBackColor() ));
	pdc->FillRect(rcBounds,&backBrush );
	
	// draw the caption with foreground color.
	char str[1000];
	strcpy(str,InternalGetText());
	pdc->SetTextColor(TranslateColor(GetForeColor()));
	pdc->TextOut(10,0,str);

	// Display the current time with foreground color.
	sprintf(str,"%d",m_remainingTime);
	pdc->TextOut(10,15,str,strlen(str));
	if ( m_beep )
		pdc->TextOut(10,30,"beep",4);
}


/////////////////////////////////////////////////////////////////////////////
// CMyTimerCtrl::DoPropExchange - Persistence support

void CMyTimerCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	// TODO: Call PX_ functions for each persistent custom property.

}


/////////////////////////////////////////////////////////////////////////////
// CMyTimerCtrl::OnResetState - Reset control to default state

void CMyTimerCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	// TODO: Reset any other control state here.
}


/////////////////////////////////////////////////////////////////////////////
// CMyTimerCtrl::AboutBox - Display an "About" box to the user

void CMyTimerCtrl::AboutBox()
{
	CDialog dlgAbout(IDD_ABOUTBOX_MYTIMER);
	dlgAbout.DoModal();
}


/////////////////////////////////////////////////////////////////////////////
// CMyTimerCtrl message handlers

void CMyTimerCtrl::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	m_remainingTime--;

	// check if the timer has expired.
	if ( m_remainingTime == 0){
		KillTimer(m_timerIdentifier);
		if ( m_beep );
			// sound a beep******

		// Fire the timer expiration event.
		FireTimerExpired();

	}

	//repaint the control
	InvalidateControl();
	COleControl::OnTimer(nIDEvent);
}

void CMyTimerCtrl::StartTimer(long time) 
{
	// TODO: Add your dispatch handler code here
	// see if the timer is already running.
	if ( time < 0)
		return;
	if ( m_remainingTime > 0)
	{
		KillTimer(m_timerIdentifier);
		m_remainingTime = time;
		InvalidateControl();
	}
	m_remainingTime = time;
	m_timerIdentifier = SetTimer(555,1000,NULL);

}
