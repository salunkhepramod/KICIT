#if !defined(AFX_MYTIMERPPG_H__6D2D5855_266C_11D3_9021_000000000000__INCLUDED_)
#define AFX_MYTIMERPPG_H__6D2D5855_266C_11D3_9021_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// MyTimerPpg.h : Declaration of the CMyTimerPropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CMyTimerPropPage : See MyTimerPpg.cpp.cpp for implementation.

class CMyTimerPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CMyTimerPropPage)
	DECLARE_OLECREATE_EX(CMyTimerPropPage)

// Constructor
public:
	CMyTimerPropPage();

// Dialog Data
	//{{AFX_DATA(CMyTimerPropPage)
	enum { IDD = IDD_PROPPAGE_MYTIMER };
	CString	m_Caption;
	BOOL	m_beep;
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CMyTimerPropPage)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYTIMERPPG_H__6D2D5855_266C_11D3_9021_000000000000__INCLUDED)
