// MyTimerPpg.cpp : Implementation of the CMyTimerPropPage property page class.

#include "stdafx.h"
#include "MyTimer.h"
#include "MyTimerPpg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CMyTimerPropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CMyTimerPropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CMyTimerPropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CMyTimerPropPage, "MYTIMER.MyTimerPropPage.1",
	0x6d2d5846, 0x266c, 0x11d3, 0x90, 0x21, 0, 0, 0, 0, 0, 0)


/////////////////////////////////////////////////////////////////////////////
// CMyTimerPropPage::CMyTimerPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CMyTimerPropPage

BOOL CMyTimerPropPage::CMyTimerPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_MYTIMER_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CMyTimerPropPage::CMyTimerPropPage - Constructor

CMyTimerPropPage::CMyTimerPropPage() :
	COlePropertyPage(IDD, IDS_MYTIMER_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CMyTimerPropPage)
	m_Caption = _T("");
	m_beep = FALSE;
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// CMyTimerPropPage::DoDataExchange - Moves data between page and properties

void CMyTimerPropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CMyTimerPropPage)
	DDP_Text(pDX, IDC_EDIT_CAPTION, m_Caption, _T("Caption") );
	DDX_Text(pDX, IDC_EDIT_CAPTION, m_Caption);
	DDP_Check(pDX, IDC_CHECK_BEEP, m_beep, _T("beep") );
	DDX_Check(pDX, IDC_CHECK_BEEP, m_beep);
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CMyTimerPropPage message handlers
