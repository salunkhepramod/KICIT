//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MyTimer.rc
//
#define IDS_MYTIMER                     1
#define IDD_ABOUTBOX_MYTIMER            1
#define IDB_MYTIMER                     1
#define IDI_ABOUTDLL                    1
#define IDS_MYTIMER_PPG                 2
#define IDS_MYTIMER_PPG_CAPTION         200
#define IDD_PROPPAGE_MYTIMER            200
#define IDC_EDIT_CAPTION                201
#define IDC_CHECK_BEEP                  202

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         203
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
