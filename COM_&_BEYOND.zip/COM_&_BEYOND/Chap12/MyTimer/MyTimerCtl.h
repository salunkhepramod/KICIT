#if !defined(AFX_MYTIMERCTL_H__6D2D5853_266C_11D3_9021_000000000000__INCLUDED_)
#define AFX_MYTIMERCTL_H__6D2D5853_266C_11D3_9021_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// MyTimerCtl.h : Declaration of the CMyTimerCtrl ActiveX Control class.

/////////////////////////////////////////////////////////////////////////////
// CMyTimerCtrl : See MyTimerCtl.cpp for implementation.

class CMyTimerCtrl : public COleControl
{
	DECLARE_DYNCREATE(CMyTimerCtrl)

// Constructor
public:
	CMyTimerCtrl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyTimerCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	//}}AFX_VIRTUAL

// Implementation
protected:
	~CMyTimerCtrl();

	DECLARE_OLECREATE_EX(CMyTimerCtrl)    // Class factory and guid
	DECLARE_OLETYPELIB(CMyTimerCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CMyTimerCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CMyTimerCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CMyTimerCtrl)
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CMyTimerCtrl)
	BOOL m_beep;
	afx_msg void StartTimer(long time);
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

	afx_msg void AboutBox();

// Event maps
	//{{AFX_EVENT(CMyTimerCtrl)
	void FireTimerExpired()
		{FireEvent(eventidTimerExpired,EVENT_PARAM(VTS_NONE));}
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	UINT m_timerIdentifier;
	unsigned long m_remainingTime;
	enum {
	//{{AFX_DISP_ID(CMyTimerCtrl)
	dispidBeep = 1L,
	dispidStartTimer = 2L,
	eventidTimerExpired = 1L,
	//}}AFX_DISP_ID
	};
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYTIMERCTL_H__6D2D5853_266C_11D3_9021_000000000000__INCLUDED)
