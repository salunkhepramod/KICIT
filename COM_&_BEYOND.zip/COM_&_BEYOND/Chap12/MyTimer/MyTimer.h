#if !defined(AFX_MYTIMER_H__6D2D584B_266C_11D3_9021_000000000000__INCLUDED_)
#define AFX_MYTIMER_H__6D2D584B_266C_11D3_9021_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// MyTimer.h : main header file for MYTIMER.DLL

#if !defined( __AFXCTL_H__ )
	#error include 'afxctl.h' before including this file
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CMyTimerApp : See MyTimer.cpp for implementation.

class CMyTimerApp : public COleControlModule
{
public:
	BOOL InitInstance();
	int ExitInstance();
};

extern const GUID CDECL _tlid;
extern const WORD _wVerMajor;
extern const WORD _wVerMinor;

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYTIMER_H__6D2D584B_266C_11D3_9021_000000000000__INCLUDED)
