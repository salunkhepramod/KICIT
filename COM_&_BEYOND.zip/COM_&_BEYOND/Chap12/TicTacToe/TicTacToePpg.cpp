// TicTacToePpg.cpp : Implementation of the CTicTacToePropPage property page class.

#include "stdafx.h"
#include "TicTacToe.h"
#include "TicTacToePpg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CTicTacToePropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CTicTacToePropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CTicTacToePropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CTicTacToePropPage, "TICTACTOE.TicTacToePropPage.1",
	0xc784f716, 0x9ea0, 0x11d3, 0xbd, 0xcf, 0, 0xa0, 0xc9, 0x70, 0xef, 0xdb)


/////////////////////////////////////////////////////////////////////////////
// CTicTacToePropPage::CTicTacToePropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CTicTacToePropPage

BOOL CTicTacToePropPage::CTicTacToePropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_TICTACTOE_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CTicTacToePropPage::CTicTacToePropPage - Constructor

CTicTacToePropPage::CTicTacToePropPage() :
	COlePropertyPage(IDD, IDS_TICTACTOE_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CTicTacToePropPage)
	// NOTE: ClassWizard will add member initialization here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// CTicTacToePropPage::DoDataExchange - Moves data between page and properties

void CTicTacToePropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CTicTacToePropPage)
	// NOTE: ClassWizard will add DDP, DDX, and DDV calls here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CTicTacToePropPage message handlers
