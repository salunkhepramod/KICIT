#if !defined(AFX_TICTACTOE_H__C784F71B_9EA0_11D3_BDCF_00A0C970EFDB__INCLUDED_)
#define AFX_TICTACTOE_H__C784F71B_9EA0_11D3_BDCF_00A0C970EFDB__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// TicTacToe.h : main header file for TICTACTOE.DLL

#if !defined( __AFXCTL_H__ )
	#error include 'afxctl.h' before including this file
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CTicTacToeApp : See TicTacToe.cpp for implementation.

class CTicTacToeApp : public COleControlModule
{
public:
	BOOL InitInstance();
	int ExitInstance();
};

extern const GUID CDECL _tlid;
extern const WORD _wVerMajor;
extern const WORD _wVerMinor;

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TICTACTOE_H__C784F71B_9EA0_11D3_BDCF_00A0C970EFDB__INCLUDED)
