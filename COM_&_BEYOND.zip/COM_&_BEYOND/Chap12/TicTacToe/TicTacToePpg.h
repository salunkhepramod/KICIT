#if !defined(AFX_TICTACTOEPPG_H__C784F725_9EA0_11D3_BDCF_00A0C970EFDB__INCLUDED_)
#define AFX_TICTACTOEPPG_H__C784F725_9EA0_11D3_BDCF_00A0C970EFDB__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// TicTacToePpg.h : Declaration of the CTicTacToePropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CTicTacToePropPage : See TicTacToePpg.cpp.cpp for implementation.

class CTicTacToePropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CTicTacToePropPage)
	DECLARE_OLECREATE_EX(CTicTacToePropPage)

// Constructor
public:
	CTicTacToePropPage();

// Dialog Data
	//{{AFX_DATA(CTicTacToePropPage)
	enum { IDD = IDD_PROPPAGE_TICTACTOE };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CTicTacToePropPage)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TICTACTOEPPG_H__C784F725_9EA0_11D3_BDCF_00A0C970EFDB__INCLUDED)
