#if !defined(AFX_TICTACTOECTL_H__C784F723_9EA0_11D3_BDCF_00A0C970EFDB__INCLUDED_)
#define AFX_TICTACTOECTL_H__C784F723_9EA0_11D3_BDCF_00A0C970EFDB__INCLUDED_
#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define INVALID -1
#define ME 0
#define OPPONENT 1

// Game state
#define NOT_STARTED -1
#define STARTED      0
#define FINISHED     1

#define CROSS 0
#define CIRCLE 1
// TicTacToeCtl.h : Declaration of the CTicTacToeCtrl ActiveX Control class.

/////////////////////////////////////////////////////////////////////////////
// CTicTacToeCtrl : See TicTacToeCtl.cpp for implementation.

class CTicTacToeCtrl : public COleControl
{
	DECLARE_DYNCREATE(CTicTacToeCtrl)

// Constructor
public:
	CTicTacToeCtrl();


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTicTacToeCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	//}}AFX_VIRTUAL

// Implementation
protected:
	~CTicTacToeCtrl();

	DECLARE_OLECREATE_EX(CTicTacToeCtrl)    // Class factory and guid
	DECLARE_OLETYPELIB(CTicTacToeCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CTicTacToeCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CTicTacToeCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CTicTacToeCtrl)
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CTicTacToeCtrl)
	afx_msg void SetMyIcon(short iconType);
	afx_msg void Restart();
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

	afx_msg void AboutBox();

// Event maps
	//{{AFX_EVENT(CTicTacToeCtrl)
	void FireGameWon(short who)
		{FireEvent(eventidGameWon,EVENT_PARAM(VTS_I2), who);}
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	short m_Cell[3][3];
	CPoint m_Coordinates[4][4];
	BOOL opponentMoveDue;
	BOOL m_State;	
	short m_MyIcon;

	BOOL selectionCell( CPoint input, short *x, short *y);
	BOOL isWinner(short who);
	void addCross( CRect rect, CDC *pdc);
	void addCircle(CRect rect, CDC *pdc);
	void playOpponent(int *a, int *b);	
	
	enum {
	//{{AFX_DISP_ID(CTicTacToeCtrl)
	dispidSetMyIcon = 1L,
	dispidRestart = 2L,
	eventidGameWon = 1L,
	//}}AFX_DISP_ID
	};
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TICTACTOECTL_H__C784F723_9EA0_11D3_BDCF_00A0C970EFDB__INCLUDED)
