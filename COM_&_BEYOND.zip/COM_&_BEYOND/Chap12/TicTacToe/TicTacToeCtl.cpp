// TicTacToeCtl.cpp : Implementation of the CTicTacToeCtrl ActiveX Control class.

#include "stdafx.h"
#include "TicTacToe.h"
#include "TicTacToeCtl.h"
#include "TicTacToePpg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CTicTacToeCtrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CTicTacToeCtrl, COleControl)
	//{{AFX_MSG_MAP(CTicTacToeCtrl)
	ON_WM_LBUTTONDBLCLK()
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CTicTacToeCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CTicTacToeCtrl)
	DISP_FUNCTION(CTicTacToeCtrl, "SetMyIcon", SetMyIcon, VT_EMPTY, VTS_I2)
	DISP_FUNCTION(CTicTacToeCtrl, "Restart", Restart, VT_EMPTY, VTS_NONE)
	//}}AFX_DISPATCH_MAP
	DISP_FUNCTION_ID(CTicTacToeCtrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CTicTacToeCtrl, COleControl)
	//{{AFX_EVENT_MAP(CTicTacToeCtrl)
	EVENT_CUSTOM("GameWon", FireGameWon, VTS_I2)
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CTicTacToeCtrl, 1)
	PROPPAGEID(CTicTacToePropPage::guid)
END_PROPPAGEIDS(CTicTacToeCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CTicTacToeCtrl, "TICTACTOE.TicTacToeCtrl.1",
	0xc784f715, 0x9ea0, 0x11d3, 0xbd, 0xcf, 0, 0xa0, 0xc9, 0x70, 0xef, 0xdb)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CTicTacToeCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DTicTacToe =
		{ 0xc784f713, 0x9ea0, 0x11d3, { 0xbd, 0xcf, 0, 0xa0, 0xc9, 0x70, 0xef, 0xdb } };
const IID BASED_CODE IID_DTicTacToeEvents =
		{ 0xc784f714, 0x9ea0, 0x11d3, { 0xbd, 0xcf, 0, 0xa0, 0xc9, 0x70, 0xef, 0xdb } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwTicTacToeOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CTicTacToeCtrl, IDS_TICTACTOE, _dwTicTacToeOleMisc)


/////////////////////////////////////////////////////////////////////////////
// CTicTacToeCtrl::CTicTacToeCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CTicTacToeCtrl

BOOL CTicTacToeCtrl::CTicTacToeCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_TICTACTOE,
			IDB_TICTACTOE,
			afxRegApartmentThreading,
			_dwTicTacToeOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// CTicTacToeCtrl::CTicTacToeCtrl - Constructor

CTicTacToeCtrl::CTicTacToeCtrl()
{
	InitializeIIDs(&IID_DTicTacToe, &IID_DTicTacToeEvents);

	// TODO: Initialize your control's instance data here.
	m_State = NOT_STARTED;
	opponentMoveDue = FALSE;
	m_MyIcon = CROSS;
	int i,j;
	for ( i=0; i < 3; i++)
		for (j=0; j < 3; j++)
			m_Cell[i][j] = INVALID;   //Not selected yet
}


/////////////////////////////////////////////////////////////////////////////
// CTicTacToeCtrl::~CTicTacToeCtrl - Destructor

CTicTacToeCtrl::~CTicTacToeCtrl()
{
	// TODO: Cleanup your control's instance data here.
}


/////////////////////////////////////////////////////////////////////////////
// CTicTacToeCtrl::OnDraw - Drawing function

void CTicTacToeCtrl::OnDraw(
			CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{

	CPoint Hor1Start, Hor2Start, Hor1End, Hor2End;
	CPoint Ver1Start, Ver1End, Ver2Start, Ver2End;

	Hor1Start.x = Hor2Start.x = rcBounds.left;
	Hor1End.x = Hor2End.x = rcBounds.right;

	Hor1End.y = Hor1Start.y = (rcBounds.bottom - rcBounds.top)/3  + rcBounds.top;
	Hor2End.y = Hor2Start.y = 2*(rcBounds.bottom - rcBounds.top)/3  + rcBounds.top;

	Ver1Start.y = Ver2Start.y = rcBounds.top;
	Ver1End.y = Ver2End.y = rcBounds.bottom;

	Ver1End.x  = Ver1Start.x = (rcBounds.right - rcBounds.left)/3 + rcBounds.left;
	Ver2End.x  = Ver2Start.x = 2*(rcBounds.right - rcBounds.left)/3 + rcBounds.left;

	int i;
	for(i=0; i < 4; i++)
		m_Coordinates[i][0].y = rcBounds.top;
	for(i=0; i < 4; i++)
		m_Coordinates[i][1].y = Hor1Start.y;
	for(i=0; i < 4; i++)
		m_Coordinates[i][2].y = Hor2Start.y;
	for(i=0; i < 4; i++)
		m_Coordinates[i][3].y = rcBounds.bottom;

	for(i=0; i < 4; i++)
		m_Coordinates[0][i].x = rcBounds.left;
	for(i=0; i < 4; i++)
		m_Coordinates[1][i].x = Ver1Start.x;
	for(i=0; i < 4; i++)
		m_Coordinates[2][i].x = Ver2Start.x;
	for(i=0; i < 4; i++)
		m_Coordinates[3][i].x = rcBounds.right;



	// TODO: Replace the following code with your own drawing code.
	pdc->FillRect(rcBounds, CBrush::FromHandle((HBRUSH)GetStockObject(WHITE_BRUSH)));
	pdc->MoveTo(Hor1Start);
	pdc->LineTo(Hor1End);
	pdc->MoveTo(Hor2Start);
	pdc->LineTo(Hor2End);
	pdc->MoveTo(Ver1Start);
	pdc->LineTo(Ver1End);
	pdc->MoveTo(Ver2Start);
	pdc->LineTo(Ver2End);

	// Fill the Selected Rectangle
	CRect tmpRect;
	int j;
	for (i =0; i < 3; i++)
		for (j=0; j < 3; j++)
		{
			//Form the rectangle.
			tmpRect.left = m_Coordinates[i][j].x;
			tmpRect.right = m_Coordinates[i+1][j].x;
			tmpRect.top = m_Coordinates[i][j].y;
			tmpRect.bottom = m_Coordinates[i][j+1].y;
			if ( m_Cell[i][j] == ME)
			{	
				if ( m_MyIcon == CROSS )
					addCross(tmpRect,pdc);
				else
					addCircle(tmpRect,pdc);	
			}
			else if ( m_Cell[i][j] == OPPONENT)
			{
				if ( m_MyIcon == CROSS )
					addCircle(tmpRect,pdc);
				else
					addCross(tmpRect,pdc);
			}
		}
	if ( opponentMoveDue )
	{
		playOpponent(&i, &j);
		HCURSOR cur = LoadCursor(NULL,IDC_WAIT);
		HCURSOR oldcur = SetCursor(cur);
		Sleep(1000);
		SetCursor(oldcur);
		tmpRect.left = m_Coordinates[i][j].x;
		tmpRect.right = m_Coordinates[i+1][j].x;
		tmpRect.top = m_Coordinates[i][j].y;
		tmpRect.bottom = m_Coordinates[i][j+1].y;
		if ( m_MyIcon == CROSS )
			addCircle(tmpRect,pdc);
		else
			addCross(tmpRect,pdc);
		opponentMoveDue = FALSE;
		if ( isWinner(OPPONENT) ){
			m_State = FINISHED;
			FireGameWon(OPPONENT);
		}
	}

}


/////////////////////////////////////////////////////////////////////////////
// CTicTacToeCtrl::DoPropExchange - Persistence support

void CTicTacToeCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	// TODO: Call PX_ functions for each persistent custom property.

}


/////////////////////////////////////////////////////////////////////////////
// CTicTacToeCtrl::OnResetState - Reset control to default state

void CTicTacToeCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	// TODO: Reset any other control state here.
}


/////////////////////////////////////////////////////////////////////////////
// CTicTacToeCtrl::AboutBox - Display an "About" box to the user

void CTicTacToeCtrl::AboutBox()
{
	CDialog dlgAbout(IDD_ABOUTBOX_TICTACTOE);
	dlgAbout.DoModal();
}


/////////////////////////////////////////////////////////////////////////////
// CTicTacToeCtrl message handlers

void CTicTacToeCtrl::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	short x,y;
	if ( m_State == NOT_STARTED)
		m_State = STARTED;
	if ( m_State == FINISHED)
		goto done;
	if ( selectionCell(point, &x,&y) )
	{
		if ( m_Cell[x][y] == INVALID )
			m_Cell[x][y] = ME;
		else
			goto done;
		if ( isWinner(ME) ){
			FireGameWon(ME);
			m_State = FINISHED;
			goto done;
		}
	}

	opponentMoveDue = TRUE;



done:
	COleControl::OnLButtonDblClk(nFlags, point);
	InvalidateControl();		
}

void CTicTacToeCtrl::SetMyIcon(short icon) 
{
	// TODO: Add your dispatch handler code here
	if ( icon != CROSS && icon != CIRCLE )
		return;
	if ( m_State != STARTED)
		m_MyIcon = icon;
}

void CTicTacToeCtrl::Restart() 
{
	// TODO: Add your dispatch handler code here
	m_State = NOT_STARTED;
	int i,j;
	for ( i=0; i < 3; i++)
		for (j=0; j < 3; j++)
			m_Cell[i][j] = INVALID;   //Not selected yet.

	InvalidateControl();
	opponentMoveDue = FALSE;
}

// This function generates a random move for the opponent from
// the available moves. 
// int *a : holds the x value of the 3 by 3 grid for the opponent's move.
// int *b : holds the y value of the 3 by 3 grid for the opponent's move.
void CTicTacToeCtrl::playOpponent(int * a, int * b)
{
	srand(1021);
	int x,y;
	BOOL flag = FALSE;

	// check if everything has already been taken.
	for (int i=0; i < 3; i++)
		for(int j =0; j< 3; j++)
			if (m_Cell[i][j] == INVALID)
			{	flag = TRUE;
				break;
			}
		
	if ( flag == FALSE)
	{
		m_State = FINISHED;
		FireGameWon(INVALID); // this would mean a "draw"
		return;
	}
	do{
		x = rand()%3;
	    y = rand()%3;
	}while(m_Cell[x][y] != INVALID );
	
	m_Cell[x][y] = OPPONENT;
	*a = x; 
	*b = y;
	return;
}


// This function draws a circle in the cell specified by CRect.
// CDC *pdc : the device context of the window for the cell.
void CTicTacToeCtrl::addCircle(CRect rect, CDC * pdc)
{
	CRect tmpRect;
	int length, height;
	length = rect.right - rect.left;
	height = rect.bottom - rect.top;
	tmpRect.left = rect.left + length/3;
	tmpRect.right = rect.left + (2*length)/3;
	tmpRect.top = rect.top + height/3;
	tmpRect.bottom = rect.top + (2*height)/3;
	pdc->Ellipse(tmpRect);
}


// This function draws a cross in the cell specified by CRect.
// CDC *pdc : the device context of the window for the cell.
void CTicTacToeCtrl::addCross(CRect rect, CDC * pdc)
{
	CPoint one, two, three, four;
	int length, height;
	length = rect.right - rect.left;
	height = rect.bottom - rect.top;
	one.x = rect.left + length/3;
	one.y = rect.top + height/3;
	two.x = rect.left + (2*length)/3;
	two.y = rect.top + (2*height)/3;
	pdc->MoveTo(one);
	pdc->LineTo(two);

	three.x =  rect.left + (2*length)/3;
	three.y =  rect.top  + height/3;
	four.x  =  rect.left + length/3;
	four.y =   rect.top  + (2*height)/3;
	pdc->MoveTo(three);
	pdc->LineTo(four);

}


// This function decides if the member specified by 
// "who" is the winner. If "who" wins, the function
// returns TRUE. Else it returns FALSE.
BOOL CTicTacToeCtrl::isWinner(short who)
{

	int i;

	// check columns 
	for (i=0; i < 3; i++)
	{
		if( ( m_Cell[i][0] == who ) &&
			( m_Cell[i][1] == who ) &&
			( m_Cell[i][2] == who ) )
			return TRUE;
	}

	// check rows 
	for (i=0; i < 3; i++)
	{
		if( ( m_Cell[0][i] == who ) &&
			( m_Cell[1][i] == who ) &&
			( m_Cell[2][i] == who ) )
			return TRUE;
	}

	// check first diagonal i.e. left to right 
	if( ( m_Cell[0][0] == who ) &&
		( m_Cell[1][1] == who ) &&
		( m_Cell[2][2] == who ) )
		return TRUE;

	// check last diagonal i.e. right to left
	if( ( m_Cell[0][2] == who ) &&
		( m_Cell[1][1] == who ) &&
		( m_Cell[2][0] == who ) )
		return TRUE;


	return FALSE;
}


// This function finds out the cell where the mouse button was clicked.
// CPoint input : co-ordinates of the mouse button click.
// short *x : returns the x value of the 3 by 3 grid where mouse was clicked.
// short *y : returns the y value of the 3 by 3 grid where mouse was clicked.
BOOL CTicTacToeCtrl::selectionCell(CPoint input, short * x, short * y)
{
	int i,j;
	for (i=0; i < 3; i++)
	{
		for (j=0; j < 3; j++)
		{
			if( ( input.x > m_Coordinates[i][j].x )  && 
				( input.x < m_Coordinates[i+1][j].x) &&
				( input.y > m_Coordinates[i][j].y)   &&
				( input.y < m_Coordinates[i][j+1].y) )
			{
				*x = i;
				*y = j;
				return TRUE;
			}
		
		}
	}
	return FALSE;
}