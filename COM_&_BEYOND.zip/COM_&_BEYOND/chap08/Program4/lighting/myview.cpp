#include <afxwin.h>
#include "myview.h"
#include <math.h>

#include "mydialog.h"

#include "resource.h"

IMPLEMENT_DYNCREATE ( myview, CView ) 

BEGIN_MESSAGE_MAP ( myview, CView )

	ON_WM_CREATE( )
	ON_WM_SIZE( )
	ON_WM_DESTROY( ) 
	ON_COMMAND ( 101, lighting )

END_MESSAGE_MAP( )

BOOL myview::PreCreateWindow ( CREATESTRUCT& cs )
{
	cs.style |= WS_CLIPCHILDREN | WS_CLIPSIBLINGS ;
	return CView::PreCreateWindow ( cs ) ;
}

int myview::OnCreate ( LPCREATESTRUCT l )
{
	CView::OnCreate ( l ) ;

	PIXELFORMATDESCRIPTOR pfd =
	{
		sizeof ( PIXELFORMATDESCRIPTOR ), 
		1,
		PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL,
		PFD_TYPE_RGBA,
		24,
		0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 
		32,
		0, 0,
		PFD_MAIN_PLANE,
		0,
		0, 0, 0
	} ;

	m_d = new CClientDC ( this ) ;

	int pixformat = ChoosePixelFormat ( m_d -> m_hDC, &pfd ) ;
	SetPixelFormat ( m_d -> m_hDC, pixformat, &pfd ) ;

	DescribePixelFormat ( m_d -> m_hDC, pixformat, sizeof ( pfd ), &pfd ) ;

	if ( pfd.dwFlags & PFD_NEED_PALETTE )
		setuplogicalpalette( ) ;

	m_hGRC = wglCreateContext ( m_d -> m_hDC ) ;
	wglMakeCurrent ( m_d -> m_hDC, m_hGRC ) ;

	glShadeModel ( GL_SMOOTH ) ;

	glClearDepth ( 1.0f ) ;
	glEnable ( GL_DEPTH_TEST ) ;

	ambient_light0_src[0] = 1.0f ;
	ambient_light0_src[1] = 1.0f ;
	ambient_light0_src[2] = 1.0f ;
	ambient_light0_src[3] = 1.0f ;

	diffuse_light0_src[0] = 0.0f ;
	diffuse_light0_src[1] = 1.0f ;
	diffuse_light0_src[2] = 0.0f ;
	diffuse_light0_src[3] = 1.0f ;

	specular_light0_src[0] = 1.0f ;
	specular_light0_src[1] = 1.0f ;
	specular_light0_src[2] = 1.0f ;
	specular_light0_src[3] = 1.0f ;

	position_light0[0] = 0.0f ;
	position_light0[1] = 1.0f ;
	position_light0[2] = 1.0f ;
	position_light0[3] = 0.0f ;

	ambient_material[0] = 0.0f ;
	ambient_material[1] = 0.5f ;
	ambient_material[2] = 1.0f ;
	ambient_material[3] = 1.0f ;

	diffuse_material[0] = 0.0f ;
	diffuse_material[1] = 0.0f ;
	diffuse_material[2] = 0.0f ;
	diffuse_material[3] = 1.0f ;

	specular_material[0] = 1.0f ;
	specular_material[1] = 0.0f ;
	specular_material[2] = 0.0f ;
	specular_material[3] = 1.0f ;

	shininess_material = 120.0f ;

	return 1 ;
}

void myview::setuplogicalpalette( )
{
    struct
    {
        WORD ver ;
        WORD num ;
        PALETTEENTRY entries[256];
    } logicalpalette = { 0x300, 256 };

    BYTE reds[ ] = { 0, 36, 72, 109, 145, 182, 218, 255 } ;
    BYTE greens[ ] = { 0, 36, 72, 109, 145, 182, 218, 255 } ;
    BYTE blues[ ] = { 0, 85, 170, 255 } ;

    for ( int cn = 0 ; cn < 256 ; ++cn )
    {	
        logicalpalette.entries[cn].peRed = reds[cn & 0x07] ;
        logicalpalette.entries[cn].peGreen = greens[( cn >> 0x03 ) & 0x07] ;
        logicalpalette.entries[cn].peBlue = blues[( cn >> 0x06 ) & 0x03] ;
        logicalpalette.entries[cn].peFlags = 0 ;
    }

    m_hpalette = CreatePalette ( ( LOGPALETTE* ) &logicalpalette ) ;

	if ( m_hpalette )
	{
		SelectPalette ( m_d -> m_hDC, m_hpalette, FALSE ) ;
		RealizePalette ( m_d -> m_hDC ) ;
	}
}

void myview::OnSize ( UINT type, int cx, int cy )
{
	glViewport ( 0, 0, cx, cy ) ;

	glMatrixMode ( GL_PROJECTION ) ;
	glLoadIdentity( ) ;

	GLdouble asp = ( GLdouble ) cx / ( GLdouble ) cy ;
	gluPerspective ( 40.0, asp, 2.0, 7.0 ) ;

	glMatrixMode ( GL_MODELVIEW ) ;
	glLoadIdentity( ) ;
	glTranslatef ( 0.0f, 0.0f, -3.5f ) ;
}

void myview::OnDraw ( CDC *p )
{
	glClearColor ( 0.0f, 0.0f, 0.0f, 0.0f ) ;
	glClear ( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT ) ;

	glPushMatrix( ) ;

	glMaterialfv ( GL_FRONT, GL_AMBIENT_AND_DIFFUSE, ambient_material ) ;
	glMaterialfv ( GL_FRONT, GL_DIFFUSE, diffuse_material ) ;
	glMaterialfv ( GL_FRONT, GL_SPECULAR, specular_material ) ;
	glMaterialf ( GL_FRONT, GL_SHININESS, shininess_material ) ;
	
	glLightfv ( GL_LIGHT0, GL_AMBIENT, ambient_light0_src ) ;
	glLightfv ( GL_LIGHT0, GL_DIFFUSE, diffuse_light0_src ) ;
	glLightfv ( GL_LIGHT0, GL_SPECULAR, specular_light0_src ) ;
	glLightfv ( GL_LIGHT0, GL_POSITION, position_light0 ) ;

	glEnable ( GL_LIGHTING ) ;
	glEnable ( GL_LIGHT0 ) ;

	auxSolidSphere ( 1.0f ) ;

	glPopMatrix( ) ;
	glFlush( ) ;
}

void myview::lighting( )
{
	mydialog d ;

	if ( d.DoModal( ) == IDOK )
	{
		ambient_light0_src[0] = d.amb_lig0_src[0] ;
		ambient_light0_src[1] = d.amb_lig0_src[1] ;
		ambient_light0_src[2] = d.amb_lig0_src[2] ;

		diffuse_light0_src[0] = d.diff_lig0_src[0] ;
		diffuse_light0_src[1] = d.diff_lig0_src[1] ;
		diffuse_light0_src[2] = d.diff_lig0_src[2] ;

		specular_light0_src[0] = d.spec_lig0_src[0] ;
		specular_light0_src[1] = d.spec_lig0_src[1] ;
		specular_light0_src[2] = d.spec_lig0_src[2] ;

		position_light0[0] = d.pos_lig0[0] ;
		position_light0[1] = d.pos_lig0[1] ;
		position_light0[2] = d.pos_lig0[2] ;

		ambient_material[0] = d.amb_mtr[0] ;
		ambient_material[1] = d.amb_mtr[1] ;
		ambient_material[2] = d.amb_mtr[2] ;

		diffuse_material[0] = d.diff_mtr[0] ;
		diffuse_material[1] = d.diff_mtr[1] ;
		diffuse_material[2] = d.diff_mtr[2] ;

		specular_material[0] = d.spec_mtr[0] ;
		specular_material[1] = d.spec_mtr[1] ;
		specular_material[2] = d.spec_mtr[2] ;

		shininess_material = d.shin_mtr ;

		Invalidate( ) ;
	}
}

void myview::OnDestroy( )
{
	wglMakeCurrent ( NULL, NULL ) ;
	wglDeleteContext ( m_hGRC ) ;

	if ( m_hpalette )
		DeleteObject ( m_hpalette ) ;
}