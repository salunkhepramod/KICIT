#include <afxwin.h>
#include "myframe.h" 
#include "myview.h" 
#include "mydialog.h" 
	
#include "resource.h" 

mydialog::mydialog( ) : CDialog ( IDD_DIALOG1 )
{
	p = ( myview * ) ( ( myframe * ) AfxGetMainWnd( ) ) -> GetActiveView( ) ;
}

int mydialog::OnInitDialog( ) 
{
	// light source properties
	amb_lig0_src[0] = p -> ambient_light0_src[0] ;
	amb_lig0_src[1] = p -> ambient_light0_src[1] ;
	amb_lig0_src[2] = p -> ambient_light0_src[2] ;

	diff_lig0_src[0] = p -> diffuse_light0_src[0] ;
	diff_lig0_src[1] = p -> diffuse_light0_src[1] ;
	diff_lig0_src[2] = p -> diffuse_light0_src[2] ;

	spec_lig0_src[0] = p -> specular_light0_src[0] ;
	spec_lig0_src[1] = p -> specular_light0_src[1] ;
	spec_lig0_src[2] = p -> specular_light0_src[2] ;

	pos_lig0[0] = p -> position_light0[0] ;
	pos_lig0[1] = p -> position_light0[1] ;
	pos_lig0[2] = p -> position_light0[2] ;

	// material properties
	amb_mtr[0] = p -> ambient_material[0] ;
	amb_mtr[1] = p -> ambient_material[1] ;
	amb_mtr[2] = p -> ambient_material[2] ;

	diff_mtr[0] = p -> diffuse_material[0] ;
	diff_mtr[1] = p -> diffuse_material[1] ;
	diff_mtr[2] = p -> diffuse_material[2] ;

	spec_mtr[0] = p -> specular_material[0] ;
	spec_mtr[1] = p -> specular_material[1] ;
	spec_mtr[2] = p -> specular_material[2] ;

	shin_mtr = p -> shininess_material ;

	return CDialog::OnInitDialog( ) ;
}

void mydialog::DoDataExchange ( CDataExchange *pdx )
{
	DDX_Text ( pdx, IDC_EDIT1, amb_lig0_src[0] ) ;
	DDX_Text ( pdx, IDC_EDIT2, amb_lig0_src[1] ) ;
	DDX_Text ( pdx, IDC_EDIT3, amb_lig0_src[2] ) ;

	DDX_Text ( pdx, IDC_EDIT4, diff_lig0_src[0] ) ;
	DDX_Text ( pdx, IDC_EDIT5, diff_lig0_src[1] ) ;
	DDX_Text ( pdx, IDC_EDIT6, diff_lig0_src[2] ) ;

	DDX_Text ( pdx, IDC_EDIT7, spec_lig0_src[0] ) ;
	DDX_Text ( pdx, IDC_EDIT8, spec_lig0_src[1] ) ;
	DDX_Text ( pdx, IDC_EDIT9, spec_lig0_src[2] ) ;

	DDX_Text ( pdx, IDC_EDIT10, amb_mtr[0] ) ;
	DDX_Text ( pdx, IDC_EDIT11, amb_mtr[1] ) ;
	DDX_Text ( pdx, IDC_EDIT12, amb_mtr[2] ) ;

	DDX_Text ( pdx, IDC_EDIT13, diff_mtr[0] ) ;
	DDX_Text ( pdx, IDC_EDIT14, diff_mtr[1] ) ;
	DDX_Text ( pdx, IDC_EDIT15, diff_mtr[2] ) ;

	DDX_Text ( pdx, IDC_EDIT16, spec_mtr[0] ) ;
	DDX_Text ( pdx, IDC_EDIT17, spec_mtr[1] ) ;
	DDX_Text ( pdx, IDC_EDIT18, spec_mtr[2] ) ;

	DDX_Text ( pdx, IDC_EDIT19, shin_mtr ) ;

	DDX_Text ( pdx, IDC_EDIT20, pos_lig0[0] ) ;
	DDX_Text ( pdx, IDC_EDIT21, pos_lig0[1] ) ;
	DDX_Text ( pdx, IDC_EDIT22, pos_lig0[2] ) ;
}

void mydialog::OnOK( )
{
	CDialog::OnOK( ) ;
}

