class mydialog : public CDialog 
{
	public :

		myview *p ;

		float amb_lig0_src[4], diff_lig0_src[4], spec_lig0_src[4], pos_lig0[4] ;
		float amb_mtr[4], diff_mtr[4], spec_mtr[4] ;
		float shin_mtr ;

	public :

		mydialog( ) ;
		int OnInitDialog( ) ;
		void DoDataExchange ( CDataExchange *pdx ) ;
		void OnOK( ) ;
} ;

