#include <gl\gl.h>
#include <gl\glaux.h>

class myview : public CView
{
	DECLARE_DYNCREATE ( myview ) ;

	private :

		HGLRC m_hGRC ;
		HPALETTE m_hpalette ;
		CClientDC *m_d ;

	public :

		GLfloat ambient_light0_src[4] ;
		GLfloat diffuse_light0_src[4] ;
		GLfloat specular_light0_src[4] ;

		GLfloat position_light0[4] ;
		
		GLfloat ambient_material[4] ;
		GLfloat diffuse_material[4] ;
		GLfloat specular_material[4] ;

		GLfloat shininess_material ;

	public :

		BOOL PreCreateWindow ( CREATESTRUCT& cs ) ;

		int OnCreate ( LPCREATESTRUCT l ) ;
		void OnSize ( UINT type, int cx, int cy ) ;
		void OnDraw ( CDC *p ) ;
		void drawcube( ) ;
		void setuplogicalpalette( ) ;
		void lighting( ) ;
		void OnDestroy( ) ;

	DECLARE_MESSAGE_MAP( )
} ;