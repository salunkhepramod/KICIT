#include "resource.h"

class myapp : public CWinApp
{
	public :

		virtual BOOL InitInstance( ) ;
		BOOL checkoption ( LPTSTR lpsz, LPTSTR lpszoption ) ;
		void doconfig( ) ;
		void dopreview( ) ;
		void dofullscreen( ) ;
} ;
