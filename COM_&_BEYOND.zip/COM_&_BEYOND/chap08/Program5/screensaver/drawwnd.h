#include <gl\gl.h>

class drawwnd : public CWnd
{
	private :

		HGLRC m_hGRC ;
		HPALETTE m_hpalette ;
		CClientDC *m_d ;
		BOOL m_busydrawing ;
		UINT m_time ;

	public :

		GLfloat m_x_degrees ;
		GLfloat m_y_degrees ;
		GLfloat m_z_degrees ;
		void setuplogicalpalette( ) ;
		void OnDestroy( )  ;

	public :

		BOOL PreCreateWindow ( CREATESTRUCT& cs ) ;
		void OnSize ( UINT type, int cx, int cy ) ;

	private :
	
		BOOL m_deleteflag ;

	public:
	
		drawwnd ( BOOL deleteflag ) ;

		BOOL Create ( DWORD exstyle, DWORD style, const RECT& r, 
						CWnd *p, UINT id, CCreateContext *pc=NULL ) ;
		int OnCreate ( LPCREATESTRUCT l ) ;
		void OnTimer ( UINT id ) ;
		void draw( ) ; 
		virtual void PostNcDestroy( ) ;

	DECLARE_MESSAGE_MAP( )
} ;

