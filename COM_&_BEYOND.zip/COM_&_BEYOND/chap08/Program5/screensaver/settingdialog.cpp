#include <afxwin.h>
#include "drawwnd.h"
#include "settingdialog.h"
#include "resource.h"

BEGIN_MESSAGE_MAP ( settingdialog, CDialog )
	ON_EN_CHANGE ( IDC_EDIT1, editchange )
END_MESSAGE_MAP( )

settingdialog::settingdialog ( int n ) : CDialog ( n ), m_preview ( FALSE )
{
}

BOOL settingdialog::OnInitDialog( )
{
	time = AfxGetApp( ) -> GetProfileInt ( "Config", "Time", 0 ) ;

	CStatic *s = ( CStatic * ) GetDlgItem ( IDC_PREVIEW ) ;
	CRect r ;
	s -> GetWindowRect ( &r ) ;
	ScreenToClient ( &r ) ;
	m_preview.Create ( NULL, WS_VISIBLE | WS_CHILD, r, this, NULL ) ;

	return CDialog::OnInitDialog( ) ;
}

void settingdialog::DoDataExchange ( CDataExchange *pdx )
{
	CDialog::DoDataExchange ( pdx ) ;
	DDX_Text ( pdx, IDC_EDIT1, time ) ;
}

void settingdialog::editchange( )
{
	UINT t = GetDlgItemInt ( IDC_EDIT1, NULL, FALSE ) ;
	m_preview.SetTimer ( 1, t, NULL ) ;
}

void settingdialog::OnOK( )
{
	CDialog::OnOK( ) ;
	AfxGetApp( ) -> WriteProfileInt ( "Config", "Time", time ) ;
}

