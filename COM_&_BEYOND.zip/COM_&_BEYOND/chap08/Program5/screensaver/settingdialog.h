class settingdialog : public CDialog
{
	public :

		UINT time ;
		drawwnd m_preview ;

	public :
		
		settingdialog ( int n ) ;
		BOOL OnInitDialog( ) ;
		void DoDataExchange ( CDataExchange *pdx ) ;
		void editchange( ) ;
		void OnOK( ) ;

	DECLARE_MESSAGE_MAP( ) 
} ;
