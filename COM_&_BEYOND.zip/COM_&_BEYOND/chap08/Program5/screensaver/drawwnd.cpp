#include "afxwin.h"
#include "myapp.h"
#include "drawwnd.h"

BEGIN_MESSAGE_MAP ( drawwnd, CWnd )

	ON_WM_TIMER( )
	ON_WM_CREATE( )
	ON_WM_SIZE( )
	ON_WM_DESTROY( )

END_MESSAGE_MAP( )

drawwnd::drawwnd ( BOOL deleteflag )
{
	m_deleteflag = deleteflag ;
	m_time = AfxGetApp( ) -> GetProfileInt ( "Config", "Time", 0 ) ;
}

BOOL drawwnd::Create ( DWORD exstyle, DWORD style, const RECT& r, 
						CWnd *p, UINT id, CCreateContext *pc ) 
{
	CBrush mybrush ( RGB ( 0, 0, 0 ) ) ;

	CString mywindowclass ;
	mywindowclass = AfxRegisterWndClass ( CS_HREDRAW | CS_VREDRAW, 
										AfxGetApp( ) -> LoadCursor ( IDC_NULLCURSOR ), 
										mybrush, 0 ) ;

	return CreateEx ( exstyle, mywindowclass, "", style, 
						r.left, r.top, r.right - r.left, r.bottom - r.top, 
						p -> GetSafeHwnd( ), NULL, NULL ) ;
}

BOOL drawwnd::PreCreateWindow ( CREATESTRUCT& cs )
{
	cs.style |= WS_CLIPCHILDREN | WS_CLIPSIBLINGS ;
	return CWnd::PreCreateWindow ( cs ) ;
}

int drawwnd::OnCreate ( LPCREATESTRUCT l ) 
{
	CWnd::OnCreate ( l ) ;

	PIXELFORMATDESCRIPTOR pfd =
	{
		sizeof ( PIXELFORMATDESCRIPTOR ), 
		1,
		PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER,
		PFD_TYPE_RGBA,
		24,
		0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 
		32,
		0, 0,
		PFD_MAIN_PLANE,
		0,
		0, 0, 0
	} ;

	m_d = new CClientDC ( this ) ;

	int index = ChoosePixelFormat ( m_d -> m_hDC, &pfd ) ;
	SetPixelFormat ( m_d -> m_hDC, index, &pfd ) ;

	DescribePixelFormat ( m_d -> m_hDC, index, sizeof ( pfd ), &pfd ) ;

	if ( pfd.dwFlags & PFD_NEED_PALETTE )
		setuplogicalpalette( ) ;

	m_hGRC = wglCreateContext ( m_d -> m_hDC ) ;
	wglMakeCurrent ( m_d -> m_hDC, m_hGRC ) ;

	glClearDepth ( 1.0f ) ;
	glEnable ( GL_DEPTH_TEST ) ;

	m_x_degrees = 1.0f ;
	m_y_degrees = 10.0f ;
	m_z_degrees = 5.0f ;

	m_busydrawing = FALSE ;

	SetTimer ( 1, m_time, NULL ) ;

	return 0 ;
}

void drawwnd::setuplogicalpalette( )
{
    struct
    {
        WORD ver ;
        WORD num ;
        PALETTEENTRY entries[256];
    } logicalpalette = { 0x300, 256 };

    BYTE reds[ ] = { 0, 20, 40, 120, 140, 180, 220, 255 } ;
    BYTE greens[ ] = { 0, 20, 40, 120, 140, 180, 220, 255 } ;
    BYTE blues[ ] = { 0, 20, 40, 120, 140, 180, 220, 255 } ;

    for ( int cn = 0 ; cn < 256 ; ++cn )
    {	
        logicalpalette.entries[cn].peRed = reds[cn & 0x07] ;
        logicalpalette.entries[cn].peGreen = greens[( cn >> 0x03 ) & 0x07] ;
        logicalpalette.entries[cn].peBlue = blues[( cn >> 0x06 ) & 0x03] ;
        logicalpalette.entries[cn].peFlags = 0 ;
    }

    m_hpalette = CreatePalette ( ( LOGPALETTE* ) &logicalpalette ) ;

	if ( m_hpalette )
	{
		SelectPalette ( m_d -> m_hDC, m_hpalette, FALSE ) ;
		RealizePalette ( m_d -> m_hDC ) ;
	}
}

void drawwnd::OnSize ( UINT type, int cx, int cy )
{
	glViewport ( 0, 0, cx, cy ) ;

	glMatrixMode ( GL_PROJECTION ) ;
	glLoadIdentity( ) ;
	glFrustum ( -1.0, 1.0, -1.0, 1.0, 2, 7.0 ) ;

	glMatrixMode ( GL_MODELVIEW ) ;
	glLoadIdentity( ) ;
}

void drawwnd::OnTimer ( UINT id ) 
{
	draw( ) ;
	MSG m ;
	while ( ::PeekMessage ( &m, m_hWnd, WM_TIMER, WM_TIMER, PM_REMOVE ) )
		;
}

void drawwnd::draw( ) 
{
	if ( m_busydrawing == TRUE )
		return ;

	m_busydrawing = TRUE ;

	glClearColor ( 0.0f, 0.0f, 0.0f, 0.0f ) ;
	glClear ( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT ) ;

	glPushMatrix( ) ;
	glTranslatef ( 0.0f, 0.0f, -6.0f ) ;

	m_x_degrees += 1.0f ;
	m_y_degrees += 10.0f ;
	m_z_degrees += 5.0f ;

	glRotatef ( m_x_degrees, 1.0f, 0.0f, 0.0f ) ;
	glRotatef ( m_y_degrees,  0.0f, 1.0f,  0.0f ) ;
	glRotatef ( m_z_degrees,  0.0f,  0.0f, 1.0f ) ;


    glBegin ( GL_POLYGON ) ;

		glColor3f ( 1.0f, 0.0f, 0.0f ) ; 
        glVertex3f ( -0.5f, 0.5f, 0.5f ) ; // lt front

		glColor3f ( 1.0f, 1.0f, 1.0f ) ; 
        glVertex3f ( -0.5f, -0.5f, 0.5f ) ; // lb front

		glColor3f ( 0.0f, 1.0f, 1.0f ) ; 
        glVertex3f ( 0.5f, -0.5f, 0.5f ) ;  // rb front

		glColor3f ( 1.0f, 1.0f, 0.0f ) ; 
        glVertex3f ( 0.5f, 0.5f, 0.5f ) ;  // rt front

    glEnd( ) ;

    glBegin ( GL_POLYGON ) ;

		glColor3f ( 1.0f, 1.0f, 0.0f ) ; 
        glVertex3f ( 0.5f, 0.5f, 0.5f ) ;  // rt front

		glColor3f ( 0.0f, 1.0f, 1.0f ) ; 
        glVertex3f ( 0.5f, -0.5f, 0.5f ) ;  // rb front

		glColor3f ( 0.7f, 0.7f, 0.7f ) ; 
        glVertex3f ( 0.5f, -0.5f, -0.5f ) ;  // rb back

		glColor3f ( 0.0f, 1.0f, 0.0f ) ; 
        glVertex3f ( 0.5f, 0.5f, -0.5f ) ;  // rt back

    glEnd( ) ;

    glBegin ( GL_POLYGON ) ;

		glColor3f ( 0.0f, 1.0f, 0.0f ) ; 
        glVertex3f ( 0.5f, 0.5f, -0.5f ) ;  // rt back

		glColor3f ( 0.7f, 0.7f, 0.7f ) ; 
        glVertex3f ( 0.5f, -0.5f, -0.5f ) ;  // rb back

		glColor3f ( 1.0f, 0.0f, 1.0f ) ; 
        glVertex3f ( -0.5f, -0.5f, -0.5f ) ;  // lb back

		glColor3f ( 0.0f, 0.0f, 1.0f ) ; 
        glVertex3f ( -0.5f, 0.5f, -0.5f ) ;  // lt back

    glEnd( ) ;

    glBegin ( GL_POLYGON ) ;

		glColor3f ( 0.0f, 0.0f, 1.0f ) ; 
        glVertex3f ( -0.5f, 0.5f, -0.5f ) ;  // lt back

		glColor3f ( 1.0f, 0.0f, 1.0f ) ; 
        glVertex3f ( -0.5f, -0.5f, -0.5f ) ;  // lb back

		glColor3f ( 1.0f, 1.0f, 1.0f ) ; 
        glVertex3f ( -0.5f, -0.5f, 0.5f ) ;  // lb front

		glColor3f ( 1.0f, 0.0f, 0.0f ) ; 
        glVertex3f ( -0.5f, 0.5f, 0.5f ) ;  // lt front

    glEnd( ) ;

    glBegin ( GL_POLYGON ) ;

		glColor3f ( 0.0f, 0.0f, 1.0f ) ; 
		glVertex3f ( -0.5f, -0.5f, 0.5f ) ;  // lb front

		glColor3f ( 1.0f, 0.0f, 1.0f ) ; 
        glVertex3f ( -0.5f, -0.5f, -0.5f ) ;  // lb back

		glColor3f ( 0.7f, 0.7f, 0.7f ) ; 
        glVertex3f ( 0.5f, -0.5f, -0.5f ) ;  // rb back

		glColor3f ( 0.0f, 1.0f, 1.0f ) ; 
        glVertex3f ( 0.5f, -0.5f, 0.5f ) ;  // rb front

    glEnd();

    glBegin ( GL_POLYGON ) ;

		glColor3f ( 1.0f, 0.0f, 1.0f ) ; 
        glVertex3f ( -0.5f, 0.5f, -0.5f ) ;  // lt back

		glColor3f ( 1.0f, 0.0f, 0.0f ) ; 
        glVertex3f ( -0.5f, 0.5f, 0.5f ) ;  // lt front

		glColor3f ( 1.0f, 1.0f, 0.0f ) ; 
        glVertex3f ( 0.5f, 0.5f, 0.5f ) ;  // rt front

		glColor3f ( 0.0f, 1.0f, 0.0f ) ; 
        glVertex3f ( 0.5f, 0.5f, -0.5f ) ;  // rt back 

	glEnd( ) ;

	glPopMatrix( ) ;
	glFinish( ) ;

	SwapBuffers ( wglGetCurrentDC( ) ) ;

	m_busydrawing = FALSE ;
}

void drawwnd::OnDestroy( ) 
{
	KillTimer ( 1 ) ;

	wglDeleteContext ( m_hGRC ) ;

	if ( m_hpalette )
		DeleteObject ( m_hpalette ) ;

	delete m_d ;
}

void drawwnd::PostNcDestroy( ) 
{
	if ( m_deleteflag )
		delete this ;
}
