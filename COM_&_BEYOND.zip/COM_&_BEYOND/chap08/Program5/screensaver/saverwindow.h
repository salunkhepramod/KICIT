class saverwindow : public drawwnd
{
	private :

		CPoint lastpoint ;

	public :

		saverwindow ( BOOL deleteflag ) ;
		BOOL Create( ) ;
		void OnSysCommand ( UINT id, LPARAM l ) ;
		void OnDestroy( ) ;
		BOOL OnSetCursor ( CWnd* w, UINT hittest, UINT message ) ;
		BOOL OnNcActivate ( BOOL active ) ;
		void OnActivate ( UINT state, CWnd* w, BOOL flag ) ;
		void OnActivateApp ( BOOL active, HTASK t ) ;
		void OnMouseMove ( UINT flags, CPoint pt ) ;
		void OnLButtonDown ( UINT flags, CPoint pt ) ;
		void OnMButtonDown ( UINT flags, CPoint pt ) ;
		void OnRButtonDown ( UINT flags, CPoint pt ) ;
		void OnKeyDown ( UINT ch, UINT count, UINT flags ) ;
		void OnSysKeyDown ( UINT ch, UINT count, UINT flags ) ;

	DECLARE_MESSAGE_MAP( )
} ;
