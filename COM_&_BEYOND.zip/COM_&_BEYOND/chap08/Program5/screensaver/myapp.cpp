#include "afxwin.h"
#include "myapp.h"
#include "drawwnd.h"
#include "saverwindow.h"
#include "settingdialog.h"

myapp a ;

BOOL myapp::InitInstance( )
{
	SetRegistryKey ( "My Screen Saver" ) ;

	if ( __argc == 1 || checkoption ( __argv[1], "c" ) )
	{
		doconfig( ) ;
		return FALSE ;
	}
	else 
	{
		if ( checkoption ( __argv[1], "p" ) )
			dopreview( ) ;
		else 
		{
			if ( checkoption ( __argv[1], "s" ) )
				dofullscreen( ) ;
		}
	}

	return TRUE ;
}

BOOL myapp::checkoption ( LPTSTR lpsz, LPTSTR lpszOption )
{
	if ( lpsz[0] == '-' || lpsz[0] == '/' )
		lpsz++;

	if ( lstrcmpi ( lpsz, lpszOption ) == 0 )
		return TRUE ;

	return FALSE ;
}

void myapp::doconfig( )
{
	settingdialog d ( IDD_SAVER_DIALOG ) ;
	m_pMainWnd = &d ;
	d.DoModal( ) ;
}

void myapp::dopreview( )
{
	CWnd* parent = CWnd::FromHandle ( ( HWND ) atol ( __argv[2] ) ) ;

	CRect r ;
	parent -> GetClientRect ( &r ) ;

	drawwnd* p = new drawwnd ( TRUE ) ;

	p -> Create ( NULL, WS_VISIBLE | WS_CHILD, r, parent, NULL ) ;
	m_pMainWnd = p ;
}

void myapp::dofullscreen( )
{
	saverwindow* p = new saverwindow ( TRUE ) ;

	p -> Create( ) ;
	m_pMainWnd = p ;
}
