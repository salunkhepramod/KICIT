class mydialog : public CDialog 
{
	public :

		myview *p ;

		float x_t, y_t, z_t ;
		float x_s, y_s, z_s ;
		int x_r, y_r, z_r ;
		float deg ;

	public :

		mydialog( ) ;
		int OnInitDialog( ) ;
		void DoDataExchange ( CDataExchange *pdx ) ;
		void OnOK( ) ;
} ;

