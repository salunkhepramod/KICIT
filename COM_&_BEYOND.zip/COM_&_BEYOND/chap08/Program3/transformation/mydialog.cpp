#include <afxwin.h>
#include "myframe.h" 
#include "myview.h" 
#include "mydialog.h" 

#include "resource.h" 

mydialog::mydialog( ) : CDialog ( IDD_DIALOG1 )
{
	p = ( myview * ) ( ( myframe * ) AfxGetMainWnd( ) ) -> GetActiveView( ) ;
}

int mydialog::OnInitDialog( ) 
{
	x_t = ( float ) p -> m_x_trans ;
	y_t = ( float ) p -> m_y_trans ;
	z_t = ( float ) p -> m_z_trans ;

	x_s = p -> m_x_scale ;
	y_s = p -> m_y_scale ;
	z_s = p -> m_z_scale ;

	x_r = ( int ) p -> m_x_rotat ;
	y_r = ( int ) p -> m_y_rotat ;
	z_r = ( int ) p -> m_z_rotat ;

	deg = p -> m_degrees ;

	return CDialog::OnInitDialog( ) ;
}

void mydialog::DoDataExchange ( CDataExchange *pdx )
{
	DDX_Text ( pdx, IDC_EDIT1, x_t ) ;
	DDX_Text ( pdx, IDC_EDIT2, y_t ) ;
	DDX_Text ( pdx, IDC_EDIT3, z_t ) ;

	DDX_Text ( pdx, IDC_EDIT4, x_s ) ;
	DDX_Text ( pdx, IDC_EDIT5, y_s ) ;
	DDX_Text ( pdx, IDC_EDIT6, z_s ) ;

	DDX_Check ( pdx, IDC_CHECK1, x_r ) ;
	DDX_Check ( pdx, IDC_CHECK2, y_r ) ;
	DDX_Check ( pdx, IDC_CHECK3, z_r ) ;
	DDX_Text ( pdx, IDC_EDIT7, deg ) ;
}

void mydialog::OnOK( )
{
	CDialog::OnOK( ) ;
}

