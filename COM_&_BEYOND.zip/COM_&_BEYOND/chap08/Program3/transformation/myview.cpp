#include <afxwin.h>
#include "myview.h"
#include "mydialog.h"

#include "resource.h"

IMPLEMENT_DYNCREATE ( myview, CView ) 

BEGIN_MESSAGE_MAP ( myview, CView )

	ON_WM_CREATE( )
	ON_WM_SIZE( )
	ON_WM_DESTROY( ) 
	ON_COMMAND ( 101, dialog )

END_MESSAGE_MAP( )

BOOL myview::PreCreateWindow ( CREATESTRUCT& cs )
{
	cs.style |= WS_CLIPCHILDREN | WS_CLIPSIBLINGS ;
	return CView::PreCreateWindow ( cs ) ;
}

int myview::OnCreate ( LPCREATESTRUCT l )
{
	CView::OnCreate ( l ) ;

	PIXELFORMATDESCRIPTOR pfd =
	{
		sizeof ( PIXELFORMATDESCRIPTOR ), 
		1,
		PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL,
		PFD_TYPE_RGBA,
		24,
		0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 
		32,
		0, 0,
		PFD_MAIN_PLANE,
		0,
		0, 0, 0
	} ;

	m_d = new CClientDC ( this ) ;

	int pixformat = ChoosePixelFormat ( m_d -> m_hDC, &pfd ) ;
	SetPixelFormat ( m_d -> m_hDC, pixformat, &pfd ) ;

	DescribePixelFormat ( m_d -> m_hDC, pixformat, sizeof ( pfd ), &pfd ) ;

	if ( pfd.dwFlags & PFD_NEED_PALETTE )
		setuplogicalpalette( ) ;

	m_hGRC = wglCreateContext ( m_d -> m_hDC ) ;
	wglMakeCurrent ( m_d -> m_hDC, m_hGRC ) ;
	glClearDepth ( 1.0f ) ;
	glEnable ( GL_DEPTH_TEST ) ;

	glMatrixMode ( GL_PROJECTION ) ;
	glLoadIdentity( ) ;
	glFrustum ( -1.0, 1.0, -1.0, 1.0, 2, 7.0 ) ;
	glMatrixMode ( GL_MODELVIEW ) ;
	
	m_x_trans = m_y_trans = 0.0f ; 
	m_z_trans = -3.5f ;
	m_x_scale = m_y_scale = m_z_scale = 1.0f ;
	m_x_rotat = m_y_rotat = m_z_rotat = 1.0f ;
	m_degrees = -60.0f ;

	return 1 ;
}

void myview::setuplogicalpalette( )
{
    struct
    {
        WORD ver ;
        WORD num ;
        PALETTEENTRY entries[256];
    } logicalpalette = { 0x300, 256 };

    BYTE reds[ ] = { 0, 36, 72, 109, 145, 182, 218, 255 } ;
    BYTE greens[ ] = { 0, 36, 72, 109, 145, 182, 218, 255 } ;
    BYTE blues[ ] = { 0, 85, 170, 255 } ;

    for ( int cn = 0 ; cn < 256 ; ++cn )
    {	
        logicalpalette.entries[cn].peRed = reds[cn & 0x07] ;
        logicalpalette.entries[cn].peGreen = greens[( cn >> 0x03 ) & 0x07] ;
        logicalpalette.entries[cn].peBlue = blues[( cn >> 0x06 ) & 0x03] ;
        logicalpalette.entries[cn].peFlags = 0 ;
    }

    m_hpalette = CreatePalette ( ( LOGPALETTE* ) &logicalpalette ) ;

	if ( m_hpalette )
	{
		SelectPalette ( m_d -> m_hDC, m_hpalette, FALSE ) ;
		RealizePalette ( m_d -> m_hDC ) ;
	}
}

void myview::OnSize ( UINT type, int cx, int cy )
{
	glViewport ( 0, 0, cx, cy ) ;

	glMatrixMode ( GL_PROJECTION ) ;
	glLoadIdentity( ) ;
	glFrustum ( -1.0, 1.0, -1.0, 1.0, 2, 7.0 ) ;
	glMatrixMode ( GL_MODELVIEW ) ;
}

void myview::OnDraw ( CDC *p )
{
	drawcube( ) ;
}

void myview::drawcube( ) 
{
	glClearColor ( 0.0f, 0.0f, 0.0f, 0.0f ) ;
	glClear ( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT ) ;

	glPushMatrix( ) ;

	glTranslatef ( m_x_trans, m_y_trans, m_z_trans ) ;
	glScalef ( m_x_scale, m_y_scale, m_z_scale ) ;
	glRotatef ( m_degrees, m_x_rotat, m_y_rotat, m_z_rotat ) ;

    glBegin ( GL_POLYGON ) ;

		glColor3f ( 0.0f, 1.0f, 1.0f ) ; 
        glVertex3f ( -0.5f, 0.5f, 0.5f ) ;
        glVertex3f ( -0.5f, -0.5f, 0.5f ) ;
        glVertex3f ( 0.5f, -0.5f, 0.5f ) ;
        glVertex3f ( 0.5f, 0.5f, 0.5f ) ;

    glEnd( ) ;

    glBegin ( GL_POLYGON ) ;

		glColor3f ( 1.0f, 0.0f, 0.0f ) ; 
        glVertex3f ( 0.5f, 0.5f, 0.5f ) ;
        glVertex3f ( 0.5f, -0.5f, 0.5f ) ;
        glVertex3f ( 0.5f, -0.5f, -0.5f ) ;
        glVertex3f ( 0.5f, 0.5f, -0.5f ) ;

    glEnd( ) ;

    glBegin ( GL_POLYGON ) ;

		glColor3f ( 0.0f, 1.0f, 0.0f ) ; 
        glVertex3f ( 0.5f, 0.5f, -0.5f ) ;
        glVertex3f ( 0.5f, -0.5f, -0.5f ) ;
        glVertex3f ( -0.5f, -0.5f, -0.5f ) ;
        glVertex3f ( -0.5f, 0.5f, -0.5f ) ;

    glEnd( ) ;

    glBegin ( GL_POLYGON ) ;

		glColor3f ( 0.0f, 0.0f, 1.0f ) ; 
        glVertex3f ( -0.5f, 0.5f, -0.5f ) ;
        glVertex3f ( -0.5f, -0.5f, -0.5f ) ;
        glVertex3f ( -0.5f, -0.5f, 0.5f ) ;
        glVertex3f ( -0.5f, 0.5f, 0.5f ) ;

    glEnd( ) ;

    glBegin ( GL_POLYGON ) ;

		glColor3f ( 1.0f, 1.0f, 0.0f ) ; 
		glVertex3f ( -0.5f, -0.5f, 0.5f ) ;
        glVertex3f ( -0.5f, -0.5f, -0.5f ) ;
        glVertex3f ( 0.5f, -0.5f, -0.5f ) ;
        glVertex3f ( 0.5f, -0.5f, 0.5f ) ;

    glEnd( ) ;

    glBegin ( GL_POLYGON ) ;

		glColor3f ( 1.0f, 0.0f, 1.0f ) ; 
        glVertex3f ( -0.5f, 0.5f, -0.5f ) ;
        glVertex3f ( -0.5f, 0.5f, 0.5f ) ;
        glVertex3f ( 0.5f, 0.5f, 0.5f ) ;
        glVertex3f ( 0.5f, 0.5f, -0.5f ) ;

	glEnd( ) ;

	glPopMatrix( ) ;
	glFinish( ) ;
}

void myview::dialog ( int id )
{
	mydialog d ;

	if ( d.DoModal( ) == IDOK )
	{
		m_x_trans = d.x_t ;
		m_y_trans = d.y_t ;
		m_z_trans = d.z_t ;

		m_x_scale = d.x_s ;
		m_y_scale = d.y_s ;
		m_z_scale = d.z_s ;

		m_x_rotat = ( float ) d.x_r ;
		m_y_rotat = ( float ) d.y_r ;
		m_z_rotat = ( float ) d.z_r ;

		m_degrees = d.deg ;

		Invalidate( ) ;
	}
}

void myview::OnDestroy( )
{
	wglMakeCurrent ( NULL, NULL ) ;
	wglDeleteContext ( m_hGRC ) ;

	if ( m_hpalette )
		DeleteObject ( m_hpalette ) ;
}