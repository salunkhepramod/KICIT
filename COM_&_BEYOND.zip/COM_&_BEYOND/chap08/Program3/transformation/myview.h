#include <gl\gl.h>

class myview : public CView
{
	DECLARE_DYNCREATE ( myview ) ;

	private :

		HGLRC m_hGRC ;
		HPALETTE m_hpalette ;
		CClientDC *m_d ;

	public :

		GLfloat m_x_trans,  m_y_trans, m_z_trans ;
		GLfloat m_x_scale,  m_y_scale, m_z_scale ;
		GLfloat m_x_rotat,  m_y_rotat, m_z_rotat ;
		GLfloat m_degrees ;

	public :

		BOOL PreCreateWindow ( CREATESTRUCT& cs ) ;

		int OnCreate ( LPCREATESTRUCT l ) ;
		void OnSize ( UINT type, int cx, int cy ) ;
		void OnDraw ( CDC *p ) ;
		void drawcube( ) ;
		void setuplogicalpalette( ) ;
		void dialog ( int id ) ;
		void OnDestroy( ) ;

	DECLARE_MESSAGE_MAP( )
} ;