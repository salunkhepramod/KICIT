#include "glos.h"

#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glaux.h>

GLvoid initialize ( GLvoid ) ;
GLvoid CALLBACK draw_conesphere ( GLvoid ) ;
GLvoid CALLBACK resize ( GLsizei, GLsizei ) ;
GLvoid draw_lightsource ( GLvoid ) ;
void polarview ( GLdouble, GLdouble, GLdouble, GLdouble ) ;

GLfloat radius ;

void _CRTAPI1 main ( void )
{
    initialize( ) ;
    auxMainLoop ( draw_conesphere ) ;
}

GLvoid CALLBACK resize ( GLsizei width, GLsizei height )
{
    GLfloat aspect;

    glViewport ( 0, 0, width, height ) ; 
    aspect = ( GLfloat ) width / height ;
    glMatrixMode ( GL_PROJECTION ) ;
    glLoadIdentity( ) ;
    gluPerspective ( 45.0, aspect, 3.0, 7.0 ) ;
    glMatrixMode ( GL_MODELVIEW ) ;
}    

GLvoid initialize(GLvoid)
{
    GLfloat	maxobjectsize, aspect ;
    GLdouble near_plane, far_plane ;
    GLsizei	width, height ;

    GLfloat	ambient_light[ ] = { 0.7f, 0.7f, 0.7f, 1.0f } ;
    GLfloat	diffuse_light[ ] = { 0.8f, 0.8f, 0.8f, 1.0f } ;
    GLfloat	specular_light[ ] = { 1.0f, 1.0f, 1.0f, 1.0f } ;

    width = 1024.0 ;
    height = 768.0 ;

    auxInitPosition ( width / 4, height / 4, width / 2, height / 2 ) ;

    auxInitDisplayMode ( AUX_RGB | AUX_DEPTH | AUX_DOUBLE ) ;

    auxInitWindow ( "AUX Library Demo" ) ;

    auxIdleFunc ( draw_conesphere ) ;

    auxReshapeFunc ( resize ) ;

    glClearColor ( 0.0, 0.0, 0.0, 1.0 ) ;
    glClearDepth ( 1.0 ) ;

    glEnable ( GL_DEPTH_TEST ) ;
    glEnable ( GL_LIGHTING ) ;
    
    glLightfv ( GL_LIGHT0, GL_AMBIENT, ambient_light ) ;
    glLightfv ( GL_LIGHT0, GL_DIFFUSE, diffuse_light ) ;
    glLightfv ( GL_LIGHT0, GL_SPECULAR, specular_light ) ;
    glLightModelf ( GL_LIGHT_MODEL_TWO_SIDE, 1.0 ) ;

    glEnable ( GL_LIGHT0 ) ;

    glMatrixMode ( GL_PROJECTION ) ;
    aspect = ( GLfloat ) width / height ;
    gluPerspective ( 45.0, aspect, 3.0, 7.0 ) ;
    glMatrixMode ( GL_MODELVIEW ) ;

    near_plane = 3.0 ;
    far_plane = 7.0 ;
    maxobjectsize = 3.0 ;
    radius = near_plane + maxobjectsize / 2.0 ;
}

void polarview ( GLdouble radius, GLdouble x, GLdouble y, GLdouble z )
{
    glTranslated ( 0.0, 0.0, -radius ) ;
    glRotated ( x, 1.0, 0.0, 0.0 ) ;
    glRotated ( y, 0.0, 1.0, 0.0 ) ;
    glRotated ( z, 0.0, 0.0, 1.0 ) ;	 
}

GLvoid CALLBACK draw_conesphere ( GLvoid )
{
    static GLfloat ambient_cone[ ] = { 0.3f, 0.1f, 0.1f, 1.0f } ;
    static GLfloat diffuse_cone[ ] = { 1.0f, 0.0f, 0.0f, 1.0f } ;
    static GLfloat specular_cone[ ] = { 1.0f, 1.0f, 1.0f, 1.0f } ;

    static GLfloat ambient_sphere[ ] = { 0.3f, 0.3f, 0.1f, 1.0f } ;
    static GLfloat diffuse_sphere[ ] = { 1.0f, 1.0f, 0.0f, 1.0f } ;
    static GLfloat specular_sphere[ ] = { 1.0f, 1.0f, 0.0f, 1.0f } ;

    static GLfloat lightPosition0[ ] = { 1.0f, 1.0f, 1.0f, 1.0f } ;
    static GLfloat x = 0.0f, y = 0.0f, z = 0.0f ;

    glClear ( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT ) ;

	glPushMatrix( ) ;

	polarview ( radius, 0.0, 0.0, 0.0 ) ;
	glTranslatef ( 1.0, 1.0, 1.0 ) ;
	glLightfv ( GL_LIGHT0, GL_POSITION, lightPosition0 ) ;
	draw_lightsource( ) ;

	glPopMatrix( ) ;

    glPushMatrix( ) ;

	x += 6.0 ;
	y += 4.0 ;
	z += 2.5 ;

	polarview ( radius, x, y, z ) ;

	glPushAttrib ( GL_LIGHTING_BIT ) ;

	glMaterialfv ( GL_FRONT_AND_BACK, GL_AMBIENT, ambient_cone ) ;
	glMaterialfv ( GL_FRONT_AND_BACK, GL_DIFFUSE, diffuse_cone ) ;
	glMaterialfv ( GL_FRONT_AND_BACK, GL_SPECULAR, specular_cone ) ;
	glMaterialf ( GL_FRONT, GL_SHININESS, 100.0 ) ;

	auxSolidCone ( 0.6, 0.6 ) ;

	glMaterialfv ( GL_FRONT, GL_AMBIENT, ambient_sphere ) ;
	glMaterialfv ( GL_FRONT, GL_DIFFUSE, diffuse_sphere ) ;
	glMaterialfv ( GL_FRONT, GL_SPECULAR, specular_sphere ) ;
	glMaterialf ( GL_FRONT, GL_SHININESS, 50.0 ) ;

	auxSolidSphere ( 0.3 ) ;

	glPopAttrib( ) ;

	glPopMatrix( ) ;

	auxSwapBuffers( ) ;
}

GLvoid draw_lightsource ( GLvoid )
{
    glPushAttrib ( GL_LIGHTING_BIT ) ;
   	glDisable ( GL_LIGHTING ) ;
   	glColor3f ( 1.0, 1.0, 1.0 ) ;
   	auxSolidSphere ( 0.1 ) ;
    glPopAttrib( ) ;
}
