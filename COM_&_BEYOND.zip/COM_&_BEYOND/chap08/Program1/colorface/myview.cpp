#include <afxwin.h>
#include "myview.h"

#include "resource.h"

IMPLEMENT_DYNCREATE ( myview, CView ) 

BEGIN_MESSAGE_MAP ( myview, CView )

	ON_WM_CREATE( )
	ON_WM_SIZE( )
	ON_WM_DESTROY( ) 

END_MESSAGE_MAP( )

BOOL myview::PreCreateWindow ( CREATESTRUCT& cs )
{
	cs.style |= WS_CLIPCHILDREN | WS_CLIPSIBLINGS ;
	return CView::PreCreateWindow ( cs ) ;
}

int myview::OnCreate ( LPCREATESTRUCT l )
{
	CView::OnCreate ( l ) ;

	PIXELFORMATDESCRIPTOR pfd =
	{
		sizeof ( PIXELFORMATDESCRIPTOR ), 
		1,
		PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL,
		PFD_TYPE_RGBA,
		24,
		0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 
		32,
		0, 0,
		PFD_MAIN_PLANE,
		0,
		0, 0, 0
	} ;

	m_d = new CClientDC ( this ) ;

	int index = ChoosePixelFormat ( m_d -> m_hDC, &pfd ) ;
	SetPixelFormat ( m_d -> m_hDC, index, &pfd ) ;

	DescribePixelFormat ( m_d -> m_hDC, index, sizeof ( pfd ), &pfd ) ;

	if ( pfd.dwFlags & PFD_NEED_PALETTE )
		setuplogicalpalette( ) ;

	m_hGRC = wglCreateContext ( m_d -> m_hDC ) ;
	wglMakeCurrent ( m_d -> m_hDC, m_hGRC ) ;

	glClearDepth ( 1.0f ) ;
	glEnable ( GL_DEPTH_TEST ) ;

	return 1 ;
}

void myview::setuplogicalpalette( )
{
    struct
    {
        WORD ver ;
        WORD num ;
        PALETTEENTRY entries[256];
    } logicalpalette = { 0x300, 256 };

    BYTE reds[ ] = { 0, 20, 40, 120, 140, 180, 220, 255 } ;
    BYTE greens[ ] = { 0, 20, 40, 120, 140, 180, 220, 255 } ;
    BYTE blues[ ] = { 0, 20, 40, 120, 140, 180, 220, 255 } ;

    for ( int cn = 0 ; cn < 256 ; ++cn )
    {	
        logicalpalette.entries[cn].peRed = reds[cn & 0x07] ;
        logicalpalette.entries[cn].peGreen = greens[( cn >> 0x03 ) & 0x07] ;
        logicalpalette.entries[cn].peBlue = blues[( cn >> 0x06 ) & 0x03] ;
        logicalpalette.entries[cn].peFlags = 0 ;
    }

    m_hpalette = CreatePalette ( ( LOGPALETTE* ) &logicalpalette ) ;

	if ( m_hpalette )
	{
		SelectPalette ( m_d -> m_hDC, m_hpalette, FALSE ) ;
		RealizePalette ( m_d -> m_hDC ) ;
	}
}

void myview::OnSize ( UINT type, int cx, int cy )
{
	glViewport ( 0, 0, cx, cy ) ;

	glMatrixMode ( GL_PROJECTION ) ;
	glLoadIdentity( ) ;
	glFrustum ( -1.0, 1.0, -1.0, 1.0, 2, 7.0 ) ;

	glMatrixMode ( GL_MODELVIEW ) ;
	glLoadIdentity( ) ;
}

void myview::OnDraw ( CDC *p )
{
	drawcube( ) ;
}

void myview::drawcube( ) 
{
	glClearColor ( 0.0f, 0.0f, 0.0f, 0.0f ) ;
	glClear ( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT ) ;

	glPushMatrix( ) ;

	glTranslatef ( 0, 0, -3.5 ) ;
	glRotatef ( 20.0, 1.0f, 0.0f, 0.0f ) ;
	glRotatef ( 30.0, 0.0f, 1.0f, 0.0f ) ;
	glRotatef ( 10.0, 0.0f, 0.0f, 1.0f ) ;

    glBegin ( GL_POLYGON ) ;

		glColor3f ( 0.0f, 1.0f, 1.0f ) ; 
        glVertex3f ( -0.5f, 0.5f, 0.5f ) ;
        glVertex3f ( -0.5f, -0.5f, 0.5f ) ;
        glVertex3f ( 0.5f, -0.5f, 0.5f ) ;
        glVertex3f ( 0.5f, 0.5f, 0.5f ) ;

    glEnd( ) ;

    glBegin ( GL_POLYGON ) ;

		glColor3f ( 1.0f, 0.0f, 0.0f ) ; 
        glVertex3f ( 0.5f, 0.5f, 0.5f ) ;
        glVertex3f ( 0.5f, -0.5f, 0.5f ) ;
        glVertex3f ( 0.5f, -0.5f, -0.5f ) ;
        glVertex3f ( 0.5f, 0.5f, -0.5f ) ;

    glEnd( ) ;

    glBegin ( GL_POLYGON ) ;

		glColor3f ( 0.0f, 1.0f, 0.0f ) ; 
        glVertex3f ( 0.5f, 0.5f, -0.5f ) ;
        glVertex3f ( 0.5f, -0.5f, -0.5f ) ;
        glVertex3f ( -0.5f, -0.5f, -0.5f ) ;
        glVertex3f ( -0.5f, 0.5f, -0.5f ) ;

    glEnd( ) ;

    glBegin ( GL_POLYGON ) ;

		glColor3f ( 0.0f, 0.0f, 1.0f ) ; 
        glVertex3f ( -0.5f, 0.5f, -0.5f ) ;
        glVertex3f ( -0.5f, -0.5f, -0.5f ) ;
        glVertex3f ( -0.5f, -0.5f, 0.5f ) ;
        glVertex3f ( -0.5f, 0.5f, 0.5f ) ;

    glEnd( ) ;

    glBegin ( GL_POLYGON ) ;

		glColor3f ( 1.0f, 1.0f, 0.0f ) ; 
		glVertex3f ( -0.5f, -0.5f, 0.5f ) ;
        glVertex3f ( -0.5f, -0.5f, -0.5f ) ;
        glVertex3f ( 0.5f, -0.5f, -0.5f ) ;
        glVertex3f ( 0.5f, -0.5f, 0.5f ) ;

    glEnd( ) ;

    glBegin ( GL_POLYGON ) ;

		glColor3f ( 1.0f, 0.0f, 1.0f ) ; 
        glVertex3f ( -0.5f, 0.5f, -0.5f ) ;
        glVertex3f ( -0.5f, 0.5f, 0.5f ) ;
        glVertex3f ( 0.5f, 0.5f, 0.5f ) ;
        glVertex3f ( 0.5f, 0.5f, -0.5f ) ;

	glEnd( ) ;

	glPopMatrix( ) ;

	glFinish( ) ;
}

void myview::OnDestroy( )
{
	wglDeleteContext ( m_hGRC ) ;

	if ( m_hpalette )
		DeleteObject ( m_hpalette ) ;

	delete m_d ;
}