#include <afxwin.h>
#include "disk.h"

#define VWIN32_DIOC_DOS_IOCTL		1
#define VWIN32_DIOC_DOS_INT25		2
#define VWIN32_DIOC_DOS_DRIVEINFO	6

#define FSINFOSIG 0x61417272L

disk::disk( )
{
	hdev = CreateFile ( "\\\\.\\VWIN32", 0, 0, NULL, 0, FILE_FLAG_DELETE_ON_CLOSE, NULL ) ;
}

void disk::getmediaid ( int drive_1, media *m )
{
	DIOC_REGISTERS r = {0};
	DWORD cb ;
	
	r.eax = 0x440d ;    
	r.ebx = drive_1 ;
	r.ecx = 0x0866 ;
	r.edx = ( DWORD ) m ;
	r.flags = 1 ;

	DeviceIoControl ( hdev, VWIN32_DIOC_DOS_IOCTL,
						&r, sizeof ( r ), &r, sizeof ( r ), &cb, 0 ) ;
}

void disk::readabsolutesectors (  int drive_0, int startsect,
		 						  int numsect, void * buffer )
{
	DIOC_REGISTERS r ;
	DISKIO di ;
	DWORD cb;

	r.eax = drive_0 ;    
	r.ebx = ( DWORD ) &di ;
	r.ecx = 0xffff ;
	r.flags = 1 ;
	di.startsector = startsect ;
	di.sectorsnum = numsect ;
	di.buff = ( DWORD ) buffer ;
	
	DeviceIoControl ( hdev, VWIN32_DIOC_DOS_INT25,
						&r, sizeof ( r ), &r, sizeof ( r ), &cb, 0 ) ;
}

void disk::readabsolutesectors32 ( int drive_1, int startsect,
								   int numsect, void *buffer )
{
	DIOC_REGISTERS r ;
	DISKIO di ;
	DWORD cb ;

	r.eax = 0x7305 ;  
	r.ebx = ( DWORD ) &di ;
	r.ecx = 0xffff ;  
	r.edx = drive_1 ;  
	r.esi = 0 ;       
	r.flags = 0 ;       
	di.startsector = startsect ;
	di.sectorsnum = numsect ;
	di.buff = ( DWORD ) buffer ;

	DeviceIoControl( hdev, VWIN32_DIOC_DOS_DRIVEINFO,
					  &r, sizeof( r ), &r, sizeof( r ), &cb, 0 ); 
}

CString disk::getfat_12 ( BYTE *pfat, int k ) 
{
	WORD value ;
	CString str ;
	WORD *fatentry ;

	int i = k * 3 / 2 ;

	fatentry =  ( WORD* ) ( pfat + i ) ;
	
	if ( ( k % 2 ) == 0 )
		value = ( *fatentry & 0x0fff ) ;
	else
		value = ( *fatentry >> 4 ) ;

	str.Format ( "%03x", value ) ;

	return str ;
}


