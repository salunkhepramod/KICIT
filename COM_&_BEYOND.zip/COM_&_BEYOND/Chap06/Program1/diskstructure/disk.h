struct DIOC_REGISTERS 
{
	DWORD ebx ;
	DWORD edx ;
	DWORD ecx ;
	DWORD eax ;
	DWORD edi ;
	DWORD esi ;
	DWORD flags ;
} ;

#pragma pack ( 1 )

struct media
{
	WORD infolevel ;
	DWORD serialnumber ;
	char vollabel[11] ;
	char filesystype[8] ;
} ;

struct DISKIO 
{
    DWORD startsector ;    
    WORD  sectorsnum ;     
    DWORD buff ;         
} ;

struct boot
{
	BYTE jump[3] ;
	char OEMname[8] ;
	WORD bps ;
	BYTE spc ;
	WORD reservedsec ;
	BYTE fatcopies ;
	WORD maxdirentries ;
	WORD totalsec ;
	BYTE mediadesc ;
	WORD secperfat ;
	WORD secpertrack ;
	WORD noofsides ;
	DWORD hidden ;
	DWORD hugesec ;
    BYTE drivenumber ;
    BYTE reserved ;
    BYTE bootsignature ;
    DWORD volumeid ;
    char volumelabel[11] ;
    char filesystype[8] ;
	BYTE unused[450] ;
} ;

struct boot32 
{
    BYTE jump[3] ;
	char bsOemName[8] ;
    WORD BytesPerSector ;
    BYTE SectorsPerCluster ;
    WORD ReservedSectors ;
    BYTE NumberOfFATs ;
    WORD RootEntries ;
    WORD TotalSectors ;
    BYTE MediaDescriptor ;
    WORD SectorsPerFAT ;
    WORD SectorsPerTrack ;
    WORD Heads ;
    WORD HiddenSectors ;
    WORD HiddenSectorsHigh ;
    WORD BigTotalSectors ;
    WORD BigTotalSectorsHigh ;
    WORD BigSectorsPerFat ;
    WORD BigSectorsPerFatHi ;
    WORD ExtFlags ;
    WORD FS_Version ;
    WORD RootDirStrtClus ;
    WORD RootDirStrtClusHi ;
    WORD FSInfoSec ;
    WORD BkUpBootSec ;
    WORD Reserved[6] ;
    BYTE bsDriveNumber ;		  
    BYTE bsReserved ;
    BYTE bsBootSignature ;
    DWORD bsVolumeID ;	
    char bsVolumeLabel[11] ;
    char bsFileSysType[8] ;
	BYTE unused [422] ;
} ;

struct 	bigfatbootfsinfo
{
	DWORD	FSInf_Sig ;
	DWORD	FSInf_free_clus_cnt ;
	DWORD	FSInf_next_free_clus ;
	DWORD	FSInf_resvd[3] ;
} ;

struct directory
{
	char filename[8] ;
	char extension[3] ;
	BYTE att ;
	BYTE reserved ;
	BYTE second ;
	WORD createtime ;
	WORD createdate ;
	WORD lastdate ;
	WORD fat32handle ;
	WORD modifytime ;
	WORD modifydate ;
	WORD startclus ;
	DWORD size ;
} ;

struct longdirectory 
{
    char    leSequence ;			// sequence byte:1,2,3,..., last entry is or'ed with 40h
    wchar_t leName[5] ;			// Unicode characters of name
    BYTE    leAttributes ;		// Attributes: 0fh
    BYTE    leType ;				  // Long Entry Type: 0
    BYTE    leChksum ;			  // Checksum for matching short name alias
    wchar_t leName2[6] ;			// More Unicode characters of name
    WORD    leZero ;				  // reserved
    wchar_t leName3[2] ;			// More Unicode characters of name
} ;

#pragma pack( )

class disk 
{
	private :

		HANDLE hdev ;
		CString bootstr ;

	public :

		disk( ) ;
		void getmediaid ( int drive_1, media *m ) ;
		void readabsolutesectors (  int drive_0, int startsect, int numsect, void * buffer ) ;
		void readabsolutesectors32 ( int drive_1, int startsect, int numsect, void *buffer ) ;
		CString getfat_12 ( BYTE* pfat, int k ) ;
} ;
