class myapp : public CWinApp
{
	public :

		virtual BOOL InitInstance( ) ;

	DECLARE_MESSAGE_MAP( )
} ;
