#include <afxwin.h>
#include <afxext.h>
#include "disk.h"
#include "mydoc.h"
#include "myview.h"

#include "resource.h"

#define VWIN32_DIOC_DOS_IOCTL		1
#define VWIN32_DIOC_DOS_INT25		2
#define VWIN32_DIOC_DOS_DRIVEINFO	6

#define		FSINFOSIG	0x61417272L

IMPLEMENT_DYNCREATE ( myview, CScrollView )

BEGIN_MESSAGE_MAP ( myview, CScrollView ) 

	ON_COMMAND ( ID_FILE_PRINT, CScrollView::OnFilePrint ) 
	ON_COMMAND ( ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview ) 

	ON_COMMAND_RANGE ( ID_DRIVE_A, ID_DRIVE_C, drive ) 

END_MESSAGE_MAP( )

void myview::OnInitialUpdate( )
{
	CScrollView::OnInitialUpdate( ) ;

	pdoc = ( mydoc * ) GetDocument( ) ;
	pds = pdoc -> getdiskobject( ) ;

	CClientDC d ( this ) ;
	d.SetMapMode ( MM_LOENGLISH ) ;

	int h = - ( ( d.GetDeviceCaps ( LOGPIXELSY ) * 10 ) / 72 ) ;
	
	if ( scr_font.m_hObject != NULL )
		scr_font.DeleteObject( ) ;

	scr_font.CreateFont ( h, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Courier New" ) ;

	CFont *prevfont = d.SelectObject ( &scr_font ) ;

	TEXTMETRIC tm ;
	d.GetTextMetrics ( &tm) ;
	scr_ht = tm.tmHeight + tm.tmExternalLeading ;

	d.SelectObject ( prevfont ) ;

	setview( ) ;
} 

void myview::setview( )
{
	SetScrollSizes ( MM_LOENGLISH, CSize ( 827, pdoc -> lines.GetCount( ) * scr_ht + 5 * scr_ht ) ) ;
}

void myview::OnDraw ( CDC *p )
{
	CFont* prevfont = p -> SelectObject ( &scr_font ) ;

	int count = pdoc -> lines.GetCount( ) ;
	POSITION pos = pdoc -> lines.GetHeadPosition( ) ;
	for ( int i = 0, y = 0 ; i < count ; i++ )
	{
		str = pdoc -> lines.GetNext ( pos ) ;
		p -> TextOut ( 5, y, str, str.GetLength( ) ) ;
		y -= scr_ht ;
	}
	str = "" ;

	p -> SelectObject ( prevfont ) ;
}

void myview::drive ( int id )
{
	switch ( id )
	{
		case ID_DRIVE_A :
			
			pdoc -> lines.RemoveAll( ) ;

			media_id_info ( 1 ) ; // reads and displays media ID information
			boot_info ( 0 ) ;  // reads and displays FAT 12 boot sector information

			fat_info( ) ; // reads and displays File Allocation Table 

			display_dir_info ( 0, 0 ) ; // reads and displays directory structure 
									//0 - !FAT32

			setview( ) ;
 			break ;

		case ID_DRIVE_C :

			pdoc -> lines.RemoveAll( ) ;

			media_id_info ( 3 ) ; // reads and displays media ID information

			if ( strncmp ( "FAT32", filetypestr, 5 ) )
			{
				boot_info ( 2 ) ; // reads and displays FAT 12/16 boot sector information
				fat_info( ) ; // reads and displays File Allocation Table 

				display_dir_info ( 0, 2 ) ; //reads and displays directory structure
										 //0 - !FAT32
			}
			else
			{
				boot_info_32 ( 3 ) ; // reads and displays FAT 32 boot sector information
				fat_info( ) ;
				display_dir_info ( 1, 2 ) ; //reads and displays directory structure
										 // 1 - FAT32
			}

			setview( ) ;

			break ;
	}

	Invalidate( ) ;
}

void myview::media_id_info  ( int drive_1 ) // one-based drive
{
	pds -> getmediaid ( drive_1, &m ) ;
	display_media_id( ) ;
}

void myview::display_media_id( ) 
{
	str = "-------------------------------" ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str = "Media ID" ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str = "-------------------------------" ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Serial Number = %u", m.serialnumber ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	CString volstr ;
	for ( int i = 0 ; i <= 10 ; i++ )
		volstr += m.vollabel[i] ;
	
	str = "Volume Label = " + volstr ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	filetypestr = "" ;
	for ( i = 0 ; i <= 7 ; i++ )
		filetypestr += m.filesystype[i] ; // private - filetypestr
	
	str = "File System Type = " + filetypestr ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str = "-------------------------------" ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;
}

void myview::boot_info ( int drive_0 )
{
	pds -> readabsolutesectors ( drive_0, 0, 1, &bs ) ; // zero-based drive
	display_boot_info( ) ;
}

void myview::display_boot_info( )
{
	CString totalhiddenstr ;
	CString totalsectorsstr ;

	str = filetypestr + " BOOT Sector" ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str = "-------------------------------" ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Jump Instruction : %X%X%X", ( BYTE ) bs.jump[0], ( BYTE ) bs.jump[1], ( BYTE ) bs.jump[2] ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "OEM Name : %s", bs.OEMname ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Bytes Per Sector : %u",bs.bps ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Sectors Per Cluster : %u",bs.spc ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Number of Sectors in Reserved Area : %u", bs.reservedsec ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Number of Copies of FAT : %u", bs.fatcopies ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Maximum Directory Entries : %u", bs.maxdirentries ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;
	
	if ( bs.totalsec == 0 )
	{
		CString hugesecstr ;
		hugesecstr.Format ( "Huge Sectors = %u", bs.hugesec ) ;
		str = hugesecstr ;
		pdoc -> lines.AddTail ( str ) ;
		str = "" ;
	}
	else
	{
		str.Format ( "Total Number of Sectors : %u", bs.totalsec ) ;
		pdoc -> lines.AddTail ( str ) ;
		str = "" ;
	}
	str.Format ( "Media Descriptor : %X", bs.mediadesc ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Sectors Per FAT : %u", bs.secperfat ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Sectors Per Track : %u", bs.secpertrack ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Number of Sides : %u", bs.noofsides ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Number of Hidden Sectors: %u", bs.hidden ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Drive Number: %d", bs.drivenumber ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Boot Signature: %u", bs.bootsignature ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Volume ID: %u", bs.volumeid ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	CString volstr ;
	for ( int i = 0 ; i <= 10 ; i++ )
		volstr += m.vollabel[i] ;
	
	str = "Volume Label = " + volstr ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str = "File System Type = " + filetypestr ; // private - filetypestr
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str = "-------------------------------" ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;
}

void myview::boot_info_32 ( int drive_1 )
{
	pds -> readabsolutesectors32 ( drive_1, 0, 1, &bs32 ) ; // one-based drive
	display_boot_info_32( ) ;
}

void myview::display_boot_info_32( )
{
	str = filetypestr + "Boot Sector" ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str = "-------------------------------" ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Jump Instruction : %X%X%X", ( BYTE ) bs32.jump[0], ( BYTE ) bs32.jump[1], ( BYTE ) bs32.jump[2] ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "OEM Name : %s", bs32.bsOemName ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Bytes Per Sector : %u", bs32.BytesPerSector ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Sectors Per Cluster : %u", bs32.SectorsPerCluster ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Number of Sectors in Reserved Area : %d", bs32.ReservedSectors ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;
	
	str.Format ( "Number of Copies of FAT : %d", bs32.NumberOfFATs ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Maximum Directory Entries : %d", bs32.RootEntries ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	if ( bs32.TotalSectors == 0 )
	{
		CString hugesecstr ;
		hugesecstr.Format ( "Huge Sectors = %u", ( bs32.BigTotalSectorsHigh << 16) + bs32.BigTotalSectors ) ;
		str = hugesecstr ;
		pdoc -> lines.AddTail ( str ) ;
		str = "" ;
	}
	else
	{
		str.Format ( "Total Number of Sectors : %d", bs32.TotalSectors ) ;
		pdoc -> lines.AddTail ( str ) ;
		str = "" ;
	}

	str.Format ( "Media Descriptor : %X", bs32.MediaDescriptor ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	if ( bs32.SectorsPerFAT == 0 )
	{
		str.Format ( "Big Sectors Per FAT : %d", (bs32.BigSectorsPerFatHi << 16) + bs32.BigSectorsPerFat ) ;
		pdoc -> lines.AddTail ( str ) ;
		str = "" ;
	}
	else
	{
		str.Format ( "Sectors Per FAT : %d", bs32.SectorsPerFAT ) ;
		pdoc -> lines.AddTail ( str ) ;
		str = "" ;
	}

	str.Format ( "Sectors Per Track : %d", bs32.SectorsPerTrack ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Number of Sides : %d", bs32.Heads ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	DWORD totalhidden = ( bs32.HiddenSectorsHigh << 16 ) + bs32.HiddenSectors ;
	str.Format ( "Number of Hidden Sectors: %d", totalhidden ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Extended flags : %d", bs32.ExtFlags ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "File System Version : %d", bs32.FS_Version ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Root Dir Start Cluster : %d", ( bs32.RootDirStrtClusHi << 16 ) + bs32.RootDirStrtClus ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "File System Info Sector : %d", bs32.FSInfoSec ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Backup Boot Sector : %d", bs32.BkUpBootSec ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "BIOS Drive Number: %d", bs32.bsDriveNumber ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Boot Signature: %u", bs32.bsBootSignature ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Volume ID: %u", bs32.bsVolumeID ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	CString volstr ;
	for ( int i = 0 ; i <= 10 ; i++ )
		volstr += m.vollabel[i] ;

	str = "Volume Label = " + volstr ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str = "File System Type = " + filetypestr ; // private - filetypestr
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	if ( bs32.FSInfoSec != 0xffff )
		file_sys_info( ) ;

	str = "-------------------------------" ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;
}

void myview::file_sys_info( ) 
{
	bigfatbootfsinfo *pfsinfo = NULL ;
	BYTE *pbuf = new BYTE[512] ;

	pds -> readabsolutesectors32 ( 3, bs32.FSInfoSec, 1, pbuf ) ;

	BYTE *pend = pbuf ;

	while ( TRUE )
	{
		DWORD *pdw = ( DWORD* ) pbuf ;
		if ( *pdw == FSINFOSIG )
		{
			pfsinfo = ( bigfatbootfsinfo * ) pdw ;
			break ;
		}
		pbuf += 4 ;
	}

	str.Format ( "Signature : %08lx", pfsinfo -> FSInf_Sig ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Free Clusters : %u", pfsinfo -> FSInf_free_clus_cnt ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str.Format ( "Next Free Cluster : %u", pfsinfo -> FSInf_next_free_clus ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;
}

void myview::fat_info( )
{
	DWORD first_fat, second_fat ;
	
	if ( strncmp ( "FAT32", filetypestr, 5 ) == 0 )
	{
		first_fat = bs32.ReservedSectors ;
		second_fat = bs32.ReservedSectors + ( bs32.BigSectorsPerFatHi << 16 ) + bs32.BigSectorsPerFat ;
	}
	else
	{
		first_fat = bs.reservedsec ;
		second_fat = bs.reservedsec  + bs.secperfat ;
	}
	
	str = filetypestr +  "Fat Information" ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str = "-------------------------------" ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str = "First FAT Information" ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;
	
	read_fat_info ( first_fat ) ;

	str = "" ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	str = "Second FAT Information" ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;
	
	read_fat_info ( second_fat ) ;

	str = "-------------------------------" ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;
}

void myview::read_fat_info ( DWORD fat_num )
{
	int j, i ;

	CString fattempstr, fatstr ;
	BYTE *p ;

	if ( strncmp ( "FAT12", filetypestr, 5 ) == 0 )
	{
		p = new BYTE[bs.bps] ;
		
		pds -> readabsolutesectors ( 0, fat_num, 1, p ) ;
		
		int k ;
		for ( k = 2 ; k < 18 ; k++ )
		{
			fattempstr = pds -> getfat_12 ( p, k ) ;
			str += "   " + fattempstr ;

			if ( k % 9 == 0 )
			{
				pdoc -> lines.AddTail ( str ) ;
				str = "" ;
			}
		}
		pdoc -> lines.AddTail ( str ) ;
		str = "" ;
	}

	if ( strncmp ( "FAT16", filetypestr, 5 ) == 0 )
	{
		p = new BYTE[bs.bps] ;
		pds -> readabsolutesectors ( 2, fat_num, 1, p ) ;

		WORD* pfat = ( WORD * ) p ;

		for ( j = 0 ; j < 2 ; j++ ) 
		{
			str.Format ( "%d   ", j * 8 ) ;
			for ( i = 0 ; i < 8 ; i++ )
			{
				fattempstr.Format ( "%04x   ", *pfat++ ) ;
				str += fattempstr ; 
			}

			pdoc -> lines.AddTail ( str ) ;
			str = "" ;
		}
	}

	if ( strncmp ( "FAT32", filetypestr, 5 ) == 0 )
	{
		p = new BYTE[bs32.BytesPerSector] ;

		pds -> readabsolutesectors32 ( 3, fat_num, 1, p ) ; 
		
		DWORD* pfat32 = (DWORD*) p ;
		
		for ( j = 0 ; j < 8 ; j++ ) 
		{
			str.Format ( "%2d   ", j * 8 ) ;
			for ( i = 0 ; i < 8 ; i++ )
			{
				fattempstr.Format ( "%07x   ", ( *pfat32++ ) & 0xfffffff ) ;
				str += fattempstr ; 
			}

			pdoc -> lines.AddTail ( str ) ;
			str = "" ;
		}
	}
}

void myview::display_dir_info ( int isFAT32, int drv )
{
	BYTE * pbuf ;
	int bufsize ;

	if ( isFAT32 == 0 )
	{
		unsigned short sect_cnt = ( ( 32 * bs.maxdirentries ) + bs.bps - 1 ) / bs.bps ;
		DWORD dirsec = ( bs.reservedsec + bs.secperfat * 2 ) ;
	
		bufsize = sect_cnt * bs.bps ;
		pbuf = new BYTE[bufsize] ;

		pds -> readabsolutesectors ( drv, dirsec, sect_cnt, pbuf ) ;
	}
	else
	{
		DWORD sector_size = bs32.BytesPerSector ;
		DWORD sectors_per_fat = ( bs32.BigSectorsPerFatHi << 16 ) + bs32.BigSectorsPerFat ;
		DWORD sectors_per_clus = bs32.SectorsPerCluster ;
		DWORD rootdirstartclus = ( bs32.RootDirStrtClusHi << 16 ) + bs32.RootDirStrtClus ;
		rootdirstartclus -= 2 ; // the first two clusters in the FAT are reserved
		DWORD startsector = bs32.ReservedSectors + sectors_per_fat * 2 ;
		DWORD rootdirstartsector = startsector + rootdirstartclus * bs32.SectorsPerCluster ;

		bufsize = sectors_per_clus * sector_size ;
		pbuf = new BYTE[bufsize] ;

		pds -> readabsolutesectors32 ( drv + 1, rootdirstartsector, sectors_per_clus, pbuf ) ;
	}
	
	CString at, dirstr ;
	CString datestr, timestr, lastdatestr ;

	str.Format ( " %-16s %-9s %-19s %-10s %-9s %-6s %-5s", "Name", "Attrib", "Creation Date/Time", "Last Date", "St.Clust.","Size", "Chksum" ) ;
	pdoc -> lines.AddTail ( str ) ;
	str = "" ;

	BYTE *epbuf, *spbuf ;

	spbuf = pbuf ;
	epbuf = spbuf + bufsize ;

	while ( ( spbuf < epbuf ) && *spbuf )
	{
		if ( *spbuf == 0xe5 )
			spbuf += sizeof ( directory ) ;
		else 
		{
			if ( * ( spbuf + 0x0b ) == 0xf && * ( spbuf + 0x0c ) == 0 ) 
			{
				int c ;
				wchar_t szName[14] ;
				longdirectory *pl = ( longdirectory * ) spbuf ;

				if ( pl -> leSequence & 0x40 )
					dirstr.Format ( "%c ", pl -> leSequence ) ;
				else
					dirstr.Format ( "%d ", pl -> leSequence ) ;
				
				memset( szName, 0, sizeof( szName ) );

				swprintf ( szName, L"%.5s", pl->leName ) ;
				
				if ( pl -> leName2[0] != 0 && pl -> leName2[0] != 0xffff )
					swprintf ( szName, L"%s%.6s", szName, pl -> leName2 ) ;
				
				if ( pl -> leName3[0] != 0 && pl -> leName3[0] != 0xffff )
					swprintf( szName, L"%s%.2s", szName, pl->leName3 );

				c = wcslen( szName );
				while ( c < 13 ) 
				{
					szName[c] = L' ' ;
					c++ ;
				}
				wprintf( L"%s ", szName ) ;
				dirstr += szName ;
				
				at = ( pl -> leAttributes & 0x20 ) ? "a " : "- " ;
				at += ( pl -> leAttributes & 0x10 ) ? "d " : "- " ;
				at += ( pl -> leAttributes & 0x08 ) ? "v " : "- " ;
				at += ( pl -> leAttributes & 0x04 ) ? "s " : "- " ;
				at += ( pl -> leAttributes & 0x02 ) ? "h " : "- " ;
				at += ( pl -> leAttributes & 0x01 ) ? "r " : "- " ;

				str = dirstr ;

				dirstr.Format ( "%02x", pl -> leChksum ) ;
				spbuf += sizeof ( directory ) ;

				CString temp ;
				temp.Format ( "%65s", " " ) ;
				str += temp + dirstr ;
			}
			else 
			{
				if ( * ( spbuf + 0x0b ) == 0xf && *( spbuf + 0x0c ) != 0 )
				{
					str = "! " ;
					for( int i = 0 ; i < 16 ; i++ ) 
					{
						dirstr.Format ( "%02x ", *spbuf++ ) ;
						str += dirstr + "  " ;
					}

					pdoc -> lines.AddTail ( str ) ;
					str = "" ;

					for( i = 0 ; i < 6 ; i++ ) 
					{
						dirstr.Format ( "%02x ",*spbuf++ );
						str += "  " + dirstr ;
					}

					pdoc -> lines.AddTail ( str ) ;
					str = "" ;
				
					spbuf += sizeof( directory );
				}

				// "Short" directory entry
				else 
				{
					directory *pd = ( directory * ) spbuf ;

					str.Format ( " %.8s %.3s ", pd -> filename, pd -> extension ) ;
					
					at = ( pd -> att & 0x20 ) ? "a " : "- " ;
					at += ( pd -> att & 0x10 ) ? "d " : "- " ;
					at += ( pd -> att & 0x08 ) ? "v " : "- " ;
					at += ( pd -> att & 0x04 ) ? "s " : "- " ;
					at += ( pd -> att & 0x02 ) ? "h " : "- " ;
					at += ( pd -> att & 0x01 ) ? "r " : "- " ;

					str += "  " + at ;
					//Date Of Creation

					if ( pd -> createdate != 0 )
					{
						short int dd =  ( pd -> createdate & 0x001f ) ;
						short int mm = ( ( pd -> createdate & 0x01e0 ) >> 5) ;
						short int yy = ( ( pd -> createdate & 0xfe00 ) >> 9 ) + 80;

						datestr.Format ( "%2d-%2d-%2d", dd, mm, yy ) ;
					}
					else
						datestr = "xx-xx-xx" ;

					str += " " + datestr ;

					if ( pd -> createtime != 0 )
					{
						short int hr =  ( pd -> createtime & 0xf800 ) >> 11 ;
						short int min =  ( ( pd -> createtime & 0x07e0 ) >> 5 ) ;
						short int sec =  ( pd -> createtime & 0x001f ) * 2 ;
						timestr.Format ( "%2d:%2d:%2d", hr, min, sec ) ; 
					}
					else
						timestr = "xx:xx:xx" ;

					str += " " + timestr ;

					//Last Access Date 

					if ( pd -> lastdate != 0 )
					{
						short int lastdd =  ( pd -> lastdate & 0x001f ) ;
						short int lastmm = ( ( pd -> lastdate & 0x01e0 ) >> 5) ;
						short int lastyy = ( ( pd -> lastdate & 0xfe00 ) >> 9 ) + 80;

						lastdatestr.Format ( " %2d-%2d-%2d", lastdd, lastmm, lastyy ) ;
					}
					else
						lastdatestr = " xx-xx-xx" ;

					str += " " + lastdatestr ;

					if ( isFAT32 == 0 )
						dirstr.Format ( " %-8d  %-8lu ", pd -> startclus, pd-> size ) ;
					else
						dirstr.Format ( " %04x%04x  %-8lu ", pd -> fat32handle, pd -> startclus, pd -> size ) ;

					str += "  " + dirstr ;
					
					spbuf += sizeof( directory );
				}
			}
		}
		pdoc -> lines.AddTail ( str ) ;
		str = "" ;
	}
}

BOOL myview::OnPreparePrinting ( CPrintInfo *info )
{
	return DoPreparePrinting ( info ) ;
}

void myview::OnBeginPrinting ( CDC *p, CPrintInfo *info )
{
	p -> SetMapMode ( MM_LOENGLISH ) ;
	int h = - ( ( p -> GetDeviceCaps ( LOGPIXELSY ) * 10 ) / 72 ) ;

	CSize temp1 ( 0, h ) ;
	p -> DPtoLP ( &temp1 ) ;
	h = temp1.cy ;

	if ( prn_font.m_hObject != NULL )
		prn_font.CreateFont ( h, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Courier New" ) ;

	CFont *prevfont = p -> SelectObject ( &prn_font ) ;

	TEXTMETRIC tm ;
	p -> GetTextMetrics ( &tm) ;
	prn_ht = tm.tmHeight + tm.tmExternalLeading ;

	// total number of pixels per page in device coordinates
	int vertpixels = p -> GetDeviceCaps ( VERTRES ) ;

	// convert into logical coordinates
	CSize sz ( 0, vertpixels ) ;
	p -> DPtoLP ( &sz ) ;

	linesperpage = sz.cy / prn_ht ;
	
	// make space for header and footer
	linesperpage = linesperpage - 10 ;

	int count = pdoc -> lines.GetCount( ) ;
	max_page = max ( 1, ( count + ( linesperpage - 1 ) ) / linesperpage ) ;
	p -> SelectObject ( prevfont ) ;
	info -> SetMaxPage ( max_page ) ;
}

void myview::OnPrint ( CDC *p, CPrintInfo *info )
{
	CFont* prevfont = p -> SelectObject ( &prn_font ) ;

	TEXTMETRIC tm ;
	p -> GetTextMetrics ( &tm ) ;

	// center coordinate
	int horzpixels = p -> GetDeviceCaps ( HORZRES ) ;
	CSize sz ( horzpixels, 0 ) ; p -> DPtoLP ( &sz ) ;
	int center = sz.cx / 2 ;

	// printheader
	CString title = pdoc -> GetTitle( ) ;
	UINT l = center - ( ( title.GetLength( ) / 2 )  * tm.tmAveCharWidth ) ;
	p -> TextOut ( l, 0, title ) ;

	// printpage
	int count = pdoc -> lines.GetCount( ) ;

	int start = ( ( info -> m_nCurPage ) - 1 ) * linesperpage ;
	int end = start + linesperpage ;
	
	POSITION pos = pdoc -> lines.FindIndex ( linesperpage * ( ( info -> m_nCurPage ) - 1 ) ) ;
	for ( int i = start, y = - ( prn_ht * 5 ) ; i < end && i < count ; i++ )
	{
		p -> TextOut ( 5, y, ( CString ) pdoc -> lines.GetNext ( pos ) ) ;
		y -= prn_ht ;
	}

	// printfooter
	CString pagenumber ;
	pagenumber.Format ( "%2d / %2d", info -> m_nCurPage, max_page ) ;
	l = center - ( ( pagenumber.GetLength( ) / 2 )  * tm.tmAveCharWidth ) ;
	p -> TextOut ( l, - ( linesperpage + 5 + 3 ) * prn_ht, pagenumber ) ;

	p -> SelectObject ( prevfont ) ;
}

void myview::OnEndPrinting ( CDC *p, CPrintInfo *info )
{
	prn_font.DeleteObject( ) ;
}

