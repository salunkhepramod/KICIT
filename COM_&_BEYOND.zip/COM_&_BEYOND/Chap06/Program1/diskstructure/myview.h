class myview : public CScrollView
{
	DECLARE_DYNCREATE ( myview ) 

	private :

		media m ;
		CString filetypestr ;
		boot bs ;
		boot32 bs32 ;
		bigfatbootfsinfo bf ;

		disk *pds ;

		mydoc *pdoc ;
		CString str ;
		CFont scr_font, prn_font ;
		int scr_ht, prn_ht, linesperpage, max_page ;

	public :

		virtual void OnInitialUpdate( ) ;
		void setview( ) ;
		virtual void OnDraw ( CDC *p ) ;

		virtual BOOL OnPreparePrinting ( CPrintInfo *info ) ;
		virtual void OnBeginPrinting ( CDC *p, CPrintInfo *info ) ;
		virtual void OnPrint ( CDC *p, CPrintInfo *info ) ;
		virtual void OnEndPrinting ( CDC *p, CPrintInfo *info ) ;

		void drive ( int id ) ;
		void media_id_info  ( int drive_1 ) ;// one-based drive
		void display_media_id( ) ;
		void boot_info ( int drive_0 ) ;
		void display_boot_info( ) ;
		void boot_info_32 ( int drive_1 ) ;
		void display_boot_info_32( ) ;
		void file_sys_info( ) ;
		void fat_info( ) ;
		void read_fat_info ( DWORD fat_num ) ;
		void display_dir_info ( int isFAT32, int drv ) ;

	DECLARE_MESSAGE_MAP( )
} ;