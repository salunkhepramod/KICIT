class mydoc : public CDocument
{
	DECLARE_DYNCREATE ( mydoc ) 

	private :

		disk ds ;

	public :

		CStringList lines ;

		virtual BOOL OnOpenDocument ( LPCTSTR filename ) ;
		virtual void Serialize ( CArchive &ar ) ;
		disk* getdiskobject( ) ;
} ;