#include <afxwin.h>
#include "disk.h"
#include "mydoc.h"
#include "myview.h"

IMPLEMENT_DYNCREATE ( mydoc, CDocument )

disk* mydoc::getdiskobject( )
{
	return &ds ;
}

BOOL mydoc::OnOpenDocument ( LPCTSTR filename )
{
	lines.RemoveAll( ) ;

	CDocument::OnOpenDocument ( filename ) ;

	POSITION pos = GetFirstViewPosition( ) ;
	myview *p = ( myview * ) GetNextView ( pos ) ;
	p -> setview( ) ;

	UpdateAllViews( NULL ) ;

	return TRUE ;
}

void mydoc::Serialize ( CArchive &ar ) 
{
	lines.Serialize ( ar ) ;
}
