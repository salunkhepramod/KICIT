class myframe : public CFrameWnd
{
	DECLARE_DYNCREATE ( myframe )
} ;
		