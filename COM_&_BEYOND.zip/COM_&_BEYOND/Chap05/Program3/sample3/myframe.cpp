#include <afxwin.h>
#include "myframe.h"
#include "htmlhelp.h"

#include "resource.h"

BEGIN_MESSAGE_MAP ( myframe, CFrameWnd ) 

	ON_COMMAND ( 101, help )
	ON_WM_HELPINFO( )

END_MESSAGE_MAP( )

myframe::myframe( )
{
	Create ( 0, "HTML Help Demo", WS_OVERLAPPEDWINDOW, rectDefault, 0, MAKEINTRESOURCE ( IDR_MENU1 ) ) ;
}

void myframe::help( )
{
	HtmlHelp ( AfxGetApp( ) -> m_pMainWnd -> GetSafeHwnd( ), "sample3.chm", HH_DISPLAY_TOPIC, 0 ) ;
}

BOOL myframe::OnHelpInfo ( HELPINFO *lpHelpInfo )
{
	HtmlHelp ( AfxGetApp( ) -> m_pMainWnd -> GetSafeHwnd( ), "sample3.chm", HH_DISPLAY_TOPIC, 0 ) ;
	return TRUE ;
}


