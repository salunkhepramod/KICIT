class myapp : public CWinApp
{
	public :

		BOOL InitInstance( ) ;
} ;



