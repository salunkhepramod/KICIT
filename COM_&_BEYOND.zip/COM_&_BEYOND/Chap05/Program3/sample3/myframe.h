class myframe : public CFrameWnd
{
	public :

		myframe( ) ;
		void help( ) ;
		BOOL OnHelpInfo( HELPINFO* lpHelpInfo ) ;

	DECLARE_MESSAGE_MAP( )
} ;
