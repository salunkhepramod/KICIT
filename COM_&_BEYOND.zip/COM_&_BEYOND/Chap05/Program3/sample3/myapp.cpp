#include <afxwin.h>
#include "myframe.h"
#include "myapp.h"

myapp a ;

BOOL myapp::InitInstance( )
{
	myframe *p ;
	p = new myframe ;
	p -> ShowWindow ( SW_SHOWNORMAL ) ;
	m_pMainWnd = p ;
	
	return TRUE ;
}
