#include <afxwin.h>
#include "myframe.h"

#include "resource.h"

BEGIN_MESSAGE_MAP ( myframe, CFrameWnd )
	ON_COMMAND ( ID_HELP_FINDER, CFrameWnd::OnHelpFinder )
END_MESSAGE_MAP( )

myframe::myframe( )
{
	Create ( 0, "Help", WS_OVERLAPPEDWINDOW, rectDefault, 0, MAKEINTRESOURCE ( IDR_MENU1 ) ) ;
}
