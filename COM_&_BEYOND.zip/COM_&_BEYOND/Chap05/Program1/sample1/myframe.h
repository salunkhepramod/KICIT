class myframe : public CFrameWnd
{
	public :

		myframe( ) ;

	DECLARE_MESSAGE_MAP( )
} ;
