class myapp : public CWinApp
{
	public :

		int InitInstance( ) ;
		void OnHelp( ) ;
		DWORD getcontrolid ( DWORD first, DWORD last ) ;

	DECLARE_MESSAGE_MAP( )
} ;
