class mydialog : public CDialog
{
	public :

		mydialog( ) ;
		void exit( ) ;

	DECLARE_MESSAGE_MAP( )
} ;
