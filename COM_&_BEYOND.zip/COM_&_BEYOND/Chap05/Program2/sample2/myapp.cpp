#include <afxwin.h>
#include "mydialog.h"
#include "myapp.h"

#include "resource.h"

BEGIN_MESSAGE_MAP ( myapp, CWinApp )
  ON_COMMAND ( ID_HELP, OnHelp )
END_MESSAGE_MAP( )

myapp a ;

int myapp::InitInstance( )
{
	mydialog d ;
	m_pMainWnd = &d ;
	d.DoModal( ) ;

	return 1 ;
}

void myapp::OnHelp()
{
   int id = getcontrolid ( IDC_EDIT1, IDC_CANCEL ) ;

   switch ( id )
   {
	  case IDC_EDIT1 :
		 WinHelp ( HID_EDIT1, HELP_CONTEXTPOPUP ) ;
		 break;

	  case IDC_RADIO1 :
		 WinHelp ( HID_RADIO, HELP_CONTEXTPOPUP ) ;
		 break;

	  case IDC_RADIO2 :
		 WinHelp ( HID_RADIO, HELP_CONTEXTPOPUP ) ;
		 break;

	  case IDC_RADIO3 :
		 WinHelp ( HID_RADIO, HELP_CONTEXTPOPUP ) ;
		 break;

	  case IDC_RADIO4 :
		 WinHelp ( HID_RADIO, HELP_CONTEXTPOPUP ) ;
		 break;

	  case IDC_OK :
		 WinHelp ( HID_OK, HELP_CONTEXTPOPUP ) ;
		 break;

	  case IDC_CANCEL :
		 WinHelp ( HID_CANCEL, HELP_CONTEXTPOPUP ) ;
		 break;

	  default:
		 WinHelp ( HID_DIALOG1, HELP_CONTEXTPOPUP ) ;
   }
}

DWORD myapp::getcontrolid ( DWORD first, DWORD last )
{
   DWORD control = 0;
   
   for ( control = first; control <= last; control++ )
   {
		if ( control == ID_HELP )
			return 0 ;

	  CWnd* w = m_pMainWnd -> GetDlgItem ( control ) ;
	  if ( !w ) 
		  continue ;

	  CPoint pt;
	  GetCursorPos ( &pt ) ;

	  CRect rc;
	  w -> GetClientRect ( &rc ) ;
	  w -> ScreenToClient ( &pt ) ;  
      
	  rc.NormalizeRect( ) ;
	  if ( rc.PtInRect ( pt ) ) 
		 return control ; 
   }

   return 0;
}
