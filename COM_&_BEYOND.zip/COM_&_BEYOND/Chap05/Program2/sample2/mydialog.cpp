#include <afxwin.h>
#include "mydialog.h"

#include "resource.h"

BEGIN_MESSAGE_MAP ( mydialog, CDialog )
	ON_COMMAND ( IDC_OK, exit )
END_MESSAGE_MAP( )

mydialog::mydialog( ) : CDialog ( IDD_DIALOG1 )
{
}

void mydialog::exit( )
{
	CDialog::OnOK( ) ;
}
