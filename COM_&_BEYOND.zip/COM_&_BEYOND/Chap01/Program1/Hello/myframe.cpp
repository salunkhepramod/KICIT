#include <afxwin.h>
#include "myframe.h"

BEGIN_MESSAGE_MAP ( myframe, CFrameWnd )
	ON_WM_PAINT( )
END_MESSAGE_MAP( )

myframe::myframe( )
{
	Create ( 0, "Draw" ) ;
}

void myframe::OnPaint( )
{
	CPaintDC d ( this ) ;
	d.TextOut ( 50, 50, "Hello", 5 ) ;
}
