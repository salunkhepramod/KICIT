class myframe : public CFrameWnd
{
	public :

		myframe( ) ;
		void OnPaint( ) ;

	DECLARE_MESSAGE_MAP( )
} ;
