#include <afxwin.h>
#include "myframe.h"
#include "myapp.h"

myapp a ;

BOOL myapp::InitInstance( )
{
	myframe *p ;
	p = new myframe ;
	m_pMainWnd = p ;
	
	p -> ShowWindow ( SW_SHOWNORMAL ) ;

	return TRUE ;
} 
