		VC++, COM and Beyond

1. The programs on this CD have been developed under VC++ 6.0 for Win95/98.  
   Hence it is necessary that VC++ 6.0 be present on the PC.

2. We trust that most of these programs would run under WinNT too. 
   Some programs however may need a few modifications.

3. Do not disable Autorun facility while using the CD.
