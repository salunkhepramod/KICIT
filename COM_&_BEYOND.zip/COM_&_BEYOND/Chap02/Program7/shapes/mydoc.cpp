#include <afxwin.h>
#include "cline.h"
#include "mydoc.h"

#include "resource.h"

IMPLEMENT_DYNCREATE ( mydoc, CDocument ) 

BEGIN_MESSAGE_MAP ( mydoc, CDocument )

	ON_COMMAND_RANGE ( ID_WIDTH_VTHIN, ID_WIDTH_VTHICK, onwidth ) 
	ON_COMMAND_RANGE ( ID_COLOR_BLACK, ID_COLOR_WHITE, oncolor ) 

END_MESSAGE_MAP( )

const int mydoc::linewidth[5] = { 1, 8, 16, 24, 32 } ;

const COLORREF mydoc::linecolor[8] = 
{ 
	RGB ( 0, 0, 0 ), 
	RGB ( 0, 0, 255 ), 
	RGB ( 0, 255, 0 ), 
	RGB ( 0, 255, 255 ), 
	RGB ( 255, 0, 0 ), 
	RGB ( 255, 0, 255 ), 
	RGB ( 255, 255, 0 ), 
	RGB ( 255, 255, 255 ), 
} ;		

mydoc::mydoc( )
{
	linearr.SetSize ( 0, 64 ) ;
}

BOOL mydoc::OnNewDocument( )
{
	if ( !CDocument::OnNewDocument( ) )
		return FALSE ;

	init_width_color( ) ;

	return true ;
}

BOOL mydoc::OnOpenDocument ( LPCTSTR filepath )
{
	if ( !CDocument::OnOpenDocument ( filepath ) )
		return FALSE ;

	init_width_color( ) ;

	return true ;
}

void mydoc::init_width_color( )
{
	wd = linewidth[0] ;
	clr = linecolor[0] ;
}

cline* mydoc::getline ( int i )
{
	return ( cline * ) linearr[i] ;
}

int mydoc::getlinecount( )
{
	return linearr.GetSize( ) ;
}

void mydoc::Serialize ( CArchive &ar )
{
	linearr.Serialize ( ar ) ;
}

cline* mydoc::addline ( CPoint from, CPoint to )
{
	cline *line ;
	line = new cline ( from, to, wd, clr ) ;

	linearr.Add ( line ) ;
	SetModifiedFlag( ) ;

	return line ;
}

void mydoc::onwidth ( UINT id )
{
	wd = linewidth[id - ID_WIDTH_VTHIN] ;
}

void mydoc::oncolor ( UINT id )
{
	clr = linecolor[id - ID_COLOR_BLACK] ;
}

int mydoc::getwidth( )
{
	return ( wd ) ;
}

COLORREF mydoc::getcolor( )
{
	return ( clr ) ;
}

void mydoc::DeleteContents( )
{
	int count = linearr.GetSize( ) ;

	if ( count )
	{
		for ( int i = 0 ; i < count ; i++ )
			delete linearr[i] ;

		linearr.RemoveAll( ) ;
	}
}
