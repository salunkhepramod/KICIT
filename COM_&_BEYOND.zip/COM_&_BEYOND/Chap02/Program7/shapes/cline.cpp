#include <afxwin.h>
#include "cline.h"

IMPLEMENT_SERIAL ( cline, CObject, 1 ) 

cline::cline( )
{
}

cline::cline ( CPoint from, CPoint to, int wd, COLORREF clr ) 
{
	startpt = from ;
	endpt = to ;
	width = wd ;
	color = clr ;
}

void cline::Serialize ( CArchive &ar )
{
	CObject::Serialize ( ar ) ;

	if ( ar.IsStoring( ) ) 
		ar << startpt << endpt << width << ( DWORD ) color ;
	else
		ar >> startpt >> endpt >> width >> ( DWORD ) color ;
}

void cline::draw ( CDC *p )
{
	CPen mypen ( PS_SOLID, width, color ) ;
			
	CPen *prevpen = p -> SelectObject ( &mypen ) ;

	p -> MoveTo ( startpt ) ;
	p -> LineTo ( endpt ) ;

	p -> SelectObject ( prevpen ) ;
}
