class mydoc : public CDocument
{
	DECLARE_DYNCREATE ( mydoc )
	
	private :

		CObArray linearr ;
		static const int linewidth[5] ;
		static const COLORREF linecolor[8] ;
		int wd ;
		COLORREF clr ;

	public :
		
		mydoc( ) ;
		BOOL OnNewDocument( ) ;
		BOOL OnOpenDocument ( LPCTSTR filepath ) ;
		void init_width_color( ) ;
		cline* getline ( int i ) ;
		int getlinecount( ) ;
		void Serialize ( CArchive &ar ) ;
		cline* addline ( CPoint from, CPoint to ) ;
		void onwidth ( UINT id ) ;
		void oncolor ( UINT id ) ;
		int getwidth( ) ;
		COLORREF getcolor( ) ;
		void DeleteContents( ) ;

	DECLARE_MESSAGE_MAP( )
} ;
