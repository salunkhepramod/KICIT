#include <afxwin.h>
#include "cline.h"
#include "mydoc.h"
#include "myview.h"
#include "myframe.h"
#include "myapp.h"

#include "resource.h"

myapp a ;

BEGIN_MESSAGE_MAP ( myapp, CWinApp )

	ON_COMMAND ( ID_FILE_NEW, CWinApp::OnFileNew ) 
	ON_COMMAND ( ID_FILE_OPEN, CWinApp::OnFileOpen ) 

END_MESSAGE_MAP( )

BOOL myapp::InitInstance( )
{
	SetRegistryKey ( "Drawing Software" ) ;
	LoadStdProfileSettings( ) ;

	d = RUNTIME_CLASS ( mydoc ) ;
	f = RUNTIME_CLASS ( myframe ) ;
	v = RUNTIME_CLASS ( myview ) ;

	CSingleDocTemplate *t ;
	t = new CSingleDocTemplate ( IDR_MAINFRAME, d, f, v ) ;

	AddDocTemplate ( t ) ;

	RegisterShellFileTypes ( TRUE ) ;

	CCommandLineInfo str ;
	ParseCommandLine ( str ) ;

	if ( !ProcessShellCommand ( str ) )
		return FALSE ;

	m_pMainWnd -> DragAcceptFiles( ) ;

	return TRUE ;
} 
