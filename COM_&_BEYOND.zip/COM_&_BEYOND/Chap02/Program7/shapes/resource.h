//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by coloredlines.rc
//
#define IDR_MAINFRAME                   101
#define ID_COLOR_BLACK                  40008
#define ID_COLOR_BLUE                   40009
#define ID_COLOR_GREEN                  40010
#define ID_COLOR_CYAN                   40011
#define ID_COLOR_RED                    40012
#define ID_COLOR_MAGENTA                40013
#define ID_COLOR_YELLOW                 40014
#define ID_COLOR_WHITE                  40015
#define ID_WIDTH_VTHIN                  40017
#define ID_WIDTH_THIN                   40018
#define ID_WIDTH_MEDIUM                 40019
#define ID_WIDTH_THICK                  40020
#define ID_WIDTH_VTHICK                 40021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40022
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
