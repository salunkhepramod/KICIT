class mydoc : public CDocument
{
	DECLARE_DYNCREATE ( mydoc )

	private :

		cline line ;

	public :
 
		mydoc( ) ;
		cline getline( ) ;
} ;
