#include <afxwin.h>
#include "cline.h"
#include "mydoc.h"
#include "myview.h"

IMPLEMENT_DYNCREATE ( myview, CView ) 

void myview::OnDraw ( CDC *p ) 
{ 
	mydoc *doc = ( mydoc * ) GetDocument( ) ;

	cline printline ;
	printline = doc -> getline( ) ;

	p -> MoveTo ( printline.startpt ) ;
	p -> LineTo ( printline.endpt ) ;
}
