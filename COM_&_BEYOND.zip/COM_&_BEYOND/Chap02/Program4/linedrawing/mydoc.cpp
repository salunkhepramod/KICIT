#include <afxwin.h>
#include "cline.h"
#include "mydoc.h"

IMPLEMENT_DYNCREATE ( mydoc, CDocument ) 

mydoc::mydoc( )
{
	line.startpt.x = 10 ;
	line.startpt.y = 10 ;

	line.endpt.x = 100 ;
	line.endpt.y = 100 ;
}

cline mydoc::getline( )
{
	return line ;
}
