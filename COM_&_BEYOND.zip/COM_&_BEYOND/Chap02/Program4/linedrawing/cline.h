struct cline 
{
	CPoint startpt ;
	CPoint endpt ;
} ;
