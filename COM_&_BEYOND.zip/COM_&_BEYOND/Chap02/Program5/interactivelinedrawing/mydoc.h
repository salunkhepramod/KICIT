class mydoc : public CDocument
{
	DECLARE_DYNCREATE ( mydoc )
	
	private :

		CObArray linearr ;

	public :
		
		mydoc( ) ;
		cline* getline ( int i ) ;
		int getlinecount( ) ;
		void Serialize ( CArchive &ar ) ;
		cline* addline ( CPoint from, CPoint to ) ;
		void DeleteContents( ) ;
} ;
