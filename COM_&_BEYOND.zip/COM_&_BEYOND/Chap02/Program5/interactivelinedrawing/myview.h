class myview : public CView
{
	DECLARE_DYNCREATE ( myview )

	private :

		CPoint lin_str_pt ;
		CPoint lin_end_pt ;
	
	public :

		void OnDraw ( CDC *p ) ;
		void OnLButtonDown ( UINT flags, CPoint pt ) ;
		void OnMouseMove ( UINT flags, CPoint pt ) ;
		void OnLButtonUp ( UINT flags, CPoint pt ) ;

	DECLARE_MESSAGE_MAP( )
} ;
