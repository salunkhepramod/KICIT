class cline : public CObject
{
	DECLARE_SERIAL ( cline ) 

	private :	

		CPoint startpt ;
		CPoint endpt ;

	public :

		cline( ) ;
		cline ( CPoint from, CPoint to ) ;
		void Serialize ( CArchive &ar ) ;
		void draw ( CDC *p ) ;
} ;
