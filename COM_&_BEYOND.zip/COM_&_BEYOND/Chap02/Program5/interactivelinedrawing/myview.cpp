#include <afxwin.h>
#include "cline.h"
#include "mydoc.h"
#include "myview.h"

IMPLEMENT_DYNCREATE ( myview, CView ) 

BEGIN_MESSAGE_MAP ( myview, CView )

	ON_WM_LBUTTONDOWN( )
	ON_WM_MOUSEMOVE( )
	ON_WM_LBUTTONUP( )

END_MESSAGE_MAP( )

void myview::OnDraw ( CDC *p ) 
{ 
	mydoc *doc = ( mydoc * ) GetDocument( ) ;
	int count = doc -> getlinecount( ) ;

	if ( count )
	{
		for ( int i = 0 ; i < count ; i++ )
			doc -> getline ( i ) -> draw ( p ) ;
	}
}

void myview::OnLButtonDown ( UINT flags, CPoint pt )
{
	CClientDC d ( this ) ;

	lin_str_pt = lin_end_pt = pt ;

	int prevmode = d.SetROP2 ( R2_NOTXORPEN ) ;

	d.MoveTo ( lin_str_pt ) ;
	d.LineTo ( lin_end_pt ) ;

	d.SetROP2 ( prevmode ) ;

	SetCapture( ) ;
}

void myview::OnMouseMove ( UINT flags, CPoint pt )
{
	if ( GetCapture( ) == this )
	{
		CClientDC d ( this ) ;

		int prevmode = d.SetROP2 ( R2_NOTXORPEN ) ;

		d.MoveTo ( lin_str_pt ) ;
		d.LineTo ( lin_end_pt ) ;

		d.MoveTo ( lin_str_pt ) ;
		d.LineTo ( pt ) ;

		lin_end_pt = pt ;

		d.SetROP2 ( prevmode ) ;
	}
}

void myview::OnLButtonUp ( UINT flags, CPoint pt )
{
	if ( GetCapture( ) == this )
	{
		::ReleaseCapture( ) ;
		CClientDC d ( this ) ;

		lin_end_pt = pt ;

		( ( mydoc * ) GetDocument( ) ) -> addline ( lin_str_pt, lin_end_pt ) ;

		d.MoveTo ( lin_str_pt ) ;
		d.LineTo ( lin_end_pt ) ;
	}
}
