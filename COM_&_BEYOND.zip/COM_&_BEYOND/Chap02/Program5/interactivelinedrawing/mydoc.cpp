#include <afxwin.h>
#include "cline.h"
#include "mydoc.h"

IMPLEMENT_DYNCREATE ( mydoc, CDocument ) 

mydoc::mydoc( )
{
	linearr.SetSize ( 0, 64 ) ;
}

cline* mydoc::getline ( int i )
{
	return ( cline* ) linearr[i] ;
}

int mydoc::getlinecount( )
{
	return linearr.GetSize( ) ;
}

void mydoc::Serialize ( CArchive &ar )
{
	linearr.Serialize ( ar ) ;
}

cline* mydoc::addline ( CPoint from, CPoint to )
{
	cline *line ;
	line = new cline ( from, to ) ;

	linearr.Add ( line ) ;
	SetModifiedFlag( ) ;

	return line ;
}

void mydoc::DeleteContents( )
{
	int count = linearr.GetSize( ) ;

	if ( count )
	{
		for ( int i = 0 ; i < count ; i++ )
			delete linearr[i] ;

		linearr.RemoveAll( ) ;
	}
}
