#include <afxwin.h>
#include "cline.h"

IMPLEMENT_SERIAL ( cline, CObject, 1 ) 

cline::cline( )
{
}

cline::cline ( CPoint from, CPoint to ) 
{
	startpt = from ;
	endpt = to ;
}

void cline::Serialize ( CArchive &ar )
{
	CObject::Serialize ( ar ) ;

	if ( ar.IsStoring( ) ) 
		ar << startpt << endpt ;
	else
		ar >> startpt >> endpt ;
}

void cline::draw ( CDC *p )
{
	p -> MoveTo ( startpt ) ;
	p -> LineTo ( endpt ) ;
}
