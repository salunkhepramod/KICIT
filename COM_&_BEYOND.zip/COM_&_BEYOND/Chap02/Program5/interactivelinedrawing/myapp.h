class myapp : public CWinApp
{
	private :
	
		CRuntimeClass *d, *f, *v ;

	public :

		BOOL InitInstance( ) ;
} ;
