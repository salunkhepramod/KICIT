#include <afxwin.h>
#include "myframe.h"

IMPLEMENT_DYNCREATE ( myframe, CFrameWnd ) 
