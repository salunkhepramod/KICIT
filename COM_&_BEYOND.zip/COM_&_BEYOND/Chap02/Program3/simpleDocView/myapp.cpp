#include <afxwin.h>
#include "mydoc.h"
#include "myframe.h"
#include "myview.h"
#include "myapp.h"

#include "resource.h"

myapp a ;

BOOL myapp::InitInstance( )
{
	d = RUNTIME_CLASS ( mydoc ) ;
	f = RUNTIME_CLASS ( myframe ) ;
	v = RUNTIME_CLASS ( myview ) ;

	CSingleDocTemplate *t ;
	t = new CSingleDocTemplate ( IDR_MAINFRAME, d,  f, v ) ; 
			// IDR_MAINFRAME - empty menu. 
			// To create an empty menu you just have to specify an id 
			// to the first menu item and no caption.


	AddDocTemplate ( t ) ;
	OnFileNew( ) ;

	return TRUE ;
} 
