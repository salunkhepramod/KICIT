#include <afxwin.h>
#include "myview.h"

IMPLEMENT_DYNCREATE ( myview, CView ) 

void myview::OnDraw ( CDC *p ) 
{ 
	p -> TextOut ( 50, 50, "Hello", 5 ) ; 
}
