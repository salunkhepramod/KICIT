class mydoc : public CDocument
{
	DECLARE_DYNCREATE ( mydoc )
} ;
