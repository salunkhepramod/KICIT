class myview : public CView
{
	DECLARE_DYNCREATE ( myview )
 
	public :

		void OnDraw ( CDC *p ) ;
} ;
