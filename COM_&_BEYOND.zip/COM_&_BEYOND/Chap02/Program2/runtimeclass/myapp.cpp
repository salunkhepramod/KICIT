#include <afxwin.h>
#include "myapp.h"
#include "myframe.h"

myapp a ;

BOOL myapp::InitInstance( ) 
{
	myframe *p ;
	p = new myframe ;
	m_pMainWnd = p ;

	p -> ShowWindow ( SW_SHOWMAXIMIZED ) ;

	return TRUE ;
}
