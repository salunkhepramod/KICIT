class myframe : public CFrameWnd
{
	public :

		myframe( ) ;
		int OnCreate ( LPCREATESTRUCT l ) ;

	DECLARE_MESSAGE_MAP( )
} ;
