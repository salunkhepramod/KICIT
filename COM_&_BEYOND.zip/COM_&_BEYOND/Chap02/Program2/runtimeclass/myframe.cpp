#include <afxwin.h>
#include "myframe.h"

BEGIN_MESSAGE_MAP ( myframe, CFrameWnd )
	ON_WM_CREATE( )
END_MESSAGE_MAP( )

myframe::myframe( )
{
	Create ( 0, "Runtime Class" ) ;
}

int myframe::OnCreate ( LPCREATESTRUCT l ) 
{
	CFrameWnd::OnCreate ( l ) ;

	CRuntimeClass *ptr ;
	ptr = RUNTIME_CLASS ( CFrameWnd ) ;
	char str[100] ;
	sprintf ( str, "%s", ptr -> m_lpszClassName ) ;
	MessageBox ( str, "Class Name" ) ;

	return 0 ;
}
