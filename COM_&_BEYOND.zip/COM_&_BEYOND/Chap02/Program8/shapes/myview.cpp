#include <afxwin.h>
#include "cshape.h"
#include "cline.h"
#include "crect.h"
#include "mydoc.h"
#include "myview.h"

IMPLEMENT_DYNCREATE ( myview, CView ) 

BEGIN_MESSAGE_MAP ( myview, CView )

	ON_WM_LBUTTONDOWN( )
	ON_WM_MOUSEMOVE( )
	ON_WM_LBUTTONUP( )

END_MESSAGE_MAP( )

void myview::OnDraw ( CDC *p ) 
{ 
	int objectcount = 0 ;

	mydoc *doc = ( mydoc * ) GetDocument( ) ;
	int count = doc -> getobjectscount( ) ;

	for ( int i = 0 ; i < count ; i++ )
		doc -> getobject ( i ) -> draw ( p ) ;
}

void myview::OnLButtonDown ( UINT flags, CPoint pt )
{
	mydoc *doc = ( mydoc * ) GetDocument( ) ;

	CClientDC d ( this ) ;
			
	CPen mypen ( PS_SOLID, doc -> getwidth( ), doc -> getcolor( ) ) ;

	CPen *prevpen = d.SelectObject ( &mypen ) ;
	int prevmode = d.SetROP2 ( R2_NOTXORPEN ) ;

	CBrush mybrush ;
	if ( doc -> getbrushstyle( ) == PS_SOLID )
		mybrush.CreateSolidBrush ( doc -> getbrushcolor( ) ) ;
	else
		mybrush.CreateStockObject( NULL_BRUSH ) ;

	CBrush *prevbrush = d.SelectObject ( &mybrush ) ;

	str_pt = end_pt = pt ;

	switch ( doc -> getshape( ) ) 
	{
		case 'L' :

			d.MoveTo ( str_pt ) ;
			d.LineTo ( end_pt ) ;
			break ;

		case 'R' :

			d.Rectangle ( str_pt.x, str_pt.y, end_pt.x, end_pt.y ) ;
			break ;
	}

	d.SelectObject ( prevpen ) ;
	d.SetROP2 ( prevmode ) ;
	d.SelectObject ( prevbrush ) ;

	SetCapture( ) ;
}

void myview::OnMouseMove ( UINT flags, CPoint pt )
{
	if ( GetCapture( ) == this )
	{
		mydoc *doc = ( mydoc * ) GetDocument( ) ;
				
		CClientDC d ( this ) ;

		CPen mypen ( PS_SOLID, ( ( mydoc * ) GetDocument( ) ) -> getwidth( ), 
					( ( mydoc * ) GetDocument( ) ) -> getcolor( ) ) ;

		CPen *prevpen = d.SelectObject ( &mypen ) ;
		int prevmode = d.SetROP2 ( R2_NOTXORPEN ) ;

		CBrush mybrush ;
		if ( doc -> getbrushstyle( ) == PS_SOLID )
			mybrush.CreateSolidBrush ( doc -> getbrushcolor( ) ) ;
		else
			mybrush.CreateStockObject( NULL_BRUSH ) ;

		CBrush *prevbrush = d.SelectObject ( &mybrush ) ;

		switch ( doc -> getshape( ) ) 
		{
			case 'L' :

				d.MoveTo ( str_pt ) ;
				d.LineTo ( end_pt ) ;

				d.MoveTo ( str_pt ) ;
				d.LineTo ( pt ) ;
				break ;

			case 'R' :
						
				d.Rectangle ( str_pt.x, str_pt.y, end_pt.x, end_pt.y ) ;
				d.Rectangle ( str_pt.x, str_pt.y, pt.x, pt.y ) ;
				break ;
		}

		end_pt = pt ;

		d.SelectObject ( prevpen ) ;
		d.SetROP2 ( prevmode ) ;
		d.SelectObject ( prevbrush ) ;
	}
}

void myview::OnLButtonUp ( UINT flags, CPoint pt )
{
	if ( GetCapture( ) == this ) 
	{
		::ReleaseCapture( ) ;
				
		mydoc *doc = ( mydoc * ) GetDocument( ) ;

		CClientDC d ( this ) ;

		end_pt = pt ;

		cline* line ;
		crect* rect ;
		switch ( doc -> getshape( ) ) 
		{
			case 'L' :

				line = doc -> addline ( str_pt, end_pt ) ;
				line -> draw ( &d ) ;
				break ;

			case 'R' :

				rect = doc -> addrect ( str_pt, end_pt ) ;
				rect -> draw ( &d ) ;
				break ;
		}
	}
}
