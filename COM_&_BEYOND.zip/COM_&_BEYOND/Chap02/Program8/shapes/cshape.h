class cshape : public CObject
{
	DECLARE_SERIAL ( cshape ) 

	public :

		cshape( ) ;
		virtual void draw ( CDC *p ) ;
} ;
