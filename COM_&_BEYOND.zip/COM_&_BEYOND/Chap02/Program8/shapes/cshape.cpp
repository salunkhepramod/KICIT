#include <afxwin.h>
#include "cshape.h"

IMPLEMENT_SERIAL ( cshape, CObject, 1 ) 

cshape::cshape( )
{
}

void cshape::draw ( CDC *p )
{
}
