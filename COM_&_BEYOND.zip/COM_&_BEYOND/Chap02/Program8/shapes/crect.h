class crect : public cshape
{
	DECLARE_SERIAL ( crect ) 

	private :	

		CPoint startpt ;
		CPoint endpt ;
		int lnwidth ;
		COLORREF lncolor ;
		UINT brstyle ;
		COLORREF brcolor ;

	public :

		crect( ) ;
		crect ( CPoint from, CPoint to, int wd, COLORREF clr, UINT brsty, 
				COLORREF brclr ) ;
		void Serialize ( CArchive &ar ) ;
		void draw ( CDC *p ) ;
} ;
