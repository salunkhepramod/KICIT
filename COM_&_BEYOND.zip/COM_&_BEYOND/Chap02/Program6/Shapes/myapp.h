class myapp : public CWinApp
{
	private :
	
		CRuntimeClass *d, *f, *v ;

	public :

		BOOL InitInstance( ) ;

	DECLARE_MESSAGE_MAP( )
} ;
