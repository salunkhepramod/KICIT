//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by bowarrow.rc
//
#define IDI_ICON1                       101
#define IDD_DIALOG1                     102
#define IDB_BITMAP1                     119
#define IDB_BITMAP2                     120
#define IDB_BITMAP3                     121
#define IDB_BITMAP4                     162
#define IDB_BITMAP5                     164
#define IDB_BITMAP6                     165
#define IDB_BITMAP7                     166
#define IDB_BITMAP8                     167
#define IDB_BITMAP9                     168
#define IDB_BITMAP10                    169
#define IDB_BITMAP11                    170
#define IDB_BITMAP12                    171
#define IDB_BITMAP13                    172
#define IDB_BITMAP14                    173
#define IDB_BITMAP15                    174
#define IDB_BITMAP16                    175
#define IDB_BITMAP17                    176
#define IDB_BITMAP18                    177
#define IDB_BITMAP19                    178
#define IDB_BITMAP20                    179
#define IDB_BITMAP21                    180
#define IDB_BITMAP22                    181
#define IDB_BITMAP23                    182
#define IDB_BITMAP24                    183
#define IDB_BITMAP25                    184
#define IDB_BITMAP26                    185
#define IDB_BITMAP27                    186
#define IDB_BITMAP28                    187
#define IDC_CURSOR1                     193
#define IDC_CURSOR2                     194
#define IDC_CURSOR3                     195
#define IDC_CURSOR4                     196

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        200
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
