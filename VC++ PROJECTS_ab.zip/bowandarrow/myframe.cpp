#include <afxwin.h>
#include <afxext.h>
#include "myframe.h"
#include "resource.h"

#define UP		1
#define DOWN	2
#define NOWHERE 3

#define NOTUSED 1
#define ALIVE	2
#define DEAD	3

#define AS		20  // arrow speed
#define BS		5   // ballon speed
#define BW		30  // balloon width
#define BH		50  // ballon height
#define AW		81  // arrow width
#define AH		9   // arrow height
#define MW		158 // Robin's width
#define MH		182 // Robin's height

BEGIN_MESSAGE_MAP( myframe, CFrameWnd ) 

	ON_WM_CREATE( )
	ON_WM_PAINT( )
	ON_WM_LBUTTONDOWN( )
	ON_WM_LBUTTONUP( )
	ON_WM_RBUTTONDOWN( )
	ON_WM_RBUTTONUP( )
	ON_WM_TIMER( )
	ON_WM_MOUSEMOVE( )
	ON_WM_DESTROY( ) 

END_MESSAGE_MAP( )
		
myframe::myframe( ) 
{
	CString mywindowclass ;
	CBrush mybrush ( RGB ( 0, 128, 0 ) ) ;
			
	mywindowclass = AfxRegisterWndClass ( CS_HREDRAW | CS_VREDRAW, 
							0, mybrush, AfxGetApp( ) -> LoadIcon ( IDI_ICON1 ) ) ;

	Create ( mywindowclass, "Bow and Arrow", WS_OVERLAPPED | WS_SYSMENU | WS_MINIMIZEBOX  ) ;
}

int myframe::OnCreate ( LPCREATESTRUCT l )
{
	CFrameWnd::OnCreate ( l ) ;
		
	CClientDC d ( this ) ;

	m_points = m_arrownumber = 0 ;
	m_personlocation = 10 ;
	m_countdown = 60 ;
	m_gameend = FALSE ;
	m_drag = FALSE ;

	m_cur1 = AfxGetApp( ) -> LoadCursor ( IDC_CURSOR1 ) ;
	m_cur2 = AfxGetApp( ) -> LoadCursor ( IDC_CURSOR2 ) ;
	m_cur3 = AfxGetApp( ) -> LoadCursor ( IDC_CURSOR3 ) ;
	m_cur4 = AfxGetApp( ) -> LoadCursor ( IDC_CURSOR4 ) ;
	m_cur5 = AfxGetApp( ) -> LoadStandardCursor ( IDC_ARROW ) ;

	m_personatstart.LoadBitmap ( IDB_BITMAP1 ) ;
	m_startmemdc.CreateCompatibleDC ( &d ) ;
	m_startmemdc.SelectObject ( &m_personatstart ) ;

	m_memdcbefore.CreateCompatibleDC ( &d ) ;
	m_memdcafter.CreateCompatibleDC ( &d ) ;
	m_personbkgndmemdc.CreateCompatibleDC ( &d ) ;

	m_personbeforeshoot.LoadBitmap ( IDB_BITMAP2 ) ;
	m_memdcbefore.SelectObject ( m_personbeforeshoot ) ;
			
	m_personaftershoot.LoadBitmap ( IDB_BITMAP3 ) ;
	m_memdcafter.SelectObject ( m_personaftershoot ) ;
		
	m_personbkgndbitmap.LoadBitmap ( IDB_BITMAP4 ) ;
	m_personbkgndmemdc.SelectObject ( &m_personbkgndbitmap ) ;

	for( int i = 0 ; i <= 9 ; i++ ) 
	{
		m_b[i].x1 = 300 + i * BW ;
		m_b[i].y1 = 420 ;
		m_b[i].x2 = m_b[i].x1 + BW ;
		m_b[i].y2 = m_b[i].y1 + BH ;

		m_b[i].balloonstatus = UP  ;
		m_b[i].balloonbitmap.LoadBitmap ( IDB_BITMAP5 + i ) ;
		m_b[i].balloonmemdc.CreateCompatibleDC ( &d ) ;
		m_b[i].balloonmemdc.SelectObject ( &m_b[i].balloonbitmap ) ;
			
		m_b[i].balloonbgbitmap.LoadBitmap ( IDB_BITMAP15 ) ;
		m_b[i].balloonbgmemdc.CreateCompatibleDC ( &d ) ;
		m_b[i].balloonbgmemdc.SelectObject ( &m_b[i].balloonbgbitmap ) ;

		m_b[i].burstballoonbitmap.LoadBitmap ( IDB_BITMAP16 + i ) ;
		m_b[i].burstballoonmemdc.CreateCompatibleDC ( &d ) ;
		m_b[i].burstballoonmemdc.SelectObject ( &m_b[i].burstballoonbitmap ) ;
	}
			
	m_spray.LoadBitmap ( IDB_BITMAP28 ) ;
	m_spraymemdc.CreateCompatibleDC ( &d ) ;
	m_spraymemdc.SelectObject ( &m_spray ) ;

	for( i = 0 ; i <= 9 ; i++ )
	{
		m_a[i].x1 = 150 ;
		m_a[i].y1 = 75 ;
		m_a[i].x2 = m_a[i].x1 + AW ;
		m_a[i].y2 = m_a[i].y1 + AH ;
		m_a[i].arrowstatus = NOTUSED ;

		m_a[i].arrowbitmap.LoadBitmap ( IDB_BITMAP26 ) ;
		m_a[i].arrowmemdc.CreateCompatibleDC ( &d ) ;
		m_a[i].arrowmemdc.SelectObject ( &m_a[i].arrowbitmap ) ;
				
		m_a[i].arrowbgbitmap.LoadBitmap ( IDB_BITMAP27 ) ;
		m_a[i].arrowbgmemdc.CreateCompatibleDC ( &d ) ;
		m_a[i].arrowbgmemdc.SelectObject ( &m_a[i].arrowbgbitmap ) ;
	}

	SetTimer ( 1, 52, NULL ) ;
	SetTimer ( 2, 150, NULL ) ;
	SetTimer ( 3, 82, NULL ) ;
	SetTimer ( 4, 30 ,NULL ) ;
	SetTimer ( 5, 12, NULL ) ;
	SetTimer ( 6, 130, NULL ) ;
	SetTimer ( 7, 25, NULL ) ;
	SetTimer ( 8, 65, NULL ) ;
	SetTimer ( 9, 100, NULL ) ;
	SetTimer ( 10, 5, NULL ) ;

	SetTimer ( 21, 1000, NULL ) ;

	UINT indicator[6] ;
	m_sb.Create ( this ) ;
	m_sb.SetIndicators ( indicator, 6 ) ;

	m_sb.SetPaneInfo ( 0, ID_SEPARATOR, SBPS_NOBORDERS, 100 ) ;
	m_sb.SetPaneInfo ( 1, ID_SEPARATOR, SBPS_NORMAL, 60 ) ;
	m_sb.SetPaneInfo ( 2, ID_SEPARATOR, SBPS_NORMAL, 100 ) ;
	m_sb.SetPaneInfo ( 3, ID_SEPARATOR, SBPS_NORMAL, 80 ) ;
	m_sb.SetPaneInfo ( 4, ID_SEPARATOR, SBPS_POPOUT, 57 ) ;
	m_sb.SetPaneInfo ( 5, ID_SEPARATOR, SBPS_NORMAL | SBPS_STRETCH, 0 ) ;

	return 0 ;
}

void myframe::OnPaint( ) 
{
	CPaintDC d ( this ) ;

	m_startpos = TRUE ;
	m_leftbutton = FALSE ;
	d.BitBlt ( 10, m_personlocation, MW, MH, &m_startmemdc, 0, 0, SRCCOPY ) ;
			
	m_sb.SetPaneText ( 0, "Developed at I C I T" ) ;
	m_sb.SetPaneText ( 1, "Get Ready" ) ;

	m_str.Format ( "Remaining : %d secs", m_countdown ) ;
	m_sb.SetPaneText ( 2, m_str ) ;

	m_str.Format ( "Arrows Left : %d", ( 10 - m_arrownumber ) ) ;
	m_sb.SetPaneText ( 3, m_str ) ;

	m_str.Format ( "Points : %d", m_points ) ;
	m_sb.SetPaneText ( 4, m_str ) ;

	m_sb.SetPaneText ( 5, "Aim and Shoot" ) ;
}

void myframe::OnLButtonDown ( int flags, CPoint p )
{
	CClientDC d ( this ) ;

	m_startpos = FALSE ;

	if ( ( p.x > 10 && ( p.x < 10 + MW ) ) && ( p.y > m_personlocation && ( p.y < m_personlocation + MH ) ) )
	{
		if ( m_drag != TRUE ) 
		{
			::SetCursor ( m_cur2 ) ;
			m_sb.SetPaneText ( 1, "Shoot" ) ;
		}
		else
		{
			if ( m_drag == TRUE )
			{
				::SetCursor ( m_cur4 ) ;
				m_sb.SetPaneText ( 1, "Drag/Shoot" ) ;
			}
		}

		m_leftbutton = TRUE ;
		d.BitBlt( 10, m_personlocation, MW, MH, &m_memdcbefore, 0, 0, SRCCOPY ) ;

		return ;
	}
		
	::SetCursor ( m_cur5 ) ;
	m_sb.SetPaneText ( 1, "Rest" ) ;
	m_leftbutton = FALSE ;
}

void myframe::OnRButtonDown( int flags, CPoint p ) 
{
	if ( ( p.x > 10 && ( p.x < 10 + MW ) ) && ( p.y > m_personlocation && ( p.y < m_personlocation + MH ) ) )
	{
		CClientDC d(this) ;

		if ( m_leftbutton != TRUE )
		{
			::SetCursor ( m_cur3 ) ;
			m_sb.SetPaneText ( 1, "Drag" ) ;
		}
		else
		{
			if ( m_leftbutton == TRUE )
			{
				::SetCursor ( m_cur4 ) ;
				m_sb.SetPaneText ( 1, "Drag/Shoot" ) ;
			}
		}

		m_drag = TRUE ;
		m_offset = p.y - m_personlocation ;

		return ;
	}

	m_drag = FALSE ;
}

void myframe::OnMouseMove( int flags, CPoint p )
{
	if ( ( p.x > 10 && ( p.x < 10 + MW ) ) && ( p.y > m_personlocation && ( p.y < m_personlocation + MH ) ) )
	{
		if ( m_drag == TRUE && m_leftbutton == FALSE && m_startpos == TRUE ) 
		{
			::SetCursor ( m_cur3 ) ;
			m_sb.SetPaneText ( 1, "Drag" ) ;

			CClientDC d(this) ;
			if ( ( ( p.y + ( MH - m_offset ) ) < 430 ) && ( ( p.y - m_offset ) > 0 ) ) 
			{
				d.BitBlt( 10, m_personlocation, MW, MH, &m_personbkgndmemdc, 0, 0, SRCCOPY ) ;
				m_personlocation = p.y - m_offset ;
				d.BitBlt( 10, m_personlocation, MW, MH, &m_startmemdc, 0, 0, SRCCOPY ) ;
			}

			return ;
		}

		if ( m_drag == TRUE && m_leftbutton == TRUE && m_startpos == FALSE )
		{
			::SetCursor ( m_cur4 ) ;
			m_sb.SetPaneText ( 1, "Drag/Shoot" ) ;

			CClientDC d(this) ;
			if ( ( ( p.y + ( MH - m_offset ) ) < 430 ) && ( ( p.y - m_offset ) > 0 ) ) 
			{
				d.BitBlt( 10, m_personlocation, MW, MH, &m_personbkgndmemdc, 0, 0, SRCCOPY ) ;
				m_personlocation = p.y - m_offset ;
				d.BitBlt( 10, m_personlocation, MW, MH, &m_memdcbefore, 0, 0, SRCCOPY ) ;
			}

			return ;
		}
			
		if ( m_drag == TRUE && m_leftbutton == FALSE && m_startpos == FALSE )
		{
			::SetCursor ( m_cur3 ) ;
			m_sb.SetPaneText ( 1, "Drag" ) ;
	
			CClientDC d(this) ;
			if ( ( ( p.y + ( MH - m_offset ) ) < 430 ) && ( ( p.y - m_offset ) > 0 ) ) 
			{
				d.BitBlt( 10, m_personlocation, MW, MH, &m_personbkgndmemdc, 0, 0, SRCCOPY ) ;
				m_personlocation = p.y - m_offset ;
				d.BitBlt( 10, m_personlocation, MW, MH, &m_memdcafter, 0, 0, SRCCOPY ) ;
			}

			return ;
		}

		if ( m_leftbutton == TRUE ) 
		{
			::SetCursor ( m_cur2 ) ;
			m_sb.SetPaneText ( 1, "Shoot" ) ;
			return ;
		}

		::SetCursor ( m_cur1 ) ;
		m_sb.SetPaneText ( 1, "Load" ) ;
	}
	else
	{
		::SetCursor ( m_cur5 ) ;
		m_sb.SetPaneText ( 1, "Rest" ) ;
	}
}

void myframe::OnLButtonUp( int flags, CPoint p )
{
	CClientDC d ( this ) ;

	if ( m_arrownumber == 10 )
		return ;

	if ( ( p.x > 10 && ( p.x < 10 + MW ) ) && ( p.y > m_personlocation && ( p.y < m_personlocation + MH ) ) ) 
	{
		if ( m_leftbutton == TRUE )
		{
			::SetCursor ( m_cur1 ) ;

			d.BitBlt( 10, m_personlocation, MW, MH, &m_memdcafter, 0, 0, SRCCOPY ) ;
			m_a[m_arrownumber].arrowstatus = ALIVE ;
			m_a[m_arrownumber].y1 = m_personlocation + 65 ;
			SetTimer( m_arrownumber + 11, 10, NULL ) ;
			m_arrownumber++ ;

			m_str.Format ("Arrows left : %d", ( 10 - m_arrownumber ) ) ;
			m_sb.SetPaneText ( 3, m_str ) ;
		
			m_leftbutton = FALSE ;

			if ( m_drag == TRUE ) 
				::SetCursor ( m_cur3 ) ;

			return ;
		}
				
		::SetCursor ( m_cur1 ) ;
		m_sb.SetPaneText ( 1, "Load" ) ;
		return ;
	}

	if ( m_leftbutton == TRUE )
	{
		::SetCursor ( m_cur5 ) ;
		m_sb.SetPaneText ( 1, "Rest" ) ;
		d.BitBlt( 10, m_personlocation, MW, MH, &m_memdcafter, 0, 0, SRCCOPY ) ;
		m_leftbutton = FALSE ;

		return ;
	}

	m_sb.SetPaneText ( 1, "Rest" ) ;
}

void myframe::OnRButtonUp ( int flags, CPoint p )
{
	if ( ( p.x > 10 && ( p.x < 10 + MW ) ) && ( p.y > m_personlocation && ( p.y < m_personlocation + MH ) ) ) 
	{
		if ( m_leftbutton == TRUE )
			::SetCursor ( m_cur2 ) ;
		else
			::SetCursor ( m_cur1 ) ;

		m_sb.SetPaneText ( 1, "Load" ) ;
	}
	else
	{
		::SetCursor ( m_cur5 ) ;
		m_sb.SetPaneText ( 1, "Rest" ) ;
	}

	m_drag = FALSE ;
}

void myframe::OnTimer( int n ) 
{
	CClientDC d(this) ;
	int count ;
	int ht, ht1 ;

	switch( n )
	{
		case 21 :

			if ( m_gameend == FALSE ) 
			{
				m_countdown-- ;
				
				m_str.Format ( "Remaining : %d secs", m_countdown ) ;
				m_sb.SetPaneText ( 2, m_str ) ;
				if ( ( m_countdown == 0 ) || ( m_a[9].arrowstatus == DEAD ) )
				{
					if ( m_points < 50 )
						m_sb.SetPaneText ( 5, "You'r weak at Shooting, try to improve..." ) ;
					else if ( m_points < 100 )
						m_sb.SetPaneText ( 5, "You need to concentrate more..." ) ;
					else if ( m_points < 200 )
						m_sb.SetPaneText ( 5, "You might be making errors, try again..." ) ;
					else if ( m_points < 300 )
						m_sb.SetPaneText ( 5, "Good..." ) ;
					else if ( m_points >= 300 )
						m_sb.SetPaneText ( 5, "Excellent..." ) ;

					m_gameend = TRUE ;
					CDialog pp ( IDD_DIALOG1 ) ;
					pp.DoModal( ) ;
					DestroyWindow( ) ;
				}
			}

			break ;

		case 1 :
		case 2 :
		case 3 :
		case 4 :
		case 5 :
		case 6 :
		case 7 :
		case 8 :
		case 9 :
		case 10 :
					
			n = n - 1 ;
			if ( m_b[n].balloonstatus == UP )
			{
				if ( m_b[n].y1 >= 385 )
				{
					ht = 435 - m_b[n].y1 ;
					ht1 = ht - BS ;
				}
				else
				{
					ht = BH ;
					ht1 = BH ;
				}

				d.BitBlt( m_b[n].x1, m_b[n].y1 + BS, BW, ht1, &m_b[n].balloonbgmemdc, 0, 0, SRCCOPY ) ;
				d.BitBlt( m_b[n].x1, m_b[n].y1, BW, ht, &m_b[n].balloonmemdc, 0, 0, SRCCOPY ) ;
				m_b[n].y1 = m_b[n].y1 - BS ;
				m_b[n].y2 = m_b[n].y2 - BS ;
						
				if( m_b[n].y1 < -BH )
					m_b[n].balloonstatus = NOWHERE ;
			}

			if( m_b[n].balloonstatus == DOWN ) 
			{
				if ( m_b[n].y1 >= 390 )
				{
					ht = 442 - m_b[n].y1 ;
					ht1 = ht - BS ;
				}
				else
				{
					ht = BH ;
					ht1 = BH ;
				}

				d.BitBlt( m_b[n].x1, m_b[n].y1 - BS, BW, ht, &m_b[n].balloonbgmemdc, 0, 0, SRCCOPY ) ;
				d.BitBlt( m_b[n].x1, m_b[n].y1, BW, ht1, &m_b[n].burstballoonmemdc, 0, 0, SRCCOPY ) ;
				m_b[n].y1 = m_b[n].y1 + BS ;
				m_b[n].y2 = m_b[n].y2 + BS ;

				if ( m_b[n].y1 > 480 )
					m_b[n].balloonstatus = NOWHERE ;
			}

			count = 0 ;

			if( m_b[n].balloonstatus == NOWHERE ) 
			{
				m_b[n].x1 = 300 + n * BW ;
				m_b[n].y1 = 420 ;
				m_b[n].x2 = m_b[n].x1 + BW ;
				m_b[n].y2 = m_b[n].y1 + BH ;
				m_b[n].balloonstatus = UP ;
			} 
			break ;

		default :

			n = n - 11 ;

			if ( m_a[n].arrowstatus == ALIVE ) 
			{
				d.BitBlt( m_a[n].x1 - AS, m_a[n].y1, AW, AH, &m_a[n].arrowbgmemdc, 0, 0, SRCCOPY ) ;
				d.BitBlt( m_a[n].x1, m_a[n].y1, AW, AH, &m_a[n].arrowmemdc, 0, 0, SRCCOPY ) ;
							
				m_a[n].x1 = m_a[n].x1 + AS ;
				m_a[n].x2 = m_a[n].x2 + AS ;
							
				if( m_a[n].x1 > 650 )
				{
					m_a[n].arrowstatus = DEAD ;
					KillTimer ( n + 11 ) ;
				}
			}

			for( int j = 0 ; j <= 9 ; j++ )
			{
				if ( m_b[j].balloonstatus == UP )
				{
					if( m_a[n].x2 >= m_b[j].x1 && m_a[n].x2 <= m_b[j].x2 
						&& m_a[n].y1 + 4 >= m_b[j].y1 && m_a[n].y1 + 4 <= m_b[j].y2 )
					{
						m_b[j].balloonstatus = DOWN ;
						::MessageBeep(1);
						d.BitBlt( m_b[j].x1, m_b[j].y1, 30, 30, &m_spraymemdc, 0, 0, SRCCOPY ) ;
									
						m_points = m_points + ( j + 1 ) ;
						m_str.Format ( "Points : %d", m_points ) ;
						m_sb.SetPaneText ( 4, m_str ) ;
					}
				}
			}
			break ;
		}
}

void myframe::OnDestroy( )
{
	for ( int i = 1 ; i <= 10 ; i++ )
	{
		KillTimer ( i ) ;

		if ( m_a[i].arrowstatus == ALIVE )
			KillTimer ( i + 11 ) ;
	}

	KillTimer ( 21 ) ;
}
