class myframe : public CFrameWnd
{
	private :

		CBitmap m_personbeforeshoot, m_personaftershoot, m_personbkgndbitmap, m_personatstart, m_spray ;
		CDC m_memdcbefore, m_memdcafter, m_personbkgndmemdc, m_startmemdc, m_spraymemdc ;
		int m_personlocation, m_offset, m_arrownumber, m_drag, m_points, m_countdown ;
		HCURSOR m_cur1, m_cur2, m_cur3, m_cur4, m_cur5 ;
		BOOL m_leftbutton, m_startpos, m_gameend ;
		CStatusBar m_sb ;
		CString m_str ;

		struct balloon
		{
			int x1, y1, x2, y2 ;
			int balloonstatus ;
			CBitmap balloonbitmap ;
			CDC balloonmemdc ;
			CBitmap  balloonbgbitmap ;
			CDC balloonbgmemdc ;
			CBitmap burstballoonbitmap ;
			CDC burstballoonmemdc ;
		} m_b[10] ;

		struct arrow
		{
			int x1, y1, x2, y2 ;
			int arrowstatus ;
			CBitmap arrowbitmap ;
			CDC arrowmemdc ;
			CBitmap arrowbgbitmap ;
			CDC arrowbgmemdc ;
		} m_a[10] ;

	public :

		myframe( ) ;
		int OnCreate ( LPCREATESTRUCT l ) ;
		void OnPaint( ) ;
		void OnLButtonDown ( int flags, CPoint p ) ;
		void OnRButtonDown( int flags, CPoint p ) ;
		void OnMouseMove( int flags, CPoint p ) ;
		void OnLButtonUp( int flags, CPoint p ) ;
		void OnRButtonUp ( int flags, CPoint p ) ;
		void OnTimer( int n ) ;
		void OnDestroy( ) ;
				
	DECLARE_MESSAGE_MAP( )

} ;
