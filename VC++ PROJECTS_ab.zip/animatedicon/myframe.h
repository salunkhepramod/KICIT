#include "myimage.h"

class myframe : public CFrameWnd
{
	private :

		int m_count ;
		myimage m_img ;

	public :

		myframe( ) ;
		int OnCreate ( LPCREATESTRUCT l ) ;
		void OnTimer ( UINT id ) ;

	DECLARE_MESSAGE_MAP( )
};
