#include "myimage.h"

HICON myimage::shownextimage ( int i )
{
	return ( ExtractIcon ( i ) ) ;
}
