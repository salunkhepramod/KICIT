class myapp : public CWinApp
{
	public :
		
		int InitInstance( ) ;
} ;
