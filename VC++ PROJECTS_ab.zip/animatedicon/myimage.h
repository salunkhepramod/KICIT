#include <afxcmn.h>

class myimage : public CImageList 
{
	public:
		
		HICON shownextimage ( int i ) ;
};

