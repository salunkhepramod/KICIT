#include <afxwin.h>
#include "myframe.h"
#include "resource.h"

BEGIN_MESSAGE_MAP ( myframe, CFrameWnd )

	ON_WM_CREATE( )
	ON_WM_TIMER( )

END_MESSAGE_MAP( )

myframe::myframe( )
{
	Create ( 0, "ANIMATED ICON" ) ;
}

int myframe::OnCreate ( LPCREATESTRUCT l )
{
	CFrameWnd::OnCreate ( l );
		
	m_img.Create ( IDB_BITMAP1, 16, 1, CLR_NONE ) ;
	SetTimer ( 1, 250, NULL ) ;
	m_count = 0 ;

	return 0 ;
}

void myframe::OnTimer ( UINT id )
{
	HICON h = m_img.shownextimage ( m_count ) ;
	SetIcon ( h, TRUE ) ;

	m_count++ ;
	if ( m_count == 4 )
		m_count = 0;
}
