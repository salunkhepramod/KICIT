class aboutdialog : public CDialog
{
	public :
		
		aboutdialog( ) ;
		int OnInitDialog( ) ;
		void OnOK( ) ;
		void OnCancel( ) ;
};

