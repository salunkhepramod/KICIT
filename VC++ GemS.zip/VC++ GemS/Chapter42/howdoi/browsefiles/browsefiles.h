// browsefiles.h : main header file for the BROWSEFILES application
//

#if !defined(AFX_BROWSEFILES_H__6A76C6C4_C31B_11D5_A73B_0050BA37CE53__INCLUDED_)
#define AFX_BROWSEFILES_H__6A76C6C4_C31B_11D5_A73B_0050BA37CE53__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CBrowsefilesApp:
// See browsefiles.cpp for the implementation of this class
//

class CBrowsefilesApp : public CWinApp
{
public:
	CBrowsefilesApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBrowsefilesApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CBrowsefilesApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BROWSEFILES_H__6A76C6C4_C31B_11D5_A73B_0050BA37CE53__INCLUDED_)
