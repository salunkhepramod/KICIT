// animatedcursorDlg.h : header file
//

#if !defined(AFX_ANIMATEDCURSORDLG_H__73F75276_B8D9_11D5_9D42_0050BAD6AD8F__INCLUDED_)
#define AFX_ANIMATEDCURSORDLG_H__73F75276_B8D9_11D5_9D42_0050BAD6AD8F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CAnimatedcursorDlg dialog

class CAnimatedcursorDlg : public CDialog
{
// Construction
public:
	CAnimatedcursorDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CAnimatedcursorDlg)
	enum { IDD = IDD_ANIMATEDCURSOR_DIALOG };
	CStatic	m_picture;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAnimatedcursorDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CAnimatedcursorDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ANIMATEDCURSORDLG_H__73F75276_B8D9_11D5_9D42_0050BAD6AD8F__INCLUDED_)
