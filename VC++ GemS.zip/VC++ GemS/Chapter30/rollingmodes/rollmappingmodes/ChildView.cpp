// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "rollmappingmodes.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildView

CChildView::CChildView()
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView,CWnd )
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), HBRUSH(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc ( this ) ; 

	dc.SetMapMode ( MM_ANISOTROPIC ) ;

	int wx = dc.GetDeviceCaps ( HORZSIZE ) ;
	int wy = dc.GetDeviceCaps ( VERTSIZE ) ;

	dc.SetWindowExt ( wx / 10 , -wy / 5 ) ;

	int vx = dc.GetDeviceCaps ( HORZRES ) ;
	int vy = dc.GetDeviceCaps ( VERTRES ) ;

	dc.SetViewportExt ( vx, vy ) ;
		
	CRect r ;
	GetClientRect ( &r ) ;
	dc.SetViewportOrg ( r.right / 2, r.bottom / 2 ) ;
	dc.MoveTo ( 0, -r.bottom ) ;
	dc.LineTo ( 0, r.bottom ) ;
	dc.MoveTo ( -r.right, 0 ) ; 
	dc.LineTo ( r.right, 0 ) ;
			
	dc.SetPixel ( CPoint ( 2, 4 ), RGB ( 255, 0, 0 ) ) ;
	dc.SetPixel ( CPoint ( -2, -4 ),RGB ( 255, 0, 0 ) ) ;
	dc.SetPixel ( CPoint ( -2, 4 ),RGB ( 255, 0, 0 ) ) ;
	dc.SetPixel ( CPoint ( 2, -4 ), RGB ( 255, 0, 0 ) ) ;
}

