// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "barchart.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildView

CChildView::CChildView()
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView,CWnd )
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), HBRUSH(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc ( this ) ; 

	CRect r ; 
	GetClientRect ( &r ) ;

	dc.SetMapMode ( MM_ANISOTROPIC ) ;
	dc.SetWindowExt ( 100, -200 ) ;
	dc.SetViewportExt ( r.right, r.bottom );	
	dc.SetViewportOrg ( 0, r.bottom / 2 ) ;

	dc.MoveTo ( 0, 0 ) ;
	dc.LineTo ( r.right, 0 ) ;

	CString str ;
	for ( int i = 10, x = 1991 ; i < 100; i += 10, x++ )
	{
		dc.MoveTo ( i, 0 ) ;
		dc.LineTo ( i, -4 ) ;
		str.Format ( "%d", x ) ;	
		dc.TextOut ( i-2, -5, str ) ;
	}
			
	for( i = -90 ; i < 100; i += 10 )
	{
		dc.MoveTo ( 0, i ) ;
		dc.LineTo ( 2, i ) ;
		str.Format ( "%d", i ) ;
		dc.TextOut ( 4, i + 4, str ) ;  
	}

	int p[ ] = { 40, -10, 20, 40, 40, 50, -40, 50, -60 } ;

	dc.SelectStockObject ( NULL_BRUSH ) ;
	int j = 0 ;
	for( i = 10 ; i < 100 ; i += 10, j++ ) 
		dc.Rectangle ( i - 3, 0, i + 3, p[ j ] ) ;
}

