// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "mediaid.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildView

#define VWIN32_DIOC_DOS_IOCTL	1

struct DIOC_REGISTERS 
{
	DWORD ebx ;
	DWORD edx ;
	DWORD ecx ;
	DWORD eax ;
	DWORD edi ;
	DWORD esi ;
	DWORD flags ;
} ;


CChildView::CChildView()
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView,CWnd )
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	ON_WM_CREATE()
	ON_COMMAND_RANGE ( 65, 90, drive )
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), HBRUSH(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc ( this ) ; 

	CRect r ;
	GetClientRect ( &r ) ;
			
	int y = 10 ;
	for ( int i = 0 ; i <= m_cnt ; i++ )
	{
		dc.TextOut( 10, y, m_str[i], strlen ( m_str[i] ) ) ;
		y += 20 ;
	}
}


int CChildView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd ::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	m_hdev = CreateFile ( "\\\\.\\VWIN32", 0, 0, NULL, 0, 
			FILE_FLAG_DELETE_ON_CLOSE, NULL ) ;
	
	return 0;
}

void CChildView::getmediaid(int drive_1, media *m)
{
	DIOC_REGISTERS r = {0};
	DWORD cb ;
			
	r.eax = 0x440d ;
	r.ebx = drive_1 ;
	r.ecx = 0x0866 ;
	r.edx = ( DWORD ) m ;
	r.flags = 1 ;

	DeviceIoControl ( m_hdev, VWIN32_DIOC_DOS_IOCTL,
					&r, sizeof ( r ), &r, sizeof ( r ), &cb, 0 ) ;
}

void CChildView::drive(int id)
{
	media m ;

	int drive_1 ;
	CString drivetypestr, drivestr ;

	m_cnt = 0 ;

	drive_1 = id - 'A' + 1 ;
	drivetypestr = drivestr = 'A' + drive_1 - 1 ;
	drivestr += ":\\" ;

	int result = GetDriveType ( drivestr ) ;

	if ( result == 1 )
		m_str[m_cnt] = "Drive does not exist" ;
	else
	{
		if ( result == 5 )
			m_str[m_cnt] = "CD ROM Drive" ;
		else
		{
			getmediaid ( drive_1, &m ) ;

			CString tempstr ;

			m_str[m_cnt] = "Media ID of drive " + drivetypestr ;
			m_cnt++ ;

			m_str[m_cnt] = "--------------------------------" ;
			m_cnt++ ;

			m_str[m_cnt] = "Volume Label : " ;

			for ( int i = 0 ; i < 11 ; i++ )
			{
				tempstr.Format ( "%c", m.vollabel[i] ) ;
				m_str[m_cnt] += tempstr ;
			}

			m_cnt++ ;
					
			m_str[m_cnt] = "File System Type : " ;

			for ( i = 0 ; i < 8 ; i++ )
			{
				tempstr.Format ( "%c", m.filesystype[i] ) ;
				m_str[m_cnt] += tempstr ;
			}

			m_cnt++ ;

			m_str[m_cnt].Format("Serial Number : %u",m.serialnumber) ;
		}
	}		
	
	Invalidate( ) ;
}

