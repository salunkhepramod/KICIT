// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "keypress.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildView

CChildView::CChildView()
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView,CWnd )
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), HBRUSH(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc (this ) ; // device context for painting
	
//	CRect r ;
//	GetClientRect (&r ) ;

	int i = 1 ;
	CString str ;

	if ( ::GetKeyState ( VK_SHIFT )  < 0 )
	{
		str = "Shift key is depressed" ;
		dc.TextOut ( 50 , 10 * i , str,
				str.GetLength( ) ) ;
		i += 2 ;
	}

	if ( ::GetKeyState ( VK_CONTROL ) < 0 )
	{
		str = "Control key is depressed" ;
		dc.TextOut ( 50 , 10 * i , str,
				str.GetLength( ) ) ;
		i += 2 ;
	}

	if ( ::GetKeyState ( VK_MENU ) < 0 )
	{
		str = "Alt key is depressed" ;
		dc.TextOut ( 50 , 10 * i , str, str.GetLength( ) ) ;
		i += 2 ;
	}

	if ( ::GetKeyState ( VK_NUMLOCK ) & 0x01 == 1 )
	{
		str = "Num Lock is On" ;
		dc.TextOut ( 50 , 10 * i , str, str.GetLength( ) ) ;
		i += 2 ;
	}

	if ( ::GetKeyState ( VK_NUMLOCK ) < 0 )
	{
		str = "Num Lock is currently depressed" ;
		dc.TextOut ( 50 , 10 * i , str, str.GetLength( ) ) ;
		i += 2 ;
	}

	if ( ::GetKeyState ( VK_CAPITAL ) & 0x01 == 1 )
	{
		str = "Caps Lock is On" ;
		dc.TextOut ( 50 , 10 * i , str, str.GetLength( ) ) ;
		i += 2 ;
	}

	if ( ::GetKeyState ( VK_CAPITAL ) < 0 )
	{
		str = "Caps Lock is currently depressed" ;
		dc.TextOut ( 50 , 10 * i , str,	str.GetLength( ) ) ;
		i += 2 ;
	}

	if ( ::GetKeyState ( VK_SCROLL ) & 0x01 == 1 < 0 )
	{
		str = "Scroll Lock is On" ;
		dc.TextOut ( 50 , 10 * i , str, str.GetLength( ) ) ;
		i += 2 ;
	}

	if ( ::GetKeyState ( VK_SCROLL ) < 0 )
	{
		str = "Scroll Lock is currently depressed" ;
		dc.TextOut ( 50 , 10 * i , str, str.GetLength( ) ) ;
		i += 2 ;
	}
}

