// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "shuffle.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildView

CChildView::CChildView()
{
	row = col = 3 ;
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView,CWnd )
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	ON_WM_KEYDOWN()
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), HBRUSH(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	drawgrid (&dc);
	printallnumbers (&dc);
}

int CChildView::check( )
{
	int b[4][4] = {
					1, 2, 3, 4,
					5, 6, 7, 8,
					9, 10, 11, 12,
					13, 14, 15,0,
				   } ;
	int i, j ;
		
	for ( i = 0 ; i <= 3 ; i++ )
	{
		for ( j = 0 ; j <= 3 ; j++ )
		{
			if( a[i][j] != b[i][j] )
				return ( 0 ) ;
		}
	}

	return ( 1 ) ;
}

void CChildView::drawgrid(CDC *p)
{
	CPen mypen ( PS_SOLID, 5, RGB ( 0, 0, 0 ) ) ;
	p -> SelectObject ( &mypen ) ;

	for ( int i = 78 ; i <= 238 ; i += 80 )
	{
		p -> MoveTo ( i, 0 ) ;
		p -> LineTo ( i, 320 ) ;
		p -> MoveTo ( 0, i ) ;
		p -> LineTo ( 320, i ) ;
	}
}

void CChildView::exchange(CDC *p, int zero_row, int zero_col, int num_row, int num_col)
{
	int print_zero_y, print_zero_x, print_num_y, print_num_x ;
///	char str[5] ;
	CString str ;

	print_zero_y = 39 + zero_row * 80 ;
	print_zero_x = 39 + zero_col * 80 ;
	
	print_num_y = 39 + num_row * 80 ;
	print_num_x = 39 + num_col * 80 ;

	p -> SetBkMode ( TRANSPARENT ) ;
	p -> SetTextColor ( RGB ( 0, 0, 0 ) ) ;

	p -> FillRect ( 
			&( CRect ( print_zero_x - 34, print_zero_y - 34, 
			print_zero_x + 34, print_zero_y + 34)), 
			&( CBrush ( RGB ( 192, 192, 192 ) ) ) ) ;
//	sprintf ( str, " ", a[num_row][num_col] ) ;
	str = " " ;
	p -> TextOut ( print_num_x - tm.tmAveCharWidth, 
	               print_num_y - tm.tmHeight / 2,
				   str, strlen ( str ) ) ;
			
	p -> FillRect ( 
	          &( CRect ( print_num_x - 34, print_num_y - 34, 
						print_num_x + 34, print_num_y + 34)), 
			  &( CBrush ( RGB ( 255, 255, 255 ) ) ) ) ;
	//sprintf ( str, "%2d", a[zero_row][zero_col] ) ;
	str.Format ( "%2d", a[zero_row][zero_col] ) ;
	p -> TextOut ( print_zero_x - tm.tmAveCharWidth, 
	               print_zero_y - tm.tmHeight / 2, 
				   str, strlen ( str ) ) ;
}

void CChildView::generate_random_nos()
{
	int i, j, n, equal ;
	int p[16] ;

	for ( i = 0 ; i <= 15 ; i++ )
		p[i] = 0 ;

	for ( i = 0 ; i <= 14 ; )
	{
		n = rand( ) % 16 ;

		if ( n == 0 )
			continue ;

		equal = 0 ;
		for ( j = 0 ; j < i ; j++ )
		{
			if ( p[j] == n )
			{
				equal = 1 ;
				break ;
			}
		}

		if ( equal != 1 )
		{
			p[i] = n ;
			i++ ;
		}
	}

	for( i = 0 ; i <= 3 ; i++ )
	{
		for( j = 0 ; j <= 3 ; j++ )
		{
			a[i][j] = p[i*4+j] ;
		}
	}
}

void CChildView::printallnumbers(CDC *p)
{
	CString str ;
	int i, j, r, c ; 
	
 	p->GetTextMetrics (&tm);
	p -> SetBkMode ( TRANSPARENT ) ;
	p -> SetTextColor ( RGB ( 0, 0, 0 ) ) ;

	for ( c = 0, i = 39 ; c <= 3 ; c++, i += 80 )
	{
		for ( r = 0, j = 39 ; r <= 3 ; r++, j += 80 )
		{
			if ( a[r][c] == 0 )
			{
				p -> FillRect ( 
	                 &( CRect ( i - 34, j - 34, i + 34, j + 34 ) ), 
					 &( CBrush ( RGB ( 255, 255, 255 ) ) ) ) ;
				str = " " ;
			}
			else
			{
				p -> FillRect ( 
			         &( CRect ( i - 34, j - 34, i + 34, j + 34)), 
					 &( CBrush ( RGB ( 192, 192, 192 ) ) ) ) ;
				str.Format ( "%2d ", a[r][c] ) ;
			}

			p -> TextOut ( i - tm.tmAveCharWidth, j - tm.tmHeight / 2, str, strlen ( str ) ) ;
		}
	}
}

void CChildView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	int t ;
	char str[50] ;
	static int count = 0 ;

	nFlags = ( nFlags << 24 ) >> 24 ;
	
	CClientDC d ( this ) ;
	switch ( nFlags )
	{
		case 80 :

			if ( row != 0 )
			{
				t = a[row][col] ;
				a[row][col] = a[row-1][col] ;
				a[row-1][col] = t ;
				exchange ( &d, row, col, row - 1, col ) ;
				row-- ;
				count++ ;
			}
			break ;
		
		case 72 :

			if ( row != 3 )
			{
				t = a[row][col] ;
				a[row][col] = a[row+1][col] ;
				a[row+1][col] = t ;
				exchange ( &d, row, col, row + 1, col ) ;
				row++ ;
				count++ ;
			}
			break ;
				
		case 75 :

			if ( col != 3 )
			{
				t = a[row][col] ;
				a[row][col] = a[row][col+1] ;
				a[row][col+1] = t ;
				exchange ( &d, row, col, row, col + 1 ) ;
				col++ ;
				count++ ;
			}
			break ;

		case 77 :

			if ( col != 0 )
			{
				t = a[row][col] ;
				a[row][col] = a[row][col-1] ;
				a[row][col-1] = t ;
				exchange ( &d, row, col, row, col - 1 ) ;
				col-- ;
				count++ ;
			}
			break ;

		default :
		   ::MessageBeep ( 1 ) ;
	}
		
	if ( check( ) == 1 )
	{
		sprintf ( str , 
			"You took %d move(s)\n to arrange numbers",
			count ) ;
		MessageBox ( str, "Game Over!" ) ;
		DestroyWindow( ) ;
	}
	
	CWnd ::OnKeyDown(nChar, nRepCnt, nFlags);
}

int CChildView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd ::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	generate_random_nos();

	return 0;
}
