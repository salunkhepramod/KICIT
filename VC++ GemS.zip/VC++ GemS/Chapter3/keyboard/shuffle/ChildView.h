// ChildView.h : interface of the CChildView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHILDVIEW_H__3DFDEA6A_B0CE_11D5_BFC8_0050BAD70AB6__INCLUDED_)
#define AFX_CHILDVIEW_H__3DFDEA6A_B0CE_11D5_BFC8_0050BAD70AB6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CChildView window

class CChildView : public CWnd
{
// Construction
public:
	CChildView();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChildView)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CChildView();
public:
	void printallnumbers(CDC *p);
	void generate_random_nos();
	void exchange(CDC *p, int zero_row, int zero_col, int num_row, int num_col);
	void drawgrid ( CDC *p );
	int check();

private:
	int a[4][4];
	int row,col;
	TEXTMETRIC tm;

	int zero_row,zero_col;
	int num_row,num_col;

	// Generated message map functions
protected:
	//{{AFX_MSG(CChildView)
	afx_msg void OnPaint();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHILDVIEW_H__3DFDEA6A_B0CE_11D5_BFC8_0050BAD70AB6__INCLUDED_)
