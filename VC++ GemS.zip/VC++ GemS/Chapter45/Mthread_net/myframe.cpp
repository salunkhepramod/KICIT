// myframe.cpp : implementation file
//

#include "stdafx.h"
#include "Mthread_net.h"
#include "myframe.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// myframe

IMPLEMENT_DYNCREATE(myframe, CFrameWnd)

myframe::myframe()
{
	Create ( 0, "View Thread" ) ;
}

myframe::~myframe()
{
}


BEGIN_MESSAGE_MAP(myframe, CFrameWnd)
	//{{AFX_MSG_MAP(myframe)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// myframe message handlers

int myframe::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	m_view = new myview ;
	m_view -> Create( 0, "", WS_CHILD | WS_VISIBLE | LVS_SMALLICON, rectDefault, this, AFX_IDW_PANE_FIRST ) ;

	return 0;
}

