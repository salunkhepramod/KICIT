//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Mthread_net.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MTHREAD_NET_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDR_MENU1                       130
#define IDC_BROWSE                      1000
#define IDC_LISTRES                     1003
#define ID_SMALL                        32772
#define ID_LARGE                        32773
#define ID_LIST                         32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
