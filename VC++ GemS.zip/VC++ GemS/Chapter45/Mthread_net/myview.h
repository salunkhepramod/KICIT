#if !defined(AFX_MYVIEW_H__130B5E8B_87F0_11D4_BFC3_0050BAD70AB6__INCLUDED_)
#define AFX_MYVIEW_H__130B5E8B_87F0_11D4_BFC3_0050BAD70AB6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// myview.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// myview view
#include <afxcview.h>

class myview : public CListView
{
public:
	myview();           // protected constructor used by dynamic creation
	void displayfiles(CString path) ;

	DECLARE_DYNCREATE(myview)

// Attributes
public:

// Operations
public:

	CString m_path;
	CImageList m_imglarge, m_imgsmall;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(myview)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~myview();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(myview)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDblclkItem(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYVIEW_H__130B5E8B_87F0_11D4_BFC3_0050BAD70AB6__INCLUDED_)
