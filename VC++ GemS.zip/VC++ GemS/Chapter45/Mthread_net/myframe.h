#if !defined(AFX_MYFRAME_H__377EE2AF_88A9_11D4_BFC3_0050BAD70AB6__INCLUDED_)
#define AFX_MYFRAME_H__377EE2AF_88A9_11D4_BFC3_0050BAD70AB6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// myframe.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// myframe frame
#include "myview.h"

class myframe : public CFrameWnd
{
	DECLARE_DYNCREATE(myframe)
public:
	myframe();           // protected constructor used by dynamic creation

private :
	myview *m_view ;
// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(myframe)
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~myframe();

	// Generated message map functions
	//{{AFX_MSG(myframe)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYFRAME_H__377EE2AF_88A9_11D4_BFC3_0050BAD70AB6__INCLUDED_)
