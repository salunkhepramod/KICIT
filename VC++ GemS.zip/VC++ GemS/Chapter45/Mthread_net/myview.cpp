// myview.cpp : implementation file
//

#include "stdafx.h"
#include "Mthread_net.h"
#include "myview.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// myview

extern CString m_filepath ;
IMPLEMENT_DYNCREATE(myview, CListView)

myview::myview()
{
}

myview::~myview()
{
}


BEGIN_MESSAGE_MAP(myview, CListView)
	//{{AFX_MSG_MAP(myview)
	ON_WM_CREATE()
	ON_NOTIFY_REFLECT(NM_DBLCLK, OnDblclkItem)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// myview drawing

void myview::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	pDC -> TextOut ( 10, 10, "Reached" ) ;
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// myview diagnostics

#ifdef _DEBUG
void myview::AssertValid() const
{
	CListView::AssertValid();
}

void myview::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// myview message handlers

void myview::OnInitialUpdate() 
{
	CListView::OnInitialUpdate();
}

int myview::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CListView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	m_imglarge.Create ( 32, 32, ILC_COLOR16 | ILC_MASK, 0, 10 ) ; 
	m_imgsmall.Create ( 16, 16, ILC_COLOR16 | ILC_MASK, 0, 10 ) ; 

	GetListCtrl( ).SetImageList ( &m_imglarge, LVSIL_NORMAL ) ;
	GetListCtrl( ).SetImageList ( &m_imgsmall, LVSIL_SMALL ) ;

	GetListCtrl( ).InsertColumn ( 0, "File Name", LVCFMT_LEFT, 150, 0 ) ;

	m_path = m_filepath ;
	displayfiles ( m_path ) ;

	return 0 ;
}

void myview::OnDblclkItem(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW *plist = ( NM_LISTVIEW* ) pNMHDR ;
	
	if ( m_path.GetAt ( m_path.GetLength( ) - 1 ) != '\\' )
		m_path += "\\" ;

	int item = plist -> iItem ;
	m_path += GetListCtrl( ).GetItemText ( item, 0 ) ;
	
	GetListCtrl( ).DeleteAllItems( ) ;

	displayfiles ( m_path ) ;
		
	*pResult = 0;
}

void myview::displayfiles(CString path)
{
	CFileFind fd ;
	int i = 0 ;
	
	if ( path.Right ( 1 ) != '\\' )
		path += "\\" ;

	path += "*.*" ;
	SHFILEINFO sh = { 0 } ;

	if ( fd.FindFile ( path ) == NULL )
		return ;

	BOOL f = fd.FindNextFile( ) ;
	
	while ( f )
	{
		f = fd.FindNextFile( ) ;
		if ( fd.IsDots( ) )
			continue ;

		SHGetFileInfo ( fd.GetFilePath( ), NULL, &sh, sizeof ( SHFILEINFO ), SHGFI_ICON ) ;
		int i = m_imglarge.Add ( sh.hIcon ) ;
		i = m_imgsmall.Add ( sh.hIcon ) ;
		GetListCtrl( ).InsertItem ( 0, fd.GetFileName( ), i ) ;
	}

	fd.Close( ) ;
}

