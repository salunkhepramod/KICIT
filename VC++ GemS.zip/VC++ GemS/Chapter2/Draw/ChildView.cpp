// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "Draw.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildView

CChildView::CChildView()
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView,CWnd )
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), HBRUSH(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	dc.MoveTo ( 10, 10 ) ;
	dc.LineTo ( 200, 10 ) ;

	CPen mypen ( PS_SOLID, 3, RGB( 0, 0, 255)) ;
	CPen *oldpen = dc.SelectObject ( &mypen ) ;
	dc.Rectangle ( 10, 20, 200, 100 ) ;
	dc.SelectObject ( oldpen ) ;

	mypen.DeleteObject( ) ;
	mypen.CreatePen ( PS_DOT, 1, RGB ( 0, 0, 255));
	oldpen = dc.SelectObject ( &mypen ) ;
	CBrush mybrush ( RGB( 255,0,0)) ;
	CBrush *oldbrush = dc.SelectObject ( &mybrush ) ;
	dc.RoundRect ( 10, 120, 200, 220, 20, 20 ) ;
	dc.SelectObject ( oldbrush ) ;
	dc.SelectObject ( oldpen ) ;
	
	mypen.DeleteObject( ) ;
	mypen.CreatePen ( PS_DASH, 1, RGB(0,0,255)) ;
	oldpen = dc.SelectObject ( &mypen ) ;
	mybrush.DeleteObject( ) ;
	mybrush.CreateHatchBrush ( HS_CROSS, RGB ( 255, 0, 255 ) ) ;
	oldbrush = dc.SelectObject ( &mybrush ) ;
	dc.Ellipse ( 10, 240, 200, 340 ) ;
	dc.SelectObject ( oldbrush ) ;
	dc.SelectObject ( oldpen ) ;

	mypen.DeleteObject( ) ;
	mypen.CreatePen ( PS_DOT, 1, RGB (0, 0, 255)) ;
	oldpen = dc.SelectObject ( &mypen ) ;
	CBitmap mybitmap ;
	mybitmap.LoadBitmap ( IDB_BITMAP1 ) ;
	mybrush.DeleteObject( ) ;
	mybrush.CreatePatternBrush ( &mybitmap ) ;
	oldbrush = dc.SelectObject ( &mybrush ) ;
	dc.Pie ( 250, 10, 350, 110, 350, 110, 350, 10 ) ;

	oldpen = ( CPen* ) dc.SelectStockObject ( WHITE_PEN ) ;
	oldbrush = ( CBrush* ) dc.SelectStockObject ( NULL_BRUSH ) ;

	POINT pt[5] = { 250, 150, 250, 300, 300, 350, 400, 300, 320, 190 } ;  
	dc.Polygon ( pt, 5 ) ;
	dc.SelectObject ( oldpen ) ;
	dc.SelectObject ( oldbrush ) ;

	CRect r ;
	GetClientRect ( &r ) ;
	dc.TextOut ( 100, 200, "Raindrops on roses & whiskers on kittens", strlen ( "Raindrop on roses & whiskers on kittens" ) ) ;
	dc.DrawText ( "Of Words'n Figures", -1, &r, DT_SINGLELINE | DT_VCENTER | DT_CENTER ) ;
	
	// Do not call CWnd::OnPaint() for painting messages
}


BOOL CChildView::OnEraseBkgnd(CDC* pDC) 
{
	CBrush mybrush ( RGB ( 0, 125, 0 ) ) ;
	CRect r ;
	GetClientRect ( &r ) ;
	pDC -> FillRect ( &r, &mybrush ) ;
	return TRUE ;
		
//	return CWnd ::OnEraseBkgnd(pDC);
}
