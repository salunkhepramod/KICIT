// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "paletteanimation.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildView
BYTE CChildView::m_colors[10][3] = 
							{
								255, 255, 255,
								0, 0, 0 ,
								160, 160, 128,  
								192, 192, 255,
								255, 160, 128,
								255, 204, 102,
								255, 255, 153,
								255, 255, 102,
								255, 255, 51,
								255, 255, 0,
							};


CChildView::CChildView()
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView,CWnd )
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	ON_WM_CREATE()
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), HBRUSH(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc ( this ) ; 

	if ( m_palette.m_hObject == NULL )
		return ;

	CPalette *old_palette ;
	old_palette = dc.SelectPalette ( &m_palette, FALSE ) ;

	dc.RealizePalette( ) ;

	m_memdc.SelectObject ( &m_bitmap ) ;
	
	dc.StretchBlt ( 0, 0, m_x, m_y, &m_memdc, 0, 0, 600, 400, SRCCOPY ) ;

	dc.SelectPalette ( old_palette, FALSE ) ;
}


int CChildView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd ::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	HBITMAP hbitmap = ( HBITMAP )::LoadImage ( AfxGetInstanceHandle( ), 
					  ( LPCTSTR ) "colorbulb.bmp", IMAGE_BITMAP, 0, 0, 
					LR_LOADFROMFILE | LR_CREATEDIBSECTION ) ;

	m_bitmap.Attach ( hbitmap ) ;

	if ( ( ( HBITMAP ) m_bitmap ) != NULL )
	{
		CClientDC d ( this ) ;

		if ( ( d.GetDeviceCaps ( RASTERCAPS ) & 
								RC_PALETTE ) == 0 )
		{
			MessageBox ( "Palette not suppored by this device\nChange Settings", "Sorry" ) ;
			return 0 ;
		}

		struct 
		{
			LOGPALETTE lp ;
			PALETTEENTRY ape[10] ;
		} pal ;

		LOGPALETTE *lp = ( LOGPALETTE * ) &pal ;
		lp -> palVersion = 0x300 ; 
		lp -> palNumEntries = 10;

		for ( int i = 0 ; i < 10 ; i++ )
		{
			lp -> palPalEntry[i].peRed = m_colors[i][0] ;
			lp -> palPalEntry[i].peGreen = m_colors[i][1] ;
			lp -> palPalEntry[i].peBlue = m_colors[i][2] ;
			lp -> palPalEntry[i].peFlags = PC_RESERVED ;
		}

		m_palette.CreatePalette ( lp ) ;

		m_memdc.CreateCompatibleDC ( &d ) ;
	}

	SetTimer ( 1, 550, NULL ) ;
			
	return 0;
}

void CChildView::OnTimer(UINT nIDEvent) 
{
	PALETTEENTRY pal[5] ;
	m_palette.GetPaletteEntries ( 9, 1, &pal[0] ) ;
	m_palette.GetPaletteEntries ( 5, 4, &pal[1] ) ;  
	m_palette.AnimatePalette ( 5, 5, pal ) ;

	CWnd ::OnTimer(nIDEvent);
}

void CChildView::OnDestroy() 
{
	KillTimer ( 1 ) ;	
	
	CWnd ::OnDestroy();	
}

void CChildView::OnSize(UINT nType, int cx, int cy) 
{
	CWnd ::OnSize(nType, cx, cy);
	
	m_x = cx ;
	m_y = cy ;
}
