// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "fileproperties.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_SETFOCUS()
	ON_COMMAND(ID_FILEDIALOG, OnFiledialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	// create a view to occupy the client area of the frame
	if (!m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW,
		CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL))
	{
		TRACE0("Failed to create view window\n");
		return -1;
	}
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(0);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers
void CMainFrame::OnSetFocus(CWnd* pOldWnd)
{
	// forward focus to the view window
	m_wndView.SetFocus();
}

BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// let the view have first crack at the command
	if (m_wndView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	// otherwise, do default handling
	return CFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}


void CMainFrame::OnFiledialog() 
{
	CString filename ,creat, modify,access ;
	CString	info, str1, str2, str3, str4 ;
	CFileStatus fs ;

	CFileDialog d ( TRUE, NULL, NULL, NULL, "All Files|*.*||" ) ;
	if ( d.DoModal( ) == IDOK )
		filename = d.GetPathName( ) ;

	CFile::GetStatus ( filename, fs ) ;
	CTime cre, mod, acc ;

	cre = fs.m_ctime ;
	CString daystring ;

	int day = cre.GetDayOfWeek( ) ;
	daystring = getdaystring ( day ) ;
			
	creat.Format ( "Creation Day & Date :- %s  %d : %d : %d  \
					 Creation Time :- %d : %d : %d ",
					daystring, cre.GetDay( ), cre.GetMonth( ),
					cre.GetYear( ), cre.GetHour( ), cre.GetMinute( ), 
					cre.GetSecond( ) ) ;

	mod = fs.m_mtime ;
	day = mod.GetDayOfWeek( ) ;
	daystring = getdaystring ( day ) ;
	modify.Format ( "Modified Day & Date :-%s %d : %d : %d  \nModified Time :-%d : %d : %d ", daystring, 
					 mod.GetDay( ), mod.GetMonth( ), 
					 mod.GetYear( ) , mod.GetHour( ), 
					 mod.GetMinute( ), mod.GetSecond( ) ) ;

	acc = fs.m_atime ;
	day = acc.GetDayOfWeek( ) ;
	daystring = getdaystring ( day ) ;
	access.Format("Accessed Day & Date :- %s %d : %d : %d ",
				   daystring, acc.GetDay( ), acc.GetMonth( ), 
				   acc.GetYear( ) ) ;
			
	str1 = str2 = str3 = str4 = "NO" ;

	if ( ( fs.m_attribute & 0x01 ) == 0x01 )
		str1 = "YES" ;

	if ( ( fs.m_attribute & 0x02 ) == 0x02 )
		str2 = "YES" ;

	if ( ( fs.m_attribute & 0x04 ) == 0x04 )
		str3 = "YES" ;

	if ( ( fs.m_attribute & 0x20 ) == 0x20 )
		str4 = "YES" ;

	info.Format ( "FileName=%s \n\nSize = %ld bytes \
				   \n\nReadOnly = %s  \n\nHidden = %s \
				   \n\nSystem = %s \n\nArchive = %s \n\n%s \n\n%s \n\n%s", fs.m_szFullName, fs.m_size, str1, 
				   str2, str3, str4, creat, modify, access ) ;

	MessageBox ( info ) ;	
}

CString CMainFrame::getdaystring(int day)
{
	CString str ;
	switch ( day )
	{
		case 1 : 
			str = "Sunday" ;
			break ;
		case 2 : 
			str = "Monday" ;
			break ;
		case 3 : 
			str = "Tuesday" ;
			break ;
		case 4 : 
			str = "Wednesday" ;
			break ;
		case 5 : 
			str = "Thursday" ;
			break ;
		case 6 : 
			str = "Friday" ;
			break ;
		case 7 : 
			str = "Saturday" ;
			break ;
	}
	return str ;
}
