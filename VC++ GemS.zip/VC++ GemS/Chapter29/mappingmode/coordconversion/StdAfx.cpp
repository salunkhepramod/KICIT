// stdafx.cpp : source file that includes just the standard includes
//	coordconversion.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"



