// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "shiftorigin.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildView

CChildView::CChildView()
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView,CWnd )
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), HBRUSH(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	CRect r ; 
	GetClientRect ( &r ) ;

	dc.SetViewportOrg ( r.right / 2, r.bottom / 2 ) ;

	dc.MoveTo ( r.right / 2, 0 ) ;
	dc.LineTo ( r.right / 2, r.bottom ) ;

	dc.MoveTo ( 0, r.bottom / 2 ) ;
	dc.LineTo ( r.right, r.bottom / 2 ) ;

	dc.SetMapMode ( MM_LOENGLISH ) ;

	dc.SetPixel ( 10 , 10 , RGB ( 255 , 0 , 0 ) ) ;
	dc.SetPixel ( 10 , -10 , RGB ( 255 , 0 , 0 ) ) ;
	dc.SetPixel ( -10 , -10 , RGB ( 255 , 0 , 0 ) ) ;
	dc.SetPixel ( -10 , 10 , RGB ( 255 , 0 , 0 ) ) ;
}

