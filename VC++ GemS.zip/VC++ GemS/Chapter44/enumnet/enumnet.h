// enumnet.h : main header file for the ENUMNET application
//

#if !defined(AFX_ENUMNET_H__7B286BC4_7D96_11D4_BFC3_0050BAD70AB6__INCLUDED_)
#define AFX_ENUMNET_H__7B286BC4_7D96_11D4_BFC3_0050BAD70AB6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CEnumnetApp:
// See enumnet.cpp for the implementation of this class
//

class CEnumnetApp : public CWinApp
{
public:
	CEnumnetApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEnumnetApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CEnumnetApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ENUMNET_H__7B286BC4_7D96_11D4_BFC3_0050BAD70AB6__INCLUDED_)
