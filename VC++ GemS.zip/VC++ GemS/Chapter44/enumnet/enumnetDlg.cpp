// enumnetDlg.cpp : implementation file
//

#include "stdafx.h"
#include "enumnet.h"
#include "enumnetDlg.h"

#include "winnetwk.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

CListCtrl CEnumnetDlg::m_listres ;
CString CEnumnetDlg::getdisplaytype(DWORD) ;
UINT enumnet ( LPVOID param ) ;

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEnumnetDlg dialog

CEnumnetDlg::CEnumnetDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEnumnetDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEnumnetDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CEnumnetDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEnumnetDlg)
	DDX_Control(pDX, IDC_LISTRES, m_listres);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CEnumnetDlg, CDialog)
	//{{AFX_MSG_MAP(CEnumnetDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CONNECT, OnConnect)
	ON_BN_CLICKED(IDC_DISCONNECT, OnDisconnect)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEnumnetDlg message handlers

BOOL CEnumnetDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	m_listres.InsertColumn ( 0, "Remote Name", LVCFMT_LEFT, 160, 0 ) ;
	m_listres.InsertColumn ( 1, "Comment", LVCFMT_LEFT, 150, 0 ) ;
	m_listres.InsertColumn ( 2, "Display Type", LVCFMT_LEFT, 100, 0 ) ;
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CEnumnetDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CEnumnetDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CEnumnetDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CEnumnetDlg::OnConnect() 
{
	if ( WNetConnectionDialog ( m_hWnd, RESOURCETYPE_DISK ) == NO_ERROR )
			MessageBox ( "Drive Mapped" ) ;
}

void CEnumnetDlg::OnDisconnect() 
{
	if ( WNetDisconnectDialog ( m_hWnd, RESOURCETYPE_DISK ) == NO_ERROR )
		MessageBox ( "Drive Disconnected" ) ;
}

void CEnumnetDlg::OnBrowse() 
{
	m_pthread = AfxBeginThread ( enumnet, NULL ) ;
}

UINT enumnet ( LPVOID param )
{
	LPNETRESOURCE lpnr = ( LPNETRESOURCE ) param ;
	HANDLE h ;
	DWORD cn = 0xFFFFFFFF, s = 16384 ;
	LPNETRESOURCE nr ;
	static int item = 0 ;

	int res = WNetOpenEnum ( RESOURCE_GLOBALNET, RESOURCETYPE_ANY, 0, lpnr, &h ) ;
	nr = (LPNETRESOURCE) new char[s] ;

	do
	{
		res =  WNetEnumResource ( h, &cn, nr, &s ) ;

		if ( res == NO_ERROR )
		{
			for ( int i = 0 ; i <= cn ; i++ )
			{
				if ( nr[i].dwType != RESOURCEDISPLAYTYPE_GENERIC )
				{
					CEnumnetDlg::m_listres.InsertItem ( item, nr[i].lpRemoteName ) ;
					
					CString comment = nr[i].lpComment ;
					if ( comment == "" )
						comment = "None" ;

					CEnumnetDlg::m_listres.SetItemText ( item, 1, comment ) ;

					CString distype = CEnumnetDlg::getdisplaytype ( nr[i].dwDisplayType ) ;
					CEnumnetDlg::m_listres.SetItemText ( item, 2, distype ) ;

					item++ ;
				}
				if ( RESOURCEUSAGE_CONTAINER == 
					( nr[i].dwUsage & RESOURCEUSAGE_CONTAINER ) ) 
					enumnet ( &nr[i] ) ;
			}
		}
		
	} while ( res == ERROR_NO_MORE_ITEMS ) ;

	WNetCloseEnum ( h ) ;

	return 0 ;
}

CString CEnumnetDlg::getdisplaytype(DWORD type)
{
	CString str ;
	switch ( type )
	{
		case RESOURCEDISPLAYTYPE_DOMAIN :
			str = "Domain" ; 
			break ;
		case RESOURCEDISPLAYTYPE_SERVER :
			str = "Container" ;
			break ;
		case RESOURCEDISPLAYTYPE_SHARE :
			str = "Share" ;
	}

	return str ;
}

