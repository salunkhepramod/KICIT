// enumnetDlg.h : header file
//

#if !defined(AFX_ENUMNETDLG_H__7B286BC6_7D96_11D4_BFC3_0050BAD70AB6__INCLUDED_)
#define AFX_ENUMNETDLG_H__7B286BC6_7D96_11D4_BFC3_0050BAD70AB6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CEnumnetDlg dialog


class CEnumnetDlg : public CDialog
{
// Construction
public:
	static CString getdisplaytype ( DWORD type );
	CEnumnetDlg(CWnd* pParent = NULL);	// standard constructor
	static CListCtrl	m_listres;

// Dialog Data
	//{{AFX_DATA(CEnumnetDlg)
	enum { IDD = IDD_ENUMNET_DIALOG };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEnumnetDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CEnumnetDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnConnect();
	afx_msg void OnDisconnect();
	afx_msg void OnBrowse();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CWinThread* m_pthread;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ENUMNETDLG_H__7B286BC6_7D96_11D4_BFC3_0050BAD70AB6__INCLUDED_)
