//{{AFX_INCLUDES()
#include "activemovie3.h"
//}}AFX_INCLUDES
#if !defined(AFX_MOVIEDLG_H__2030BCCB_E29F_4080_A557_28D59C6227C5__INCLUDED_)
#define AFX_MOVIEDLG_H__2030BCCB_E29F_4080_A557_28D59C6227C5__INCLUDED_

#include "activemovie3.h"	// Added by ClassView

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MovieDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMovieDlg dialog

class CMovieDlg : public CDialog
{
// Construction
public:
	CMovieDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMovieDlg)
	enum { IDD = IDD_MOVIE };
	CActiveMovie3	m_amovie;
	//}}AFX_DATA
	CString fname;
	double length;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMovieDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMovieDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnOpenCompleteActivemoviecontrol1();
	afx_msg void OnTimerActivemoviecontrol1();
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void OnCancel();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MOVIEDLG_H__2030BCCB_E29F_4080_A557_28D59C6227C5__INCLUDED_)
