// MovieDlg.cpp : implementation file
//

#include "stdafx.h"
#include "mycdplayer.h"
#include "MovieDlg.h"

#include "mycdplayerdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMovieDlg dialog


CMovieDlg::CMovieDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMovieDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMovieDlg)
	//}}AFX_DATA_INIT
}


void CMovieDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMovieDlg)
	DDX_Control(pDX, IDC_ACTIVEMOVIECONTROL1, m_amovie);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMovieDlg, CDialog)
	//{{AFX_MSG_MAP(CMovieDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMovieDlg message handlers

BOOL CMovieDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_amovie.SetAutoStart(FALSE);
	m_amovie.SetAllowChangeDisplayMode(TRUE);
	m_amovie.SetEnablePositionControls(FALSE);
	m_amovie.SetAutoRewind(FALSE);
	m_amovie.SetShowControls(FALSE);
	m_amovie.SetShowTracker(FALSE);
	m_amovie.SetShowPositionControls(FALSE);
	CMycdplayerDlg* p=(CMycdplayerDlg*)AfxGetMainWnd();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CMovieDlg::OnCancel()
{
	long int status=m_amovie.GetCurrentState();
	if(status==2 || status ==1)
	{
		m_amovie.Stop();
		
	}
	CMycdplayerDlg* p=(CMycdplayerDlg*)AfxGetMainWnd();
	p->m_prog2.SetPos(0);
	p->m_static2.SetWindowText("00:00:00");
	CDialog::OnCancel();
}


BEGIN_EVENTSINK_MAP(CMovieDlg, CDialog)
    //{{AFX_EVENTSINK_MAP(CMovieDlg)
	ON_EVENT(CMovieDlg, IDC_ACTIVEMOVIECONTROL1, 50 /* OpenComplete */, OnOpenCompleteActivemoviecontrol1, VTS_NONE)
	ON_EVENT(CMovieDlg, IDC_ACTIVEMOVIECONTROL1, 3 /* Timer */, OnTimerActivemoviecontrol1, VTS_NONE)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()


void CMovieDlg::OnOpenCompleteActivemoviecontrol1() 
{
	// TODO: Add your control notification handler code here
	int wd = m_amovie.GetImageSourceWidth();
	int ht = m_amovie.GetImageSourceHeight();
	ht+=GetSystemMetrics(SM_CYCAPTION)+6;
	SetWindowPos(&wndTopMost,0,0,wd,ht,SWP_FRAMECHANGED);
	SetWindowText(fname+" - mycdplayer");
	length=m_amovie.GetDuration();
	CMycdplayerDlg* p=(CMycdplayerDlg*)AfxGetMainWnd();
	p->m_prog2.SetRange(0,(int)length);
	p->m_prog2.SetStep(1);
	m_amovie.Run();
}

void CMovieDlg::OnTimerActivemoviecontrol1() 
{
	// TODO: Add your control notification handler code here
	double pos=m_amovie.GetCurrentPosition();
	int npos=(int)pos;
	CMycdplayerDlg* p=(CMycdplayerDlg*)AfxGetMainWnd();
	p->m_prog2.SetPos(npos);
	
	CString str;
	str.Format("00:%02d:%02d",npos/60,npos%60);
	p->m_static2.SetWindowText(str);
	
}
