// mycdplayerDlg.h : header file
//

#if !defined(AFX_MYCDPLAYERDLG_H__720729DF_26A8_4C4F_99E2_52E38A6FB8FA__INCLUDED_)
#define AFX_MYCDPLAYERDLG_H__720729DF_26A8_4C4F_99E2_52E38A6FB8FA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "mci.h"	// Added by ClassView
#include "MovieDlg.h"	// Added by ClassView
#include "mytooltipctrl.h"

/////////////////////////////////////////////////////////////////////////////
// CMycdplayerDlg dialog

class CMycdplayerDlg : public CDialog
{
// Construction
public:
	CMovieDlg m_moviedlg;
	CMycdplayerDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMycdplayerDlg)
	enum { IDD = IDD_MYCDPLAYER_DIALOG };
	CStatic	m_static2;
	CStatic	m_static1;
	CSpinButtonCtrl	m_spin1;
	CSliderCtrl	m_slider1;
	CProgressCtrl	m_prog2;
	CProgressCtrl	m_prog1;
	int		m_edit1;
	int		m_volume;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMycdplayerDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMycdplayerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg UINT OnNcHitTest(CPoint point);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnPlaytrk();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnCustomdrawSlider1(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	bool filesel;
	bool timeractive;
	Cmci m_audio;
	CBitmapButton m_power,m_minimize,m_about,m_vbutton[8],m_abutton[8];
	mytooltipctrl tip;
	void audioevent(int id);
	void videoevent(int id);
	void onabout();
	void onminimize();
	void onpower();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYCDPLAYERDLG_H__720729DF_26A8_4C4F_99E2_52E38A6FB8FA__INCLUDED_)
