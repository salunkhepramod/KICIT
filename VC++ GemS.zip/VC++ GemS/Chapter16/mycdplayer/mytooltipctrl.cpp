// mytooltipctrl.cpp : implementation file
//

#include "stdafx.h"
#include "mycdplayer.h"
#include "mytooltipctrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// mytooltipctrl

mytooltipctrl::mytooltipctrl()
{
}

mytooltipctrl::~mytooltipctrl()
{
}

BEGIN_MESSAGE_MAP(mytooltipctrl, CToolTipCtrl)
	//{{AFX_MSG_MAP(mytooltipctrl)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// mytooltipctrl message handlers
int mytooltipctrl::addtool(CWnd *pwnd, LPCTSTR text)
{
	TOOLINFO ti;
	ti.cbSize=sizeof(TOOLINFO);
	ti.lpszText=(LPTSTR)text;
	ti.hinst=AfxGetInstanceHandle();
	ti.hwnd=pwnd->GetParent()->GetSafeHwnd();
	ti.uFlags=TTF_SUBCLASS | TTF_IDISHWND;
	ti.uId=(UINT)pwnd->GetSafeHwnd();
	return (int) SendMessage(TTM_ADDTOOL,0,(LPARAM)&ti);
}
