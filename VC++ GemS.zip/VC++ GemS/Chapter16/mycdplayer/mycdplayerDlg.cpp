// mycdplayerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "mycdplayer.h"
#include "mycdplayerDlg.h"
#include <mmsystem.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// macro defines
#define ID_POWER	10
#define ID_MINIMIZE	11
#define ID_ABOUT	12

#define ID_AEJECT	13
#define ID_APLAY	14
#define ID_APAUSE	15
#define ID_ASTOP	16
#define ID_APREV	17
#define ID_AREV 	18
#define ID_AFORW	19
#define ID_ANEXT	20

#define ID_VEJECT	21
#define ID_VPLAY	22
#define ID_VPAUSE	23
#define ID_VSTOP	24
#define ID_VPREV	25
#define ID_VREV 	26
#define ID_VFORW	27
#define ID_VNEXT	28

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMycdplayerDlg dialog

CMycdplayerDlg::CMycdplayerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMycdplayerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMycdplayerDlg)
	m_edit1 = 0;
	m_volume = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMycdplayerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMycdplayerDlg)
	DDX_Control(pDX, IDC_STATIC2, m_static2);
	DDX_Control(pDX, IDC_STATIC1, m_static1);
	DDX_Control(pDX, IDC_SPIN1, m_spin1);
	DDX_Control(pDX, IDC_SLIDER1, m_slider1);
	DDX_Control(pDX, IDC_PROGRESS2, m_prog2);
	DDX_Control(pDX, IDC_PROGRESS1, m_prog1);
	DDX_Text(pDX, IDC_EDIT1, m_edit1);
	DDX_Slider(pDX, IDC_SLIDER1, m_volume);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMycdplayerDlg, CDialog)
	//{{AFX_MSG_MAP(CMycdplayerDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_NCHITTEST()
	ON_WM_ERASEBKGND()
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_PLAYTRACK, OnPlaytrk)
	ON_WM_TIMER()
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER1, OnCustomdrawSlider1)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_POWER,onpower)
	ON_COMMAND(ID_MINIMIZE,onminimize)
	ON_COMMAND(ID_ABOUT,onabout)
	ON_COMMAND_RANGE(ID_VEJECT,ID_VNEXT,videoevent)
	ON_COMMAND_RANGE(ID_AEJECT,ID_ANEXT,audioevent)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMycdplayerDlg message handlers

BOOL CMycdplayerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	SetWindowText("mycdplayer");
	timeractive = 0;

	tip.Create(this);

	m_power.Create("",WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,CRect(4,11,46,24),this,ID_POWER);
	m_power.LoadBitmaps(IDB_POWER1,IDB_POWER2);
	tip.addtool(&m_power,"Power Off (Exit mycdplayer)");

	m_minimize.Create("",WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,CRect(4,29,46,42),this,ID_MINIMIZE);
	m_minimize.LoadBitmaps(IDB_MINIMIZE1,IDB_MINIMIZE2); 
	tip.addtool(&m_minimize,"Minimize");

	m_about.Create("",WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,CRect(4,47,46,173+47),this,ID_ABOUT);
	m_about.LoadBitmaps(IDB_ABOUT1,IDB_ABOUT2); 
	tip.addtool(&m_about,"About Multimedia Player");

	for(int i=0;i<8;++i)
	{
		m_abutton[i].Create("",WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,CRect(38*i+67,24,38*i+67+38,30+24),this,ID_AEJECT+i);
		m_vbutton[i].Create("",WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,CRect(38*i+67,137,38*i+67+38,30+137),this,ID_VEJECT+i);
		
	}
	
	// audio buttons
	m_abutton[0].LoadBitmaps(IDB_EJECT1,IDB_EJECT2);
	tip.addtool(&m_abutton[0],"Eject");

	m_abutton[1].LoadBitmaps(IDB_PLAY1,IDB_PLAY2);
	tip.addtool(&m_abutton[1],"Play");

	m_abutton[2].LoadBitmaps(IDB_PAUSE1,IDB_PAUSE2);
	tip.addtool(&m_abutton[2],"Pause");

	m_abutton[3].LoadBitmaps(IDB_STOP1,IDB_STOP2);
	tip.addtool(&m_abutton[3],"Stop");

	m_abutton[4].LoadBitmaps(IDB_PREV1,IDB_PREV2);
	tip.addtool(&m_abutton[4],"Previous Track");

	m_abutton[5].LoadBitmaps(IDB_REV1,IDB_REV2);
	tip.addtool(&m_abutton[5],"Rewind 10 sec");

	m_abutton[6].LoadBitmaps(IDB_FORW1,IDB_FORW2);
	tip.addtool(&m_abutton[6],"Forward 10 sec");

	m_abutton[7].LoadBitmaps(IDB_NEXT1,IDB_NEXT2);
	tip.addtool(&m_abutton[7],"Next Track");
	
	// video buttons
	m_vbutton[0].LoadBitmaps(IDB_EJECT1,IDB_EJECT2);
	tip.addtool(&m_vbutton[0],"Eject");

	m_vbutton[1].LoadBitmaps(IDB_PLAY1,IDB_PLAY2);
	tip.addtool(&m_vbutton[1],"Play");

	m_vbutton[2].LoadBitmaps(IDB_PAUSE1,IDB_PAUSE2);
	tip.addtool(&m_vbutton[2],"Pause");

	m_vbutton[3].LoadBitmaps(IDB_STOP1,IDB_STOP2);
	tip.addtool(&m_vbutton[3],"Stop");
	
	m_vbutton[4].LoadBitmaps(IDB_PREV1,IDB_PREV2);
	tip.addtool(&m_vbutton[4],"Previous Track");

	m_vbutton[5].LoadBitmaps(IDB_REV1,IDB_REV2);
	tip.addtool(&m_vbutton[5],"Rewind 10 sec");

	m_vbutton[6].LoadBitmaps(IDB_FORW1,IDB_FORW2);
	tip.addtool(&m_vbutton[6],"Forward 10 sec");

	m_vbutton[7].LoadBitmaps(IDB_NEXT1,IDB_NEXT2);
	tip.addtool(&m_vbutton[7],"Next Track");


	// audio settings
	m_audio.Create("",WS_CHILD,CRect(10,10,100,100),this,1,0);
	m_audio.SetDeviceType("cdaudio");
	m_audio.SetCommand("open");
	/*
	if(m_audio.GetError()!=0)
	{
		MessageBox("CD ROM drive is not present\nor it is currently not available!!","Error - mycdplayer",MB_OK | MB_ICONSTOP);
		OnCancel();
	}*/
	m_audio.SetTimeFormat(10L); // mciFormatTmsf
	m_audio.SetCommand("stop");
	int maxtrk=(int)m_audio.GetTracks();
	m_spin1.SetRange ( 1, maxtrk ) ; 
	m_spin1.SetPos ( 1 ) ;

	m_prog1.SetStep(1);
	tip.addtool(&m_prog1,"Progress Bar");

	//video settings
	m_moviedlg.Create(IDD_MOVIE,this);

	m_prog2.SetStep(1);
	tip.addtool(&m_prog2,"Progress Bar");

	m_slider1.SetRange(-3500,0,FALSE);

	tip.addtool(&m_slider1,"Volume Control");

	
	m_prog1.SendMessage(PBM_SETBARCOLOR,0,RGB(255,0,0));
	m_prog1.SendMessage(PBM_SETBKCOLOR,0,RGB(255,255,0));

	m_prog2.SendMessage(PBM_SETBARCOLOR,0,RGB(255,0,0));
	m_prog2.SendMessage(PBM_SETBKCOLOR,0,RGB(255,255,0));

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMycdplayerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMycdplayerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMycdplayerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

UINT CMycdplayerDlg::OnNcHitTest(CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	UINT hittest=CDialog::OnNcHitTest(point);
	switch(hittest)
	{
	case HTCLIENT:
		hittest=HTCAPTION;
	}
	return hittest;
}

BOOL CMycdplayerDlg::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	CBitmap mybitmap;
	mybitmap.LoadBitmap(IDB_TEXTURE);
	CDC mymemdc;
	mymemdc.CreateCompatibleDC(pDC);
	mymemdc.SelectObject(&mybitmap);

	CRect r;
	GetClientRect(&r);

	for(int x=0;x<=r.right;x+=128)
		for(int y=0;y<=r.bottom;y+=128)
			pDC->BitBlt(x,y,128,128,&mymemdc,0,0,SRCCOPY);

	return 1;
}

HBRUSH CMycdplayerDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	// TODO: Change any attributes of the DC here
		
	// TODO: Return a different brush if the default is not desired
	
	int ctrlid=pWnd->GetDlgCtrlID ( ) ;
	switch(ctrlid)
	{
	case IDC_STATIC1:
	case IDC_STATIC2:
	case IDC_EDIT1:
		pDC->SetBkMode(TRANSPARENT);
		pDC->SetTextColor(RGB(222,0,0));
		break;
	}
	CString title;
	pWnd->GetWindowText(title);
	if(title=="Audio CD" || title == "Video CD")
	{
		pDC->SetBkMode(RGB(0,0,0));
		pDC->SetTextColor(RGB(255,0,0));
	}
	hbr=CreateSolidBrush(RGB(255,255,0));
	return hbr;
}

void CMycdplayerDlg::onpower()
{
	OnOK();
}

void CMycdplayerDlg::onminimize()
{
	ShowWindow(2);
}

void CMycdplayerDlg::onabout()
{
	CAboutDlg d;
	d.DoModal();
}

void CMycdplayerDlg::audioevent(int id)
{
	int maxtrk;
	long apos;
	switch(id)
	{
	case ID_AEJECT:
		m_audio.SetCommand("eject");
		m_prog1.SetPos(0);
		Sleep(2000);
		maxtrk = m_audio.GetTracks();
		m_spin1.SetRange(1,maxtrk);
		break;

	case ID_APLAY:
		m_audio.SetCommand("play");
		if(timeractive==0)
		{
			SetTimer(1,1000,NULL);
			timeractive=1;
		}
		break;
	
	case ID_APAUSE:
		m_audio.SetCommand("pause");
		break;
	
	case ID_ASTOP:
		m_audio.SetCommand("stop");
		KillTimer(1);
		timeractive=0;
		break;
	
	case ID_APREV:
		m_audio.SetCommand("prev");
		break;
	
	case ID_AREV:
		m_audio.SetTimeFormat(0);
		apos=m_audio.GetPosition();
		apos-=10000;
		if(apos==0)
			apos=0;
		m_audio.SetFrom(apos);
		m_audio.SetCommand("play");
		m_audio.SetTimeFormat(10);
		
		break;
	
	case ID_AFORW:
		m_audio.SetTimeFormat(0);
		apos=m_audio.GetPosition();
		apos+=10000;
		m_audio.SetFrom(apos);
		m_audio.SetCommand("play");
		m_audio.SetTimeFormat(10);
		break;
	
	case ID_ANEXT:
		m_audio.SetCommand("next");
		break;
	}
}


void CMycdplayerDlg::OnPlaytrk() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	m_audio.SetFrom(m_edit1);
	m_audio.SetCommand("Play");
	if(timeractive==0)
		SetTimer(1,1000,NULL);	
}


void CMycdplayerDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	m_audio.SetTimeFormat(0L);
	m_audio.SetTrack(m_audio.GetTrack());
	int len=m_audio.GetTrackLength();
	m_prog1.SetRange(0,len/1000);
			
	m_audio.SetTimeFormat(10L);
	int apos=m_audio.GetPosition();
	int trk=MCI_TMSF_TRACK((DWORD)apos);
	int min=MCI_TMSF_MINUTE((DWORD)apos);
	int sec=MCI_TMSF_SECOND((DWORD)apos);
	
	m_prog1.SetPos(min*60+sec);	

	CString str;
	str.Format("%02d:%02d:%02d",trk,min,sec);
	m_static1.SetWindowText(str);
	
	CDialog::OnTimer(nIDEvent);
}



void CMycdplayerDlg::videoevent(int id)
{
	CString filespec="Movie Files(*.mpeg;*.mpg)|*.mpeg;*.mpg|Quick Time(*.mov;*.qt)|*.mov;*.qt|Video Files(*.avi)|*.avi|All Files|*.*||";
	CFileDialog fd(1,0,0,OFN_HIDEREADONLY | OFN_FILEMUSTEXIST ,filespec);
	
	long status=m_moviedlg.m_amovie.GetCurrentState();
	double pos=m_moviedlg.m_amovie.GetCurrentPosition();
	
	switch(id)
	{
	
		case ID_VPLAY:
		if(filesel==1)
		{
			m_moviedlg.m_amovie.SetFileName(m_moviedlg.fname);
			m_moviedlg.ShowWindow(3);
			
		}
		break;

	case ID_VEJECT:

	//fd.m_ofn.lpstrTitle="
	if(fd.DoModal()==IDOK)
	{
		m_moviedlg.fname=fd.GetPathName();
		filesel=1;
	}
	break;
	
	case ID_VPAUSE:

	if(status==2)
		m_moviedlg.m_amovie.Pause();
	else if(status==1)
		m_moviedlg.m_amovie.Run();
	
	break;

	case  ID_VSTOP:
	if(status==2)
	{
		m_moviedlg.m_amovie.Stop();
		m_moviedlg.ShowWindow(SW_HIDE);
		KillTimer(2);
		m_prog2.SetPos(0);
		m_static2.SetWindowText("00:00:00");
	}
	break;

	case ID_VPREV:
		m_moviedlg.m_amovie.SetCurrentPosition(0);
		if(status!=2)
			m_moviedlg.m_amovie.Run();

	break;

	case ID_VREV:
	if(status==2)
	{
		if(pos-10 >= 0)
		m_moviedlg.m_amovie.SetCurrentPosition(pos-10);
		
	}
	break;

	case ID_VFORW:
	if(status==2)
	{
		double end=m_moviedlg.m_amovie.GetDuration();
		if ( (pos + 10) <=end)
			m_moviedlg.m_amovie.SetCurrentPosition(pos+10);
	}
	
	break;

	case ID_VNEXT:
	if(status==2)
	{
		double end=m_moviedlg.m_amovie.GetDuration();
		m_moviedlg.m_amovie.SetCurrentPosition(end);
	}
	break;
	}
}


void CMycdplayerDlg::OnCustomdrawSlider1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	if(filesel==1)
	{
		UpdateData(TRUE);
		m_moviedlg.m_amovie.SetVolume(m_volume);
	}
	*pResult = 0;
}
