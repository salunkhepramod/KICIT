//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by mycdplayer.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MYCDPLAYER_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDB_ABOUT1                      130
#define IDB_ABOUT2                      131
#define IDB_EJECT1                      132
#define IDB_EJECT2                      133
#define IDB_FORW1                       134
#define IDB_FORW2                       135
#define IDB_MINIMIZE1                   136
#define IDB_MINIMIZE2                   137
#define IDB_NEXT1                       138
#define IDB_NEXT2                       139
#define IDB_PAUSE1                      140
#define IDB_PAUSE2                      141
#define IDB_PLAY1                       142
#define IDB_PLAY2                       143
#define IDB_POWER1                      144
#define IDB_POWER2                      145
#define IDB_PREV1                       146
#define IDB_PREV2                       147
#define IDB_REV1                        148
#define IDB_REV2                        149
#define IDD_MOVIE                       150
#define IDB_TEXTURE                     152
#define IDB_STOP2                       153
#define IDB_STOP1                       154
#define IDC_ACTIVEMOVIECONTROL1         1000
#define IDC_STATIC1                     1001
#define IDC_PROGRESS1                   1002
#define IDC_PLAYTRACK                   1003
#define IDC_EDIT1                       1004
#define IDC_STATIC2                     1005
#define IDC_PROGRESS2                   1006
#define IDC_SPIN1                       1008
#define IDC_SLIDER1                     1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        157
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
