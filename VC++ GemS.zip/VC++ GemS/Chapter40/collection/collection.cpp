// collection.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "collection.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

using namespace std;

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;


	// MFC Array Class

	int i, j ;
	CUIntArray arr ;
	arr.SetSize ( 20 ) ;
	for ( i = 0 ; i < 20 ; i++ ) 
		arr[ i ] = i + 1 ;

	arr.InsertAt ( 5, 100 ) ; // Inserts 100 at index 5

	for ( i = 0 ; i < 20 ; i++ ) 
		cout << arr[ i ] << "  " ;


	// Creating 2-D array
	CUIntArray a[2] ;

	a[0].SetSize ( 4 ) ;
	a[1].SetSize ( 3 ) ;

	for ( i = 0 ; i < 2 ; i++ )
	{
		for ( j = 0 ; j < a[i].GetSize( ) ; j++ )
			a[i][j] = j ;
	}

	cout << endl ;
	for ( i = 0 ; i < 2 ; i++ )
	{
		for ( j = 0 ; j < a[i].GetSize( ) ; j++ )
			cout << a[i][j] << "  " ;
		cout << endl ;
	}

	cout << endl << a[0].GetSize( ) << endl ;
	cout << a[1].GetSize( ) ;

	// MFC List Class

	char *names[ ] = { 
						"Subhash", 
						"Rahul",
						"Joe",
						"Saurav",
						"Sachin"
					 } ;

	CStringList str ;
	for ( i = 0 ; i < 5 ; i++ ) 
		str.AddTail ( names[ i ] ) ;

	POSITION p ;
	p = str.GetHeadPosition( ) ;

	cout << endl ;

	CString s ;
	while ( p != NULL )
	{
		s = str.GetNext ( p ) ;
		cout << ( LPCTSTR ) s << endl ;
	}


	// MFC Map Classes

	CMapStringToString m ;
	m [ "Sunday" ] = "Itwar" ;
	m [ "Monday" ] = "Somwar" ;
	m [ "Tuesday" ] = "Mangalwar" ;
	m [ "Wednesday" ] = "Budhwar" ;
	m [ "Thursday" ] = "Guruwar" ;
	m [ "Friday" ] = "Shukrawar" ;
	m [ "Saturday" ] = "Shaniwar" ;

	CString day, key, item ;
	if ( m.Lookup ( "Wednesday", day ) ) 
		cout << endl << "Wednesday in Hindi is " << ( LPCTSTR ) day << endl ;

	POSITION pos ;
	pos = m.GetStartPosition ( ) ;
	while ( pos != NULL ) 
	{
		m.GetNextAssoc ( pos, key, item ) ; 
		cout << "key = " << ( LPCTSTR ) key << "item = " << ( LPCTSTR ) item << endl ;
	}

	return nRetCode;
}


