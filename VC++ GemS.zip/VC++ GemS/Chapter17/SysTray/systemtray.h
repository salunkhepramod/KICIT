#if !defined(AFX_SYSTEMTRAY_H__811383A0_B42F_11D5_B2A2_0050BAD6ADC3__INCLUDED_)
#define AFX_SYSTEMTRAY_H__811383A0_B42F_11D5_B2A2_0050BAD6ADC3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// systemtray.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// systemtray window

class systemtray : public CWnd
{
// Construction
public:
	systemtray();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(systemtray)
	protected:
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

public:
	BOOL create ( CWnd *p, UINT message, LPCTSTR tip, HICON i ) ;
	LRESULT onusermessage ( WPARAM w, LPARAM l ) ;
	void remove( ) ;
	void setdefault( ) ;
	void seticon ( HICON h ) ;
	
	// Implementation
public:
	virtual ~systemtray();

	// Generated message map functions
private:
	NOTIFYICONDATA m_nid ;
	CMenu m_mymenu ;

protected:
	//{{AFX_MSG(systemtray)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SYSTEMTRAY_H__811383A0_B42F_11D5_B2A2_0050BAD6ADC3__INCLUDED_)
