// systemtray.cpp : implementation file
//

#include "stdafx.h"
#include "SysTray.h"
#include "systemtray.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// systemtray

systemtray::systemtray()
{
}

systemtray::~systemtray()
{
}


BEGIN_MESSAGE_MAP(systemtray, CWnd)
	//{{AFX_MSG_MAP(systemtray)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	ON_MESSAGE ( WM_USER + 15, onusermessage ) 
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// systemtray message handlers


BOOL systemtray::create(CWnd *p, UINT message, LPCTSTR tip, HICON i)
{
	CWnd::CreateEx ( 0, AfxRegisterWndClass ( 0 ), "", WS_POPUP, 0, 0, 
						10, 10, NULL, 0 ) ;

	m_mymenu.CreatePopupMenu( ) ;

	m_mymenu.AppendMenu ( MF_STRING, 101, "Option1" ) ;
	m_mymenu.AppendMenu ( MF_STRING, 102, "Option2" ) ;
	m_mymenu.AppendMenu ( MF_STRING, 103, "Animate" ) ;
	m_mymenu.AppendMenu ( MF_STRING, 104, "Exit" ) ;

	m_nid.cbSize = sizeof ( NOTIFYICONDATA ) ;
	m_nid.hWnd = m_hWnd ;
	m_nid.uID = 1 ;
	m_nid.hIcon = i ; 
	m_nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP ;
	m_nid.uCallbackMessage = message ;
	strcpy ( m_nid.szTip, tip ) ;

	Shell_NotifyIcon ( NIM_ADD, &m_nid ) ;

	return 0 ;
}

LRESULT systemtray::onusermessage ( WPARAM w, LPARAM l ) 
{
	CWnd *p = AfxGetMainWnd( ) ;

	if ( LOWORD ( l ) == WM_RBUTTONUP )
	{
		CPoint pos ;
		GetCursorPos ( &pos ) ;
		p -> SetForegroundWindow( ) ;
		setdefault( ) ;
		m_mymenu.TrackPopupMenu ( TPM_RIGHTBUTTON, pos.x, pos.y, 
									p ) ;
		p -> PostMessage ( WM_NULL, 0, 0 ) ;
	}
	else if ( LOWORD ( l ) == WM_LBUTTONDBLCLK )
	{
		p -> SetForegroundWindow( ) ;
		int id = GetMenuDefaultItem ( m_mymenu.m_hMenu, FALSE, 0 ) ;
		p -> SendMessage ( WM_COMMAND, 101, 0 ) ;
	}

	return 0L ;
}

void systemtray::remove( )
{
	Shell_NotifyIcon ( NIM_DELETE, &m_nid ) ;
}


void systemtray::setdefault( )
{
	::SetMenuDefaultItem ( m_mymenu.m_hMenu, 101, NULL ) ;
}

void systemtray::seticon ( HICON h )
{
	m_nid.uFlags = NIF_ICON ;
	m_nid.hIcon = h ;

	Shell_NotifyIcon ( NIM_MODIFY, &m_nid ) ;
}

LRESULT systemtray::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CWnd::WindowProc(message, wParam, lParam);
}
