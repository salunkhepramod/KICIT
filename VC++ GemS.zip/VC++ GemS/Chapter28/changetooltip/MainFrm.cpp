// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "changetooltip.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define LDT_RECTANGLE 55
#define LDT_RECTANGLE1 56

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	ON_WM_CREATE()
	ON_WM_SETFOCUS()
	ON_NOTIFY ( TTN_NEEDTEXT, NULL, changetip )
	ON_COMMAND_RANGE ( ID_ONE, ID_TWO, tools ) 
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_i = 1 ;
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	// create a view to occupy the client area of the frame
	if (!m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW,
		CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL))
	{
		TRACE0("Failed to create view window\n");
		return -1;
	}
	
	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}


	m_tips1[0] = "AAA" ;
	m_tips1[1] = "BBB" ;
	m_tips1[2] = "CCC" ;
	m_tips1[3] = "DDD" ;

	m_tips2[0] = "111" ;
	m_tips2[1] = "222" ;
	m_tips2[2] = "333" ;
	m_tips2[3] = "444" ;

	m_t.Create ( this, WS_CHILD | WS_VISIBLE | CBRS_TOP |
					 CBRS_TOOLTIPS | CBRS_SIZE_DYNAMIC ) ;
	
	m_t.LoadToolBar ( IDR_TOOLBAR1 ) ;
			
	m_tip.Create ( this ) ;
			
	m_tip.addrect ( &m_t, LPSTR_TEXTCALLBACK, 
				CRect ( 0, 0, 25, 25 ), LDT_RECTANGLE ) ;
	m_tip.addrect ( &m_t, LPSTR_TEXTCALLBACK, 
    			CRect ( 26, 0, 51, 25 ), LDT_RECTANGLE1 ) ;
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(0);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers
void CMainFrame::OnSetFocus(CWnd* pOldWnd)
{
	// forward focus to the view window
	m_wndView.SetFocus();
}

BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// let the view have first crack at the command
	if (m_wndView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	// otherwise, do default handling
	return CFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

void CMainFrame::changetip(NMHDR *nm, LRESULT *res)
{
	TOOLTIPTEXT *tt = ( TOOLTIPTEXT * ) nm ;

	if ( tt -> hdr.idFrom == LDT_RECTANGLE )
		lstrcpy ( tt -> szText, ( LPCTSTR ) m_tips1[m_i%4] ) ; 

	if ( tt -> hdr.idFrom == LDT_RECTANGLE1 )
		lstrcpy ( tt -> szText, ( LPCTSTR ) m_tips2[m_i%4] ) ;
	
	m_i++ ;
}

void CMainFrame::tools()
{

}
