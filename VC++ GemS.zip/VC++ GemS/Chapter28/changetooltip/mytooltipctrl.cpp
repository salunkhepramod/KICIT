// mytooltipctrl.cpp : implementation file
//

#include "stdafx.h"
#include "changetooltip.h"
#include "mytooltipctrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// mytooltipctrl

mytooltipctrl::mytooltipctrl()
{
}

mytooltipctrl::~mytooltipctrl()
{
}


BEGIN_MESSAGE_MAP(mytooltipctrl, CToolTipCtrl)
	//{{AFX_MSG_MAP(mytooltipctrl)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// mytooltipctrl message handlers

BOOL mytooltipctrl::addrect(CWnd *pwnd, LPCTSTR str, LPCRECT r, UINT tool)
{
	TOOLINFO ti ;

	ti.cbSize = sizeof ( TOOLINFO ) ;
	ti.uFlags = TTF_SUBCLASS ;
	ti.hwnd = pwnd -> GetSafeHwnd( ) ; 
	ti.uId = tool ;
	ti.hinst = AfxGetInstanceHandle( ) ;
	ti.lpszText = ( LPTSTR ) str ;
	::CopyRect ( &ti.rect, r ) ;

	return ( BOOL )SendMessage ( TTM_ADDTOOL, 0, ( LPARAM ) &ti ) ;
}
