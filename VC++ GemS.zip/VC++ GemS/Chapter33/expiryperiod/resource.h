//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by expiryperiod.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_EXPIRYTYPE                  129
#define IDD_DIALOG1                     130
#define IDC_STATIC1                     1000
#define IDC_STATIC2                     1001
#define IDC_STATIC3                     1002
#define IDC_STATIC4                     1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
