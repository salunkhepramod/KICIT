// mydialog.cpp : implementation file
//

#include "stdafx.h"
#include "expiryperiod.h"
#include "mydialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// mydialog dialog


mydialog::mydialog(CWnd* pParent /*=NULL*/)
	: CDialog(mydialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(mydialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void mydialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(mydialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(mydialog, CDialog)
	//{{AFX_MSG_MAP(mydialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// mydialog message handlers

BOOL mydialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	HKEY Regentry, mykey ;

	if ( !RegOpenKeyEx ( HKEY_CLASSES_ROOT, 
		"Directory\\Time", 0, KEY_QUERY_VALUE, &mykey ) ) 
	{

		DWORD size = sizeof ( DWORD ) ;

    	RegQueryValueEx ( mykey, "Minute", 0, 0, ( BYTE * ) 
						&m_minutes, &size ) ;
		RegQueryValueEx ( mykey, "Count", 0, 0, ( BYTE * ) 
						&m_count, &size ) ;

		if ( m_count != 100 )
	         m_count++ ;

		RegSetValueEx ( mykey, "Count", 0, REG_DWORD,
					    ( const BYTE *) &m_count, sizeof ( DWORD ) ) ;
		RegCloseKey ( mykey ) ;
	}
	else
	{
		MessageBox ( "Thanks for using our Software" ) ;
		m_minutes = 0 ;
		m_count = 1 ;
		RegOpenKeyEx ( HKEY_CLASSES_ROOT, 
	                   "Directory", 0, KEY_QUERY_VALUE, &Regentry ) ;
		
		RegCreateKey ( Regentry, "Time", &mykey ) ;
		RegSetValueEx ( mykey, "Minute", 0, REG_DWORD,
                        ( const BYTE *) &m_minutes, sizeof ( DWORD ) ) ;
		RegSetValueEx ( mykey, "Count", 0, REG_DWORD,
					    ( const BYTE *) &m_count, sizeof ( DWORD ) ) ;
				
		RegCloseKey ( Regentry ) ;
	}

	int hour, minutes, remaining ;
	hour = m_minutes / 60 ;
	minutes = m_minutes % 60 ;

	CString str1, str2 ;

	str1.Format ( "%d hours %d minutes",hour,minutes) ;
	SetDlgItemText ( IDC_STATIC1, str1 ) ;

	remaining = 600 - m_minutes ;
	hour = remaining / 60 ;
	minutes = remaining % 60 ;
	str2.Format ( "%d hours %d minutes",hour,minutes) ;
	SetDlgItemText ( IDC_STATIC2, str2) ;

	SetDlgItemInt ( IDC_STATIC3, m_count ) ;
	SetDlgItemInt ( IDC_STATIC4, 100 - m_count ) ;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
