// drawrectDoc.h : interface of the CDrawrectDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DRAWRECTDOC_H__05E2DE5F_C156_11D5_B2A2_0050BAD6ADC3__INCLUDED_)
#define AFX_DRAWRECTDOC_H__05E2DE5F_C156_11D5_B2A2_0050BAD6ADC3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "rect.h"
class CDrawrectDoc : public CDocument
{
protected: // create from serialization only
	CDrawrectDoc();
	DECLARE_DYNCREATE(CDrawrectDoc)

// Attributes
public:
	rect* getobject(int i) ;
	int getrectcount() ;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDrawrectDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void DeleteContents();
	//}}AFX_VIRTUAL

// Implementation
public:
	rect* addrect ( CPoint x, CPoint y );
	virtual ~CDrawrectDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDrawrectDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CObArray m_arr;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DRAWRECTDOC_H__05E2DE5F_C156_11D5_B2A2_0050BAD6ADC3__INCLUDED_)
