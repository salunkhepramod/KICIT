// rect.h: interface for the rect class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RECT_H__05E2DE69_C156_11D5_B2A2_0050BAD6ADC3__INCLUDED_)
#define AFX_RECT_H__05E2DE69_C156_11D5_B2A2_0050BAD6ADC3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class rect : public CObject  
{
	DECLARE_SERIAL ( rect )
public:
	void Serialize ( CArchive &ar );
	rect ( CPoint x, CPoint y );
	rect();
	void draw(CDC *pdc) ;
	virtual ~rect();
private:
	CPoint m_point2;
	CPoint m_point1;
};

#endif // !defined(AFX_RECT_H__05E2DE69_C156_11D5_B2A2_0050BAD6ADC3__INCLUDED_)
