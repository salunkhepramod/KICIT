// drawrectDoc.cpp : implementation of the CDrawrectDoc class
//

#include "stdafx.h"
#include "drawrect.h"

#include "drawrectDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDrawrectDoc

IMPLEMENT_DYNCREATE(CDrawrectDoc, CDocument)

BEGIN_MESSAGE_MAP(CDrawrectDoc, CDocument)
	//{{AFX_MSG_MAP(CDrawrectDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDrawrectDoc construction/destruction

CDrawrectDoc::CDrawrectDoc()
{
	m_arr.SetSize ( 0, 100  ) ;
}

CDrawrectDoc::~CDrawrectDoc()
{
}

BOOL CDrawrectDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CDrawrectDoc serialization

void CDrawrectDoc::Serialize(CArchive& ar)
{
	m_arr.Serialize ( ar ) ;
}

/////////////////////////////////////////////////////////////////////////////
// CDrawrectDoc diagnostics

#ifdef _DEBUG
void CDrawrectDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CDrawrectDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDrawrectDoc commands

void CDrawrectDoc::DeleteContents() 
{
	int count = m_arr.GetSize( ) ;

	if ( count )
	{
		for ( int i = 0; i < count; i++ )
			delete m_arr[ i ] ;

		m_arr.RemoveAll( ) ;
	}
	
	CDocument::DeleteContents();
}

int CDrawrectDoc::getrectcount()
{
	return m_arr.GetSize( ) ;
}

rect* CDrawrectDoc::getobject(int i)
{
	return ( rect* ) m_arr [ i ] ;
}

rect* CDrawrectDoc::addrect(CPoint x, CPoint y)
{
	rect* prect = new rect ( x, y ) ;	
	m_arr.Add ( prect ) ;
	SetModifiedFlag ( ) ;

	return prect ;
}
