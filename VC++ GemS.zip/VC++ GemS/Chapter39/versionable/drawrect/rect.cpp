// rect.cpp: implementation of the rect class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "drawrect.h"
#include "rect.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
IMPLEMENT_SERIAL ( rect, CObject, 1 )

rect::rect()
{

}

rect::~rect()
{

}

rect::rect(CPoint x, CPoint y)
{
	m_point1 = x ;
	m_point2 = y ;
}

void rect::Serialize(CArchive &ar)
{
	CObject :: Serialize ( ar ) ;

	if ( ar.IsStoring( ) )
		ar << m_point1 << m_point2 ;
	else
		ar >> m_point1 >> m_point2 ;
}

void rect::draw(CDC *pdc)
{
	pdc -> Rectangle ( m_point1.x, m_point1.y, m_point2.x, m_point2.y ) ;
}
