// rect.h: interface for the rect class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RECT_H__05E2DE54_C156_11D5_B2A2_0050BAD6ADC3__INCLUDED_)
#define AFX_RECT_H__05E2DE54_C156_11D5_B2A2_0050BAD6ADC3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class rect : public CObject  
{
	DECLARE_SERIAL ( rect )
public:
	void draw ( CDC *pdc );
	void Serialize ( CArchive& ar );
	rect(CPoint x, CPoint y, COLORREF pc, COLORREF bc) ;
	rect();
	virtual ~rect();

private:
	COLORREF m_brushcolor;
	COLORREF m_pencolor;
	CPoint m_point1;
	CPoint m_point2;

};

#endif // !defined(AFX_RECT_H__05E2DE54_C156_11D5_B2A2_0050BAD6ADC3__INCLUDED_)
