// rect.cpp: implementation of the rect class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "schemas.h"
#include "rect.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IMPLEMENT_SERIAL ( rect, CObject, 2 | VERSIONABLE_SCHEMA )

rect::rect()
{

}

rect::~rect()
{

}

rect::rect(CPoint x, CPoint y, COLORREF pc, COLORREF bc)
{
	m_point1 = x ;
	m_point2 = y ;
	m_pencolor = pc ;
	m_brushcolor = bc ;
}

void rect::Serialize(CArchive &ar)
{
	CObject :: Serialize ( ar ) ;

	if ( ar.IsStoring( ) )
		ar << m_point1 << m_point2 << m_pencolor << m_brushcolor ;
	else
	{
		UINT schema = ar.GetObjectSchema( ) ;
		switch ( schema ) 
		{
			case 1:

			ar >> m_point1 >> m_point2 ;
			m_pencolor = RGB ( 0, 0, 0 ) ;  // black
			m_brushcolor = RGB ( 255, 255, 255 ) ;  // white
			break ;

			case 2:

			ar >> m_point1 >> m_point2 >> m_pencolor >> m_brushcolor ;
			break ;
		}
	}
}

void rect::draw(CDC *pdc)
{
	CPen mypen ( PS_SOLID, 1, m_pencolor ) ;
	CPen *oldpen = pdc -> SelectObject ( &mypen ) ;

	CBrush mybrush ;

	mybrush.CreateSolidBrush ( m_brushcolor ) ;

	CBrush *oldbrush = pdc -> SelectObject ( &mybrush ) ;

	pdc -> Rectangle ( m_point1.x, m_point1.y, m_point2.x, m_point2.y ) ;

	pdc -> SelectObject ( oldpen ) ;
	pdc -> SelectObject ( oldbrush ) ;
}
