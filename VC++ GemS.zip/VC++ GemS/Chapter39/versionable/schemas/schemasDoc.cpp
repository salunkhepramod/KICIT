// schemasDoc.cpp : implementation of the CSchemasDoc class
//

#include "stdafx.h"
#include "schemas.h"

#include "schemasDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSchemasDoc

IMPLEMENT_DYNCREATE(CSchemasDoc, CDocument)

BEGIN_MESSAGE_MAP(CSchemasDoc, CDocument)
	//{{AFX_MSG_MAP(CSchemasDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSchemasDoc construction/destruction

CSchemasDoc::CSchemasDoc()
{
	m_arr.SetSize ( 0, 100  ) ;
}

CSchemasDoc::~CSchemasDoc()
{
}

BOOL CSchemasDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CSchemasDoc serialization

void CSchemasDoc::Serialize(CArchive& ar)
{
	m_arr.Serialize ( ar ) ;
}

/////////////////////////////////////////////////////////////////////////////
// CSchemasDoc diagnostics

#ifdef _DEBUG
void CSchemasDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CSchemasDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSchemasDoc commands

rect* CSchemasDoc::addrect(CPoint from, CPoint to, COLORREF pc, COLORREF bc)
{
	rect* prect = new rect ( from, to, pc, bc ) ;	
	m_arr.Add ( prect ) ;
	SetModifiedFlag ( ) ;

	return prect ;
}

void CSchemasDoc::DeleteContents() 
{
	int count = m_arr.GetSize( ) ;

	if ( count )
	{
		for ( int i = 0; i < count; i++ )
			delete m_arr[ i ] ;

		m_arr.RemoveAll( ) ;
	}
		
	CDocument::DeleteContents();
}

int CSchemasDoc::getrectcount()
{
	return m_arr.GetSize( ) ;
}

rect* CSchemasDoc::getobject(int i)
{
	return ( rect* ) m_arr [ i ] ;
}
