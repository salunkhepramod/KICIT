// schemasView.cpp : implementation of the CSchemasView class
//

#include "stdafx.h"
#include "schemas.h"

#include "schemasDoc.h"
#include "schemasView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSchemasView

IMPLEMENT_DYNCREATE(CSchemasView, CView)

BEGIN_MESSAGE_MAP(CSchemasView, CView)
	//{{AFX_MSG_MAP(CSchemasView)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
	ON_COMMAND_RANGE ( ID_PEN_RED, ID_PEN_BLACK, selectpencolor )
	ON_COMMAND_RANGE ( ID_BRUSH_RED, ID_BRUSH_WHITE, selectbrushcolor )
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSchemasView construction/destruction

CSchemasView::CSchemasView()
{
	m_pen = RGB ( 0, 0, 0 ) ;
	m_brush = RGB ( 255, 255, 255 ) ;
}

CSchemasView::~CSchemasView()
{
}

BOOL CSchemasView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CSchemasView drawing

void CSchemasView::OnDraw(CDC* pDC)
{
	CSchemasDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	int objectcount = pDoc -> getrectcount( ) ;

	if ( objectcount ) 
	{
		for ( int i = 0; i < objectcount; i++ )
			pDoc -> getobject ( i ) -> draw ( pDC ) ;
	}
}

/////////////////////////////////////////////////////////////////////////////
// CSchemasView printing

BOOL CSchemasView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSchemasView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CSchemasView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CSchemasView diagnostics

#ifdef _DEBUG
void CSchemasView::AssertValid() const
{
	CView::AssertValid();
}

void CSchemasView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CSchemasDoc* CSchemasView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSchemasDoc)));
	return (CSchemasDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSchemasView message handlers

void CSchemasView::selectpencolor(UINT id)
{
	switch ( id )
	{
		case ID_PEN_RED :
			m_pen = RGB ( 255, 0, 0 ) ;
			break ;

		case ID_PEN_GREEN :
			m_pen = RGB ( 0, 255, 0 ) ;
			break ;

		case ID_PEN_BLUE :
			m_pen = RGB ( 0, 0, 255 ) ;
			break ;

		case ID_PEN_YELLOW :
			m_pen = RGB ( 255, 255, 0 ) ;
			break ;

		case ID_PEN_CYAN :
			m_pen = RGB ( 0, 255, 255 ) ;
			break ;

		case ID_PEN_PINK :
			m_pen = RGB (255, 0, 255 ) ;
			break ;

		case ID_PEN_PURPLE :
			m_pen = RGB ( 128, 0, 255 ) ;
			break ;

		case ID_PEN_BROWN :
			m_pen = RGB ( 128, 64, 64 ) ;
			break ;
		case ID_PEN_BLACK :
			m_pen = RGB ( 0, 0, 0 ) ;
			break ;
	}
}

void CSchemasView::selectbrushcolor(UINT id)
{
	switch ( id )
	{
		case ID_BRUSH_RED :
			m_brush = RGB ( 255, 0, 0 ) ;
			break ;

		case ID_BRUSH_GREEN :
			m_brush = RGB ( 0, 255, 0 ) ;
			break ;

		case ID_BRUSH_BLUE :
			m_brush = RGB ( 0, 0, 255 ) ;
			break ;

		case ID_BRUSH_YELLOW :
			m_brush = RGB ( 255, 255, 0 ) ;
			break ;

		case ID_BRUSH_CYAN :
			m_brush = RGB ( 0, 255, 255 ) ;
			break ;

		case ID_BRUSH_PINK :
			m_brush = RGB (255, 0, 255 ) ;
			break ;

		case ID_BRUSH_PURPLE :
			m_brush = RGB ( 128, 0, 255 ) ;
			break ;

		case ID_BRUSH_BROWN :
			m_brush = RGB ( 128, 64, 64 ) ;
			break ;
		case ID_BRUSH_WHITE :
			m_brush = RGB ( 255, 255, 255 ) ;
			break ;
	}
}

void CSchemasView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CClientDC dc ( this ) ;

	int prevmode = dc.SetROP2 ( R2_NOTXORPEN ) ;

	CPen mypen ( PS_SOLID, 1, m_pen ) ;
	CPen *oldpen = dc.SelectObject ( &mypen ) ;

	CBrush mybrush ;
	mybrush.CreateSolidBrush ( m_brush ) ;
	
	CBrush *oldbrush = dc.SelectObject ( &mybrush ) ;
	
	m_startpt = m_endpt = point ;

	dc.Rectangle ( m_startpt.x, m_startpt.y, m_endpt.x, m_endpt.y ) ;

	dc.SelectObject ( oldpen ) ;
	dc.SelectObject ( oldbrush ) ;
	dc.SetROP2 ( prevmode ) ;

	SetCapture( ) ;
		
	CView::OnLButtonDown(nFlags, point);
}

void CSchemasView::OnMouseMove(UINT nFlags, CPoint point) 
{
	if ( GetCapture( ) == this )
	{
		CClientDC dc ( this ) ;

		int prevmode = dc.SetROP2 ( R2_NOTXORPEN ) ;

		CPen mypen ( PS_SOLID, 1, m_pen ) ;
		CPen *oldpen = dc.SelectObject ( &mypen ) ;

		CBrush mybrush ;
		mybrush.CreateSolidBrush ( m_brush ) ;	
		CBrush *oldbrush = dc.SelectObject ( &mybrush ) ;

		dc.Rectangle ( m_startpt.x, m_startpt.y, m_endpt.x, m_endpt.y ) ;
		dc.Rectangle ( m_startpt.x, m_startpt.y, point.x, point.y ) ;

		m_endpt = point ;

		dc.SetROP2 ( prevmode ) ;
		dc.SelectObject ( oldpen ) ;
		dc.SelectObject ( oldbrush ) ;
	}
		
	CView::OnMouseMove(nFlags, point);
}

void CSchemasView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if ( GetCapture( ) == this )
	{
		::ReleaseCapture( ) ;
		CClientDC dc ( this ) ;

		CSchemasDoc *pDoc = ( ( CSchemasDoc * ) GetDocument( ) ) ;
		rect *prect ;

		m_endpt = point ;

		prect = pDoc -> addrect ( m_startpt, m_endpt, m_pen, m_brush ) ;
		prect -> draw ( &dc ) ;
	}
	
	CView::OnLButtonUp(nFlags, point);
}
