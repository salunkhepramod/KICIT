// schemasDoc.h : interface of the CSchemasDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCHEMASDOC_H__05E2DE4A_C156_11D5_B2A2_0050BAD6ADC3__INCLUDED_)
#define AFX_SCHEMASDOC_H__05E2DE4A_C156_11D5_B2A2_0050BAD6ADC3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "rect.h"

class CSchemasDoc : public CDocument
{
protected: // create from serialization only
	CSchemasDoc();
	DECLARE_DYNCREATE(CSchemasDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSchemasDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void DeleteContents();
	//}}AFX_VIRTUAL

// Implementation
public:
	rect* getobject ( int i );
	int getrectcount( );
	rect* addrect ( CPoint from, CPoint to, COLORREF pc, COLORREF bc );
	virtual ~CSchemasDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSchemasDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CObArray m_arr;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCHEMASDOC_H__05E2DE4A_C156_11D5_B2A2_0050BAD6ADC3__INCLUDED_)
