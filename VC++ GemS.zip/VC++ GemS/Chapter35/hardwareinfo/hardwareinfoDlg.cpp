// hardwareinfoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "hardwareinfo.h"
#include "hardwareinfoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHardwareinfoDlg dialog

CHardwareinfoDlg::CHardwareinfoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHardwareinfoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHardwareinfoDlg)
	m_architecture = _T("");
	m_processorlevel = _T("");
	m_vendorinfo = _T("");
	m_mask = _T("");
	m_maxaddress = _T("");
	m_memavailable = _T("");
	m_meminstalled = _T("");
	m_memvirtual = _T("");
	m_memused = _T("");
	m_minaddress = _T("");
	m_numprocessors = _T("");
	m_pagesize = _T("");
	m_processortype = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CHardwareinfoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHardwareinfoDlg)
	DDX_Control(pDX, IDC_PROCESS, m_cprocessortype);
	DDX_Control(pDX, IDC_MANU, m_cvendorinfo);
	DDX_Control(pDX, IDC_MEMTOTAL, m_cmemvirtual);
	DDX_Control(pDX, IDC_PAGE, m_cpagesize);
	DDX_Control(pDX, IDC_NUMPROCESS, m_cnumprocessors);
	DDX_Control(pDX, IDC_MINADDRESS, m_cminaddress);
	DDX_Control(pDX, IDC_MEMUSED, m_cmemused);
	DDX_Control(pDX, IDC_MEMINST, m_cmeminstalled);
	DDX_Control(pDX, IDC_MAXADDRESS, m_cmaxaddress);
	DDX_Control(pDX, IDC_MASK, m_cmask);
	DDX_Control(pDX, IDC_LEVEL, m_cprocessorlevel);
	DDX_Control(pDX, IDC_MEMAV, m_cmemavailable);
	DDX_Control(pDX, IDC_ARC, m_carchitecture);
	DDX_Text(pDX, IDC_ARC, m_architecture);
	DDX_Text(pDX, IDC_LEVEL, m_processorlevel);
	DDX_Text(pDX, IDC_MANU, m_vendorinfo);
	DDX_Text(pDX, IDC_MASK, m_mask);
	DDX_Text(pDX, IDC_MAXADDRESS, m_maxaddress);
	DDX_Text(pDX, IDC_MEMAV, m_memavailable);
	DDX_Text(pDX, IDC_MEMINST, m_meminstalled);
	DDX_Text(pDX, IDC_MEMTOTAL, m_memvirtual);
	DDX_Text(pDX, IDC_MEMUSED, m_memused);
	DDX_Text(pDX, IDC_MINADDRESS, m_minaddress);
	DDX_Text(pDX, IDC_NUMPROCESS, m_numprocessors);
	DDX_Text(pDX, IDC_PAGE, m_pagesize);
	DDX_Text(pDX, IDC_PROCESS, m_processortype);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CHardwareinfoDlg, CDialog)
	//{{AFX_MSG_MAP(CHardwareinfoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHardwareinfoDlg message handlers

BOOL CHardwareinfoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	getmemoryinfo( ) ;
	getsysinfo( ) ;

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CHardwareinfoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CHardwareinfoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CHardwareinfoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CHardwareinfoDlg::getmemoryinfo()
{
	DWORD var ;
	CStatic s ;
	
	MEMORYSTATUS memorystatus = { 0 } ;
	memorystatus.dwLength = sizeof ( MEMORYSTATUS ) ;
	GlobalMemoryStatus ( &memorystatus ) ;

	m_memused.Format ( "%ld", memorystatus.dwMemoryLoad ) ;
	m_cmemused.SetWindowText ( m_memused ) ;

	var = memorystatus.dwTotalPhys / 1024 ;
	m_meminstalled.Format ( "%ld", var ) ;
	m_meminstalled += " KB" ;
	m_cmeminstalled.SetWindowText ( m_meminstalled ) ;

	var = memorystatus.dwAvailPhys / 1024 ;
	m_memavailable.Format ( "%ld", var ) ;
	m_memavailable += " KB" ;
	m_cmemavailable.SetWindowText ( m_memavailable ) ;

	var = memorystatus.dwTotalVirtual / 1024 ;
	m_memvirtual.Format ( "%ld", var ) ;
	m_memvirtual += " KB" ;
	m_cmemvirtual.SetWindowText ( m_memvirtual ) ;
}

void CHardwareinfoDlg::getsysinfo()
{
	SYSTEM_INFO sysinfo ;

	HKEY hKey ;
	BYTE vendorData [64] ;
	DWORD dataSize ;

	CString path = "Hardware\\Description\\System\\CentralProcessor\\0" ;	// Get the processor speed info.
			        dataSize = sizeof ( vendorData ) ;

	if ( ::RegOpenKeyEx ( HKEY_LOCAL_MACHINE, path, 0, 
								KEY_QUERY_VALUE, &hKey ) == 
								ERROR_SUCCESS ) 
		::RegQueryValueEx ( hKey, "VendorIdentifier", NULL, 
							NULL, vendorData, &dataSize ) ;

	m_vendorinfo.Format ( "%s", vendorData ) ;
	m_cvendorinfo.SetWindowText ( m_vendorinfo ) ;

	RegCloseKey ( hKey ) ;

	GetSystemInfo ( &sysinfo ) ;

	// processor type 
	m_processortype = "Unknown" ; // Initialize type

	switch ( sysinfo.dwProcessorType  )
	{
		case PROCESSOR_INTEL_386 :
		     m_processortype = "Intel 386" ;
			 break ;

		case PROCESSOR_INTEL_486 :
		     m_processortype = "Intel 486" ;
			 break ;

		case PROCESSOR_INTEL_PENTIUM :
			 m_processortype = "Intel Pentium" ;
			 break ;

		case PROCESSOR_MIPS_R4000 :
	 	     m_processortype = "MIPS" ;
			 break ;

		case PROCESSOR_ALPHA_21064 :
	         m_processortype = "Alpha" ;
			 break ;
	}
	m_cprocessortype.SetWindowText ( m_processortype ) ;

	// number of processors
	m_numprocessors.Format ( "%ld", sysinfo.dwNumberOfProcessors ) ;
	m_cnumprocessors.SetWindowText( m_numprocessors );

	// the architecture type and processor level
	// Windows 95 doesn't use processor level
	m_processorlevel = "Unknown" ;

	if ( sysinfo.wProcessorArchitecture == 
	     PROCESSOR_ARCHITECTURE_INTEL )
	{
		m_architecture = "Pentium" ;

		switch ( sysinfo.wProcessorLevel )
		{
				case 3 :
					m_processorlevel = "Intel 80386" ;
					break ;

				case 4 :
					m_processorlevel = "Intel 80486" ;
					break ;

				case 5 :
					m_processorlevel = "Pentium" ;
	
					// MMX instruction set is available or not
					if ( IsProcessorFeaturePresent ( 
	 	                 PF_MMX_INSTRUCTIONS_AVAILABLE ) )
					{
							m_processorlevel += " MMX" ;
					}
					break ;

				case 6 :
					m_processorlevel = "Pentium (II/Pro)" ;
					break ;
		}
	}

	if ( sysinfo.wProcessorArchitecture == 
         PROCESSOR_ARCHITECTURE_MIPS )
	{
		m_architecture = "MIPS" ;
		if ( sysinfo.wProcessorLevel == 0004 )
			m_processorlevel = "MIPS R4000" ;
	}

	if ( sysinfo.wProcessorArchitecture == 
	     PROCESSOR_ARCHITECTURE_ALPHA )
	{
		m_architecture = "Alpha" ;

		CString temp ;
		temp.Format ( "%ld", sysinfo.wProcessorLevel ) ;

		m_processorlevel = m_architecture + temp ;
	}
			
	if ( sysinfo.wProcessorArchitecture == 
		 PROCESSOR_ARCHITECTURE_PPC )
	{
		m_architecture = "PPC" ;

		switch ( sysinfo.wProcessorLevel )
		{
				case 1 :
					m_processorlevel = "PPC 601" ;
					break ;

				case 3 :
					m_processorlevel = "PPC 603" ;
					break;

				case 4 :
					m_processorlevel = "PPC 604" ;
					break ;

				case 6 :
					m_processorlevel = "PPC 603+" ;
					break ;

				case 9 :
					m_processorlevel = "PPC 604+" ;
					break ;

				case 20 :
					m_processorlevel = "PPC 620" ;
					break ;
			}
	}
			
	if ( sysinfo.wProcessorArchitecture == 
		 PROCESSOR_ARCHITECTURE_UNKNOWN )
	{
		m_architecture = "Unknown" ;
	}

	m_carchitecture.SetWindowText( m_architecture ) ;
	m_cprocessorlevel.SetWindowText( m_processorlevel ) ;

	// page size
	m_pagesize.Format ( "%ld KB", sysinfo.dwPageSize / 1024 ) ;
	m_cpagesize.SetWindowText( m_pagesize ) ;

	// Application address

	m_maxaddress.Format ( "%x", sysinfo.lpMaximumApplicationAddress ) ;
	m_cmaxaddress.SetWindowText( m_maxaddress ) ;

	m_minaddress.Format ( "0x%x", sysinfo.lpMinimumApplicationAddress ) ;
	m_cminaddress.SetWindowText( m_minaddress ) ;

	// Get active processor mask
	// It represents how many processors are active

	m_mask.Format ( "%ld", sysinfo.dwActiveProcessorMask ) ;
	m_cmask.SetWindowText( m_mask ) ;
}
