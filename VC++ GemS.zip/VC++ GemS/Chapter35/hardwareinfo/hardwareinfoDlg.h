// hardwareinfoDlg.h : header file
//

#if !defined(AFX_HARDWAREINFODLG_H__2B2F4DE6_B8A6_11D5_9D42_0050BAD6AD8F__INCLUDED_)
#define AFX_HARDWAREINFODLG_H__2B2F4DE6_B8A6_11D5_9D42_0050BAD6AD8F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CHardwareinfoDlg dialog

class CHardwareinfoDlg : public CDialog
{
// Construction
public:
	void getsysinfo( );
	void getmemoryinfo( );
	CHardwareinfoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CHardwareinfoDlg)
	enum { IDD = IDD_HARDWAREINFO_DIALOG };
	CStatic	m_cprocessortype;
	CStatic	m_cvendorinfo;
	CStatic	m_cmemvirtual;
	CStatic	m_cpagesize;
	CStatic	m_cnumprocessors;
	CStatic	m_cminaddress;
	CStatic	m_cmemused;
	CStatic	m_cmeminstalled;
	CStatic	m_cmaxaddress;
	CStatic	m_cmask;
	CStatic	m_cprocessorlevel;
	CStatic	m_cmemavailable;
	CStatic	m_carchitecture;
	CString	m_architecture;
	CString	m_processorlevel;
	CString	m_vendorinfo;
	CString	m_mask;
	CString	m_maxaddress;
	CString	m_memavailable;
	CString	m_meminstalled;
	CString	m_memvirtual;
	CString	m_memused;
	CString	m_minaddress;
	CString	m_numprocessors;
	CString	m_pagesize;
	CString	m_processortype;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHardwareinfoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CHardwareinfoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HARDWAREINFODLG_H__2B2F4DE6_B8A6_11D5_9D42_0050BAD6AD8F__INCLUDED_)
