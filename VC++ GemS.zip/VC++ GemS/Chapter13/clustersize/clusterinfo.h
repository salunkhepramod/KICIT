// clusterinfo.h: interface for the clusterinfo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CLUSTERINFO_H__37DC120F_B32C_11D5_B2A2_0050BAD6ADC3__INCLUDED_)
#define AFX_CLUSTERINFO_H__37DC120F_B32C_11D5_B2A2_0050BAD6ADC3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// the structure returned by VWIN32_DIOC_DOS_DRIVEINFO
struct diskinfo
{
	WORD size ;
	WORD level ;
	DWORD sectorspercluster ;
	DWORD bytespersector ;
	DWORD availableclusters ;
	DWORD totalclusters ;
	DWORD availablephyssectors ;
	DWORD totalphyssectors ;
	DWORD availableallocationunits ;
	DWORD totalallocationunits ;
	DWORD reserved[2] ;
} ; 


// Definitions for getting cluster size in OSR2
#define VWIN32_DIOC_DOS_DRIVEINFO 6

// holds the register values before and after the call to get 
// the cluster size
struct REGS
{
	DWORD ebx, edx, ecx, eax, edi, esi, flags ;
} ;


class clusterinfo  
{
private :
	CString m_drivestr ;
public:
	clusterinfo();
	clusterinfo ( CString strdrive ) ;
	virtual ~clusterinfo();
public:
	bool getclustersize ( diskinfo& info ) ;
};

#endif // !defined(AFX_CLUSTERINFO_H__37DC120F_B32C_11D5_B2A2_0050BAD6ADC3__INCLUDED_)
