// clusterinfo.cpp: implementation of the clusterinfo class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "clustersize.h"
#include "clusterinfo.h"
//#include <ctype.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

clusterinfo::clusterinfo()
{

}

clusterinfo::~clusterinfo()
{

}

clusterinfo::clusterinfo ( CString strdrive )
{
	m_drivestr = strdrive ;
}

bool clusterinfo::getclustersize ( diskinfo& info )
{
	if ( m_drivestr.IsEmpty( ) )
		return false ;
	
	bool OSR2 = false ;

	OSVERSIONINFO os ;

	os.dwOSVersionInfoSize = sizeof ( OSVERSIONINFO ) ;
	GetVersionEx ( &os ) ;

	if ( os.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS )
	{
		if ( LOWORD ( os.dwBuildNumber ) > 1000 )		
			OSR2 = true ;
	}
	
	if ( !OSR2 )
	{
		GetDiskFreeSpace ( ( LPCTSTR ) m_drivestr, 
							&info.sectorspercluster, &info.bytespersector, 
							NULL, NULL ) ;
		return true ;
	}
	else
	{
		HANDLE hDevice;
		struct REGS reg;
		BOOL result;
		DWORD cb;
		
		const char *sz[ ] = { ( LPCTSTR ) m_drivestr };
		info.level = 0 ;
		hDevice = CreateFile ( "\\\\.\\vwin32", 0, 0, NULL, 0, 
							FILE_FLAG_DELETE_ON_CLOSE, NULL ) ;
		
		reg.edi = ( DWORD ) &info;
		reg.ecx = sizeof ( diskinfo ) ;
		reg.edx = ( DWORD ) ( LPCTSTR ) m_drivestr ;
		reg.eax = 0x7303;
		reg.flags = 0x0001;

		result = DeviceIoControl ( hDevice, 
								VWIN32_DIOC_DOS_DRIVEINFO,
								&reg, sizeof ( reg ), &reg, sizeof ( reg ), 
								&cb, 0 ) ;
		CloseHandle ( hDevice ) ;

		if ( result == 0 || ( reg.flags & 0x0001 ) )
			return false ;
		else
			return true ;
	}
}
