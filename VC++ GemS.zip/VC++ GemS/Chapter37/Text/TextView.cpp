// TextView.cpp : implementation of the CTextView class
//

#include "stdafx.h"
#include "Text.h"

#include "TextDoc.h"
#include "TextView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTextView
IMPLEMENT_DYNCREATE(CTextView, CView)

BEGIN_MESSAGE_MAP(CTextView, CView)
	//{{AFX_MSG_MAP(CTextView)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTextView construction/destruction

CTextView::CTextView()
{
	// TODO: add construction code here

}

CTextView::~CTextView()
{
}

BOOL CTextView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTextView drawing

void CTextView::OnDraw(CDC* pDC)
{
	CTextDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	int count = pDoc -> textarr.GetSize() ;
	if ( count )
	{
		for ( int i = 0 ; i < count ; i++ )
			( ( mytext * ) pDoc -> textarr[i] ) -> drawtext ( pDC ) ; 
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTextView diagnostics

#ifdef _DEBUG
void CTextView::AssertValid() const
{
	CView::AssertValid();
}

void CTextView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTextDoc* CTextView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTextDoc)));
	return (CTextDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTextView message handlers

void CTextView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CClientDC dc ( this ) ;

	CString facename[9] = 
	{
		"Arial", 
		"Times New Roman",
		"Tohima",
		"Comic Sans MS",
		"Courier",
		"Impact",
		"MS Sans Serif",
		"Verdana",
		"terminal"
	} ;

	COLORREF color = RGB ( rand( ) % 255, rand() % 255, rand() % 255 ) ;
	CString face = facename[rand()%9] ;
	int size = rand() % 500 ;

	CFont myfont ;
	myfont.CreatePointFont ( size, face, &dc ) ;

	dc.SelectObject ( myfont ) ;
	dc.SetTextColor ( color ) ;
	dc.SetBkMode ( TRANSPARENT ) ;
	dc.TextOut ( point.x, point.y, "Hello World" ) ;
	
	( ( CTextDoc* ) GetDocument( ) ) -> addtext ( point, face, size ,color ) ;
	
}
