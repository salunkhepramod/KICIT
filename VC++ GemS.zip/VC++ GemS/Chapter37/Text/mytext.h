// mytext.h: interface for the mytext class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYTEXT_H__73B94C6D_98D6_4997_8893_C0FB4CCC1F19__INCLUDED_)
#define AFX_MYTEXT_H__73B94C6D_98D6_4997_8893_C0FB4CCC1F19__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class mytext : public CObject  
{
	DECLARE_SERIAL( mytext ) 
public:
	void Serialize ( CArchive  &ar );
	void drawtext ( CDC *p );
	mytext ( CPoint point, CString facename, int size, COLORREF color );
	mytext();
	virtual ~mytext();
private:
	CString textfacename ;
	COLORREF textcolor ;
	CPoint textpoint ;
	int textsize ;

};

#endif // !defined(AFX_MYTEXT_H__73B94C6D_98D6_4997_8893_C0FB4CCC1F19__INCLUDED_)
