// mytext.cpp: implementation of the mytext class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Text.h"
#include "mytext.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
IMPLEMENT_SERIAL( mytext, CObject, 1)

mytext::mytext()
{

}

mytext::~mytext()
{

}

mytext::mytext(CPoint point, CString facename, int size, COLORREF color)
{
	textpoint = point ;
	textfacename = facename ;
	textsize = size ;
	textcolor = color ;
}

void mytext::drawtext(CDC *p)
{
	CFont myfont ;
	myfont.CreatePointFont ( textsize, textfacename, p ) ;
	p -> SelectObject ( myfont ) ;
	p -> SetTextColor ( textcolor ) ;
	p -> SetBkMode ( TRANSPARENT ) ;
	p -> TextOut ( textpoint.x, textpoint.y, "Hello World" ) ;
}

void mytext::Serialize(CArchive &ar)
{
	CObject::Serialize ( ar ) ;

	if ( ar.IsStoring( ) )
		ar << textpoint << textfacename << textsize << textcolor ;	
	else
		ar >> textpoint >> textfacename >> textsize >> textcolor ;	
}
