// bmpdialog.cpp : implementation file
//

#include "stdafx.h"
#include "dbissues.h"
#include "bmpdialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// bmpdialog dialog


bmpdialog::bmpdialog(CWnd* pParent /*=NULL*/)
	: CDialog(bmpdialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(bmpdialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void bmpdialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(bmpdialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(bmpdialog, CDialog)
	//{{AFX_MSG_MAP(bmpdialog)
	ON_WM_PAINT()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// bmpdialog message handlers

BOOL bmpdialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_h1 = AfxGetApp( ) -> LoadIcon ( IDI_ICON1 ) ;
	m_h2 = AfxGetApp( ) -> LoadIcon ( IDI_ICON2 ) ;

	SetIcon ( m_h1, TRUE ) ;

	m_flag = 1 ;
	SetTimer ( 1, 250, NULL ) ;

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void bmpdialog::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	CRect r ;
	GetClientRect ( &r ) ;
	
	CDC mymemdc ;
	CBitmap mybitmap ;
	mymemdc.CreateCompatibleDC ( &dc ) ;
	mybitmap.LoadBitmap ( IDB_BITMAP1 ) ;
	mymemdc.SelectObject ( &mybitmap ) ;
	dc.StretchBlt ( r.left, r.top, r.right - r.left, r.bottom - r.top, &mymemdc, 0, 0, 77, 77, SRCCOPY ) ;

}

void bmpdialog::OnTimer(UINT nIDEvent) 
{
	if ( m_flag == 1 )
	{
		SetIcon ( m_h1, TRUE ) ;
		m_flag = 2 ;
	}
	else
	{
		SetIcon ( m_h2, TRUE ) ;
		m_flag = 1 ;
	}

	
	CDialog::OnTimer(nIDEvent);
}
