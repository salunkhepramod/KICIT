// mytooltipctrl.cpp : implementation file
//

#include "stdafx.h"
#include "dbissues.h"
#include "mytooltipctrl.h"
#include <mmsystem.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// mytooltipctrl

mytooltipctrl::mytooltipctrl()
{
}

mytooltipctrl::~mytooltipctrl()
{
}


BEGIN_MESSAGE_MAP(mytooltipctrl, CToolTipCtrl)
	//{{AFX_MSG_MAP(mytooltipctrl)
	ON_WM_WINDOWPOSCHANGED()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// mytooltipctrl message handlers

int mytooltipctrl::addtool(CWnd *pwnd, LPCTSTR text)
{
	TOOLINFO ti ;

	ti.cbSize = sizeof ( TOOLINFO ) ;
	ti.lpszText = ( LPTSTR ) text ;
	ti.hinst = AfxGetInstanceHandle ( ) ;
	ti.hwnd = pwnd -> GetParent( ) -> GetSafeHwnd( ) ;
	ti.uFlags = TTF_SUBCLASS | TTF_IDISHWND ;
	ti.uId = ( UINT ) pwnd -> GetSafeHwnd( ) ;

	return ( int ) SendMessage ( TTM_ADDTOOL, 0, ( LPARAM )&ti ) ;
}

int mytooltipctrl::addtool(CWnd *pwnd, LPCTSTR text, CRect r)
{
		TOOLINFO ti ;
	ti.cbSize = sizeof ( TOOLINFO ) ;
	ti.lpszText = ( LPTSTR ) text ;
	ti.hinst = AfxGetInstanceHandle ( ) ;
	ti.hwnd = pwnd -> GetSafeHwnd( ) ;
	ti.uFlags = TTF_SUBCLASS ;
	ti.rect = r ;
	ti.uId = ( UINT ) pwnd -> GetSafeHwnd( ) ;

	return ( int ) SendMessage ( TTM_ADDTOOL, 1, ( LPARAM ) &ti ) ;
}

void mytooltipctrl::OnWindowPosChanged(WINDOWPOS FAR* lpwndpos) 
{
	CToolTipCtrl::OnWindowPosChanged(lpwndpos);
	
	if ( lpwndpos -> flags & SWP_SHOWWINDOW )
		::PlaySound ( "start.wav", NULL, SND_FILENAME | SND_ASYNC ) ;
	else
		::PlaySound ( NULL, NULL,SND_PURGE ) ;	
}
