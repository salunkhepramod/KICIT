// colordialog.cpp : implementation file
//

#include "stdafx.h"
#include "dbissues.h"
#include "colordialog.h"
#include "mytooltipctrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// colordialog dialog


colordialog::colordialog(CWnd* pParent /*=NULL*/)
	: CDialog(colordialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(colordialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void colordialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(colordialog)
	DDX_Control(pDX, IDOK, m_ok);
	DDX_Control(pDX, IDCANCEL, m_cancel);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(colordialog, CDialog)
	//{{AFX_MSG_MAP(colordialog)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// colordialog message handlers

BOOL colordialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	SetIcon ( AfxGetApp( ) -> LoadStandardIcon ( IDI_EXCLAMATION ), FALSE ) ;

	m_tip.Create ( this ) ;

	m_tip.addtool ( &m_ok, "You are on OK" ) ;
	m_tip.addtool ( &m_cancel, "You are on Cancel" ) ;	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void colordialog::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	CBrush mybrush ( RGB ( 255, 255, 0 ) ) ;
	dc.SelectObject ( &mybrush ) ;

	CRect r ;
	GetClientRect ( &r ) ;
	dc.Rectangle ( r.left, r.top, r.right, r.bottom ) ;
	mybrush.DeleteObject( ) ;

	mybrush.CreateSolidBrush ( RGB ( 255, 0, 0 ) ) ;
	dc.SelectObject ( &mybrush ) ;

	dc.Rectangle ( 60, 40, 100, 80 ) ;
	m_tip.addtool ( this, "This is Mr. X's House", CRect ( 60, 40, 100, 80 ) ) ;

	dc.Ellipse ( 105, 40, 120, 80 ) ;
	m_tip.addtool ( this, "This is Mr. X's car ", CRect ( 105, 40, 120, 80 ) ) ;

	CBitmap mybitmap ;
	CDC mymemdc ;

	mymemdc.CreateCompatibleDC ( &dc ) ;
	mybitmap.LoadBitmap ( IDB_BITMAP1 ) ;
	mymemdc.SelectObject ( &mybitmap ) ;
	dc.BitBlt ( 131, 40, 64, 64, &mymemdc, 0, 0, SRCCOPY ) ;
	m_tip.addtool ( this, "He Is Mr.X", CRect ( 131, 40, 170, 104 ) ) ;	
	// Do not call CDialog::OnPaint() for painting messages
}
