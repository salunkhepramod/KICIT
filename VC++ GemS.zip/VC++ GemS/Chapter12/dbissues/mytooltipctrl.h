#if !defined(AFX_MYTOOLTIPCTRL_H__7ADB8236_AC1E_11D5_9D42_0050BAD6AD8F__INCLUDED_)
#define AFX_MYTOOLTIPCTRL_H__7ADB8236_AC1E_11D5_9D42_0050BAD6AD8F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// mytooltipctrl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// mytooltipctrl window

class mytooltipctrl : public CToolTipCtrl
{
// Construction
public:
	mytooltipctrl();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(mytooltipctrl)
	//}}AFX_VIRTUAL

// Implementation
public:
	int addtool ( CWnd* pwnd, LPCTSTR text, CRect r );
	int addtool ( CWnd* pwnd, LPCTSTR text );
	virtual ~mytooltipctrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(mytooltipctrl)
	afx_msg void OnWindowPosChanged(WINDOWPOS FAR* lpwndpos);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYTOOLTIPCTRL_H__7ADB8236_AC1E_11D5_9D42_0050BAD6AD8F__INCLUDED_)
