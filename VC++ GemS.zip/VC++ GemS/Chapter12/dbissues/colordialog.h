#if !defined(AFX_COLORDIALOG_H__7ADB8234_AC1E_11D5_9D42_0050BAD6AD8F__INCLUDED_)
#define AFX_COLORDIALOG_H__7ADB8234_AC1E_11D5_9D42_0050BAD6AD8F__INCLUDED_

#include "mytooltipctrl.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// colordialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// colordialog dialog

class colordialog : public CDialog
{
// Construction
public:
	mytooltipctrl m_tip;
	colordialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(colordialog)
	enum { IDD = IDD_DIALOG1 };
	CButton	m_ok;
	CButton	m_cancel;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(colordialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(colordialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COLORDIALOG_H__7ADB8234_AC1E_11D5_9D42_0050BAD6AD8F__INCLUDED_)
