// ChildView.h : interface of the CChildView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHILDVIEW_H__26571CCB_B744_11D5_9D42_0050BAD6AD8F__INCLUDED_)
#define AFX_CHILDVIEW_H__26571CCB_B744_11D5_9D42_0050BAD6AD8F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CChildView window
#include "boot.h"

class CChildView : public CWnd
{
// Construction
public:
	CChildView();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChildView)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	void getmediaid ( int drive, media *m ) ;
	void bootsector16( int drive_0, int startsect,int numsect, void * buffer ) ;
	void bootsector32 ( int drive_1, int startsect, int numsect, void *buffer ) ;
	virtual ~CChildView();

	// Generated message map functions
protected:
	//{{AFX_MSG(CChildView)
	afx_msg void OnPaint();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CString m_str;
	boot m_bs ;
	boot32 m_bs32 ;
	HANDLE m_hdev ;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHILDVIEW_H__26571CCB_B744_11D5_9D42_0050BAD6AD8F__INCLUDED_)
