struct DIOC_REGISTERS 
{
	DWORD ebx ;
	DWORD edx ;
	DWORD ecx ;
	DWORD eax ;
	DWORD edi ;
	DWORD esi ;
	DWORD flags ;
} ;

#pragma pack ( 1 )

struct media
{
	WORD infolevel ;
	DWORD serialnumber ;
	char vollabel[11] ;
	char filesystype[8] ;
} ;

struct DISKIO 
{
    DWORD startsector ;    
    WORD  sectorsnum ;     
    DWORD buff ;         
} ;

struct boot
{
	BYTE jump[3] ;
	char OEMname[8] ;
	WORD bps ;
	BYTE spc ;
	WORD reservedsec ;
	BYTE fatcopies ;
	WORD maxdirentries ;
	WORD totalsec ;
	BYTE mediadesc ;
	WORD secperfat ;
	WORD secpertrack ;
	WORD noofsides ;
	DWORD hidden ;
	DWORD hugesec ;
    BYTE drivenumber ;
    BYTE reserved ;
    BYTE bootsignature ;
    DWORD volumeid ;
    char volumelabel[11] ;
    char filesystype[8] ;
	BYTE unused[450] ;
} ;

struct boot32 
{
	BYTE jump[3] ;
	char OEMname[8] ;
	WORD bps ;
	BYTE spc ;
	WORD reservedsec ;
	BYTE fatcopies ;
	WORD maxdirentries ;
	WORD totalsec ;
	BYTE mediadesc ;
	WORD secperfat ;
	WORD secpertrack ;
	WORD noofsides ;
	WORD hidden ;
    WORD hiddensectorshigh ;
    WORD bigtotalsectors ;
    WORD bigtotalsectorshigh ;
    WORD bigsectorsperfat ;
    WORD bigsectorsperfathi ;
    WORD extflags ;
    WORD fs_version ;
    WORD rootdirstrtclus ;
    WORD rootdirstrtclushi ;
    WORD fsinfosec ;
    WORD bkupbootsec ;
    WORD reserved[6] ;
    BYTE bsdrivenumber ;		  
    BYTE bsreserved ;
    BYTE bsbootsignature ;
    DWORD bsvolumeid ;	
    char bsvolumelabel[11] ;
    char bsfilesystype[8] ;
	BYTE unused [422] ;
} ;

struct 	bigfatbootfsinfo
{
	DWORD	FSInf_Sig ;
	DWORD	FSInf_free_clus_cnt ;
	DWORD	FSInf_next_free_clus ;
	DWORD	FSInf_resvd[3] ;
} ;

#pragma pack( )