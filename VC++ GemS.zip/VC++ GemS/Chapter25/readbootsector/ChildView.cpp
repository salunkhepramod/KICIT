// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "readbootsector.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildView
#define VWIN32_DIOC_DOS_IOCTL		1
#define VWIN32_DIOC_DOS_DRIVEINFO	6

CChildView::CChildView()
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView,CWnd )
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), HBRUSH(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc ( this ) ; 
	
	CRect r ;
	GetClientRect ( &r ) ;
	dc.DrawText ( m_str, m_str.GetLength( ), &r, DT_WORDBREAK ) ;
}


int CChildView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd ::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	m_hdev = CreateFile ( "\\\\.\\VWIN32", 0, 0, NULL, 0, 0, NULL ) ;

	media m ;
	getmediaid ( 3, &m ) ;

	CString jumpstr, volstr, filetypestr ;

	for ( int i = 0 ; i < 11 ; i++ )
		volstr += m.vollabel[i] ;

	for ( i = 0 ; i < 5 ; i++ )
		filetypestr += m.filesystype[i] ;

	if ( strncmp ( "FAT32", m.filesystype, 5 ) )
	{
		bootsector16 ( 2, 0, 1, &m_bs ) ;

		jumpstr.Format ( "Jump Instruction : %X%X%X\n", 
						 ( unsigned char ) m_bs.jump[0], 
						 ( unsigned char ) m_bs.jump[1], 
						 ( unsigned char ) m_bs.jump[2] ) ; 
		m_str.Format ( "Jump Instruction : %s\n\
System ID : %s\n\
File System Type : %s\n\
Bytes Per Sector : %u\n\
Sectors Per Cluster : %u\n\
Number of Sectors in Reserved Area : %d\n\
Number of Copies of FAT : %d\n\
Maximum Directory Entries : %d\n\
Total Number of Sectors : %d\n\
Media Descriptor : %X\n\
Sectors Per FAT : %d\n\
Sectors Per Track : %d\n\
Number of Sides : %d\n\
Number of Hidden Sectors: %d", 
jumpstr, volstr, filetypestr, m_bs32.bps, m_bs32.spc, m_bs32.noofsides, 
m_bs32.fatcopies, m_bs32.maxdirentries, m_bs32.totalsec, 
m_bs32.mediadesc, m_bs32.secperfat, m_bs32.secpertrack, 
m_bs32.noofsides, m_bs32.hidden ) ;
	}
	else
	{
		bootsector32 ( 3, 0, 1, &m_bs32 ) ;

		jumpstr.Format ( "%X%X%X\n", 
						 ( unsigned char ) m_bs32.jump[0], 
						 ( unsigned char ) m_bs32.jump[1], 
						 ( unsigned char ) m_bs32.jump[2] ) ; 

		///////////////
		CString hugesecstr, secperfatstr, hiddensecstr ;
		if ( m_bs32.totalsec == 0 )
			hugesecstr.Format ( "Huge Sectors : %u", ( m_bs32.bigtotalsectorshigh << 16) + m_bs32.bigtotalsectors ) ;
		else
			hugesecstr.Format ( "Total Number of Sectors : %d", m_bs32.totalsec ) ;

		if ( m_bs32.secperfat == 0 )
			secperfatstr.Format ( "Big Sectors Per FAT : %d", (m_bs32.bigsectorsperfathi << 16) + m_bs32.bigsectorsperfat ) ;
		else
			secperfatstr.Format ( "Sectors Per FAT : %d", m_bs32.secperfat ) ;


		DWORD totalhidden = ( m_bs32.hiddensectorshigh << 16 ) + m_bs32.hidden ;
		hiddensecstr.Format ( "Number of Hidden Sectors : %ld", totalhidden ) ;

		///////////////
		m_str.Format ( "Jump Instruction : %s\n\
System ID : %s\n\
File System Type : %s\n\
Bytes Per Sector : %u\n\
Sectors Per Cluster : %u\n\
Number of Sectors in Reserved Area : %d\n\
Number of Copies of FAT : %d\n\
Maximum Directory Entries : %d\n\
%s\n\
Media Descriptor : %X\n\
%s\n\
Sectors Per Track : %d\n\
Number of Sides : %d\n\
%s", 
jumpstr, volstr, filetypestr, m_bs32.bps, m_bs32.spc, m_bs32.noofsides, 
m_bs32.fatcopies, m_bs32.maxdirentries, hugesecstr, 
m_bs32.mediadesc, secperfatstr, m_bs32.secpertrack, 
m_bs32.noofsides, hiddensecstr ) ;
	}
	return 0;
}

void CChildView::getmediaid ( int drive, media *m )
{
	DIOC_REGISTERS r = { 0 } ;
	DWORD cb ;
	
	r.eax = 0x440d ;    
	r.ebx = drive ;
	r.ecx = 0x0866 ;
	r.edx = ( DWORD ) m ;
	r.flags = 1 ;

	DeviceIoControl ( m_hdev, VWIN32_DIOC_DOS_IOCTL,
						&r, sizeof ( r ), &r, sizeof ( r ), &cb, 0 ) ;
}

void CChildView::bootsector16( int drive_0, int startsect,
		 						  int numsect, void * buffer )
{
	DIOC_REGISTERS r = { 0 } ;
	DISKIO di ;
	DWORD cb;

	r.eax = drive_0 ;    
	r.ebx = ( DWORD ) &di ;
	r.ecx = 0xffff ;
	r.flags = 1 ;
	di.startsector = 0 ;
	di.sectorsnum = numsect ;
	di.buff = ( DWORD ) buffer ;
	
	int res = DeviceIoControl ( m_hdev, VWIN32_DIOC_DOS_DRIVEINFO,
						&r, sizeof ( r ), &r, sizeof ( r ), &cb, 0 ) ;
}

void CChildView::bootsector32 ( int drive_1, int startsect,
								   int numsect, void *buffer )
{
	DIOC_REGISTERS r ;
	DISKIO di ;
	DWORD cb ;

	r.eax = 0x7305 ;  
	r.ebx = ( DWORD ) &di ;
	r.ecx = 0xffff ;  
	r.edx = drive_1 ;  
	r.esi = 0 ;       
	r.flags = 0 ;       
	di.startsector = startsect ;
	di.sectorsnum = numsect ;
	di.buff = ( DWORD ) buffer ;

	DeviceIoControl( m_hdev, VWIN32_DIOC_DOS_DRIVEINFO,
					  &r, sizeof( r ), &r, sizeof( r ), &cb, 0 ); 
}
