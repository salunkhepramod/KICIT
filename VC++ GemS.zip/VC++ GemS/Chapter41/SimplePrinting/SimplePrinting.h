// SimplePrinting.h : main header file for the SIMPLEPRINTING application
//

#if !defined(AFX_SIMPLEPRINTING_H__44F97B9A_2CB1_11D2_9F19_0050BAD6AE01__INCLUDED_)
#define AFX_SIMPLEPRINTING_H__44F97B9A_2CB1_11D2_9F19_0050BAD6AE01__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CSimplePrintingApp:
// See SimplePrinting.cpp for the implementation of this class
//

class CSimplePrintingApp : public CWinApp
{
public:
	CSimplePrintingApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSimplePrintingApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CSimplePrintingApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIMPLEPRINTING_H__44F97B9A_2CB1_11D2_9F19_0050BAD6AE01__INCLUDED_)
