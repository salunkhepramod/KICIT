// SimplePrintingView.h : interface of the CSimplePrintingView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SIMPLEPRINTINGVIEW_H__44F97BA2_2CB1_11D2_9F19_0050BAD6AE01__INCLUDED_)
#define AFX_SIMPLEPRINTINGVIEW_H__44F97BA2_2CB1_11D2_9F19_0050BAD6AE01__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CSimplePrintingView : public CScrollView
{
protected: // create from serialization only
	CSimplePrintingView();
	DECLARE_DYNCREATE(CSimplePrintingView)

// Attributes
public:
	CSimplePrintingDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSimplePrintingView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSimplePrintingView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSimplePrintingView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in SimplePrintingView.cpp
inline CSimplePrintingDoc* CSimplePrintingView::GetDocument()
   { return (CSimplePrintingDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIMPLEPRINTINGVIEW_H__44F97BA2_2CB1_11D2_9F19_0050BAD6AE01__INCLUDED_)
