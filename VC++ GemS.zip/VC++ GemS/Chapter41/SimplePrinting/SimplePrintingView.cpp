// SimplePrintingView.cpp : implementation of the CSimplePrintingView class
//

#include "stdafx.h"
#include "SimplePrinting.h"

#include "SimplePrintingDoc.h"
#include "SimplePrintingView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSimplePrintingView

IMPLEMENT_DYNCREATE(CSimplePrintingView, CScrollView)

BEGIN_MESSAGE_MAP(CSimplePrintingView, CScrollView)
	//{{AFX_MSG_MAP(CSimplePrintingView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSimplePrintingView construction/destruction

CSimplePrintingView::CSimplePrintingView()
{
	// TODO: add construction code here

}

CSimplePrintingView::~CSimplePrintingView()
{
}

BOOL CSimplePrintingView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CSimplePrintingView drawing

void CSimplePrintingView::OnDraw(CDC* pDC)
{
	CSimplePrintingDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
	CPen mypen ;
	CBrush mybrush ;
	CFont myfont ;

	mypen.CreatePen ( PS_SOLID, 3, RGB ( 0, 0, 255 ) ) ;
	mybrush.CreateSolidBrush ( RGB ( 255, 0, 0 ) ) ;
	myfont.CreatePointFont ( 300, "Arial", pDC ) ;

	CPen* oldpen = pDC -> SelectObject ( &mypen ) ;
	CBrush* oldbrush = pDC -> SelectObject ( &mybrush ) ;
	CFont* oldfont = pDC -> SelectObject ( &myfont ) ;

	pDC -> Ellipse ( 100, -10, 300, -200 ) ;
	pDC -> Rectangle ( 300, -300, 500, -500 ) ;
	pDC -> TextOut ( 100, -600, "Hello", 5 ) ;

	pDC -> SelectObject ( oldpen ) ;
	pDC -> SelectObject ( oldbrush ) ;
	pDC -> SelectObject ( oldfont ) ;
}

void CSimplePrintingView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	CSize sizeTotal;
	// TODO: calculate the total size of this view
	sizeTotal.cx = 827 ; sizeTotal.cy = 1169 ;
	SetScrollSizes(MM_LOENGLISH, sizeTotal);
} 

/////////////////////////////////////////////////////////////////////////////
// CSimplePrintingView printing

BOOL CSimplePrintingView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	pInfo -> SetMaxPage ( 1 ) ;
	return DoPreparePrinting(pInfo);
}

void CSimplePrintingView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CSimplePrintingView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CSimplePrintingView diagnostics

#ifdef _DEBUG
void CSimplePrintingView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CSimplePrintingView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CSimplePrintingDoc* CSimplePrintingView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSimplePrintingDoc)));
	return (CSimplePrintingDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSimplePrintingView message handlers
