// SimplePrintingDoc.cpp : implementation of the CSimplePrintingDoc class
//

#include "stdafx.h"
#include "SimplePrinting.h"

#include "SimplePrintingDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSimplePrintingDoc

IMPLEMENT_DYNCREATE(CSimplePrintingDoc, CDocument)

BEGIN_MESSAGE_MAP(CSimplePrintingDoc, CDocument)
	//{{AFX_MSG_MAP(CSimplePrintingDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSimplePrintingDoc construction/destruction

CSimplePrintingDoc::CSimplePrintingDoc()
{
	// TODO: add one-time construction code here

}

CSimplePrintingDoc::~CSimplePrintingDoc()
{
}

BOOL CSimplePrintingDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CSimplePrintingDoc serialization

void CSimplePrintingDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CSimplePrintingDoc diagnostics

#ifdef _DEBUG
void CSimplePrintingDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CSimplePrintingDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSimplePrintingDoc commands
