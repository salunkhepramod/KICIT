// roundwindowView.cpp : implementation of the CRoundwindowView class
//

#include "stdafx.h"
#include "roundwindow.h"

#include "roundwindowDoc.h"
#include "roundwindowView.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRoundwindowView

IMPLEMENT_DYNCREATE(CRoundwindowView, CView)

BEGIN_MESSAGE_MAP(CRoundwindowView, CView)
	//{{AFX_MSG_MAP(CRoundwindowView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRoundwindowView construction/destruction

CRoundwindowView::CRoundwindowView()
{
	// TODO: add construction code here

}

CRoundwindowView::~CRoundwindowView()
{
}

BOOL CRoundwindowView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CRoundwindowView drawing

void CRoundwindowView::OnDraw(CDC* pDC)
{
	CRoundwindowDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CRect r ;
	GetClientRect ( &r ) ;

	CBrush mybrush ( RGB ( 0, 0, 255 ) ) ;

	pDC->FillRect ( &r, &mybrush ) ;
}

/////////////////////////////////////////////////////////////////////////////
// CRoundwindowView diagnostics

#ifdef _DEBUG
void CRoundwindowView::AssertValid() const
{
	CView::AssertValid();
}

void CRoundwindowView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CRoundwindowDoc* CRoundwindowView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CRoundwindowDoc)));
	return (CRoundwindowDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CRoundwindowView message handlers
