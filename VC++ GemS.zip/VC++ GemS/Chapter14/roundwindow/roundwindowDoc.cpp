// roundwindowDoc.cpp : implementation of the CRoundwindowDoc class
//

#include "stdafx.h"
#include "roundwindow.h"

#include "roundwindowDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRoundwindowDoc

IMPLEMENT_DYNCREATE(CRoundwindowDoc, CDocument)

BEGIN_MESSAGE_MAP(CRoundwindowDoc, CDocument)
	//{{AFX_MSG_MAP(CRoundwindowDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRoundwindowDoc construction/destruction

CRoundwindowDoc::CRoundwindowDoc()
{
	// TODO: add one-time construction code here

}

CRoundwindowDoc::~CRoundwindowDoc()
{
}

BOOL CRoundwindowDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CRoundwindowDoc serialization

void CRoundwindowDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CRoundwindowDoc diagnostics

#ifdef _DEBUG
void CRoundwindowDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CRoundwindowDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CRoundwindowDoc commands
