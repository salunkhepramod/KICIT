//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by togglekeys.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TOGGLEKEYS_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       129
#define IDC_EDIT1                       1000
#define ID_CAPS                         32771
#define ID_NUM                          32772
#define ID_SCROLL                       32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
