// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "palettedemo.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildView


COLORREF CChildView::m_colors[12] = {
									RGB ( 20, 0, 0 ),
									RGB ( 40, 0, 0 ),
									RGB ( 60, 0, 0 ),
									RGB ( 80, 0, 0 ),
									RGB ( 100, 0, 0 ),
									RGB ( 120, 0, 0 ),
									RGB ( 140, 0, 0 ),
									RGB ( 160, 0, 0 ),
									RGB ( 180, 0, 0 ),
									RGB ( 200, 0, 0 ),
									RGB ( 220, 0, 0 ),
									RGB ( 240, 0, 0 ) 
								} ;

BYTE CChildView::m_bColorVals[12][3] = {
										20, 0, 0,
										40, 0, 0,
										60, 0, 0,
										80, 0, 0,
										100, 0, 0,
										120, 0, 0,
										140, 0, 0,
										160, 0, 0,
										180, 0, 0,
										200, 0, 0,
										220, 0, 0,
										245, 0, 0 
									} ;


CChildView::CChildView()
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView,CWnd )
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), HBRUSH(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	if ( m_palette.m_hObject == NULL )
		return ;

	int width = m_maxx / 6 ;
	int height = m_maxy / 4 ;
	int row, col ;
	int x, y = 0, k = 0 ;
	
	for ( row = 0 ; row < 2 ; row++ ) 
	{
		x = 0 ;
		for ( col = 0 ; col < 6 ; col++ )
		{
			dc.SelectObject ( &m_mypen[k] ) ;
			dc.Rectangle ( x + 5, y + 5, x + width - 5, y + height - 5);
			x += width ;
			k++ ;
		}
	
		y += height ;
	}

	m_pOldpalette = dc.SelectPalette ( &m_palette, FALSE ) ;
	dc.RealizePalette();

	for ( int  i = 0 ; i < 12 ; i++  )
		m_mypalpen[i] = new CPen ( PS_SOLID, 8, 
		              PALETTERGB ( m_bColorVals[i][0], 
					  m_bColorVals[i][1], 
					  m_bColorVals[i][2] ) ) ;

	k = 0 ;
	y = height * 2 ;

	for ( row = 0 ; row < 2 ; row++ )
	{
		x = 0 ;
		for ( col = 0 ; col < 6 ; col++ )
		{
			dc.SelectObject ( m_mypalpen[k] ) ;
			dc.Rectangle ( x + 5, y + 5, x + width - 5, y + height - 5);
			x += width ;
			k++;
		}
		y += height ;
	}
	
	dc.SelectPalette ( m_pOldpalette, FALSE ) ;

	for ( i = 0 ; i < 12 ; i++ )
		delete m_mypalpen[i] ;
}


void CChildView::OnSize(UINT nType, int cx, int cy) 
{
	CWnd ::OnSize(nType, cx, cy);
	
	m_maxx = cx ;
	m_maxy = cy ;
}

int CChildView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd ::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	CClientDC d ( this ) ;
	if ( ( d.GetDeviceCaps ( RASTERCAPS ) & RC_PALETTE ) 
           == 0 )
	{
		MessageBox ( "Palette is not supported by this device \n \
			Change Settings", "Sorry" ) ;
		return 0 ;
	}

	for ( int i = 0 ; i < 12 ; i++ )
		m_mypen[i].CreatePen ( PS_SOLID, 8, m_colors[i] ) ;

	struct 
	{
		LOGPALETTE lp ;
		PALETTEENTRY ape[12] ;
	} pal ;

	LOGPALETTE *pLP = ( LOGPALETTE * ) &pal ;
	pLP -> palVersion = 0x300 ; 
	pLP -> palNumEntries = 12 ;

	for ( i = 0 ; i < 12 ; i++ )
	{
		pLP->palPalEntry[i].peRed = m_bColorVals[i][0] ;
		pLP->palPalEntry[i].peGreen = m_bColorVals[i][1] ;
		pLP->palPalEntry[i].peBlue = m_bColorVals[i][2] ;
		pLP->palPalEntry[i].peFlags = 0 ;
	}
	
	m_palette.CreatePalette ( pLP ) ;	
	
	return 0;
}
